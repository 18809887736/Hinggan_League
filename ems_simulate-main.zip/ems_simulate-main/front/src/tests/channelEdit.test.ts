/// <reference types="jest" />

import {
  applyConnectionTypeDefaults,
  applyProtocolTypeDefaults,
  getTlsMaterialRequirements,
  normalizeTlsVersion,
  selectFirstProtocolForConnectionType,
  shouldSaveChannelSecurity,
} from "@/utils/channelEdit";
import type { ChannelCreateRequest, ProtocolOption } from "@/types/channel";

const unchangedEdit = {
  isEdit: true,
  tlsSupported: true,
  tlsEnabled: false,
  tlsMode: "mutual" as const,
  tlsVersion: "1.2" as const,
  originalTlsEnabled: false,
  originalTlsMode: "mutual" as const,
  originalTlsVersion: "1.2" as const,
  hasNewFiles: false,
};

describe("channel edit optimization", () => {
  it("skips unchanged TLS settings", () => {
    expect(shouldSaveChannelSecurity(unchangedEdit)).toBe(false);
  });

  it("saves changed TLS settings or certificate files", () => {
    expect(
      shouldSaveChannelSecurity({ ...unchangedEdit, tlsEnabled: true }),
    ).toBe(true);
    expect(
      shouldSaveChannelSecurity({ ...unchangedEdit, hasNewFiles: true }),
    ).toBe(true);
  });

  it("saves when the TLS version changed", () => {
    expect(
      shouldSaveChannelSecurity({ ...unchangedEdit, tlsVersion: "1.3" }),
    ).toBe(true);
  });

  it("never saves TLS for unsupported protocols", () => {
    expect(
      shouldSaveChannelSecurity({
        ...unchangedEdit,
        tlsSupported: false,
        tlsEnabled: true,
        hasNewFiles: true,
      }),
    ).toBe(false);
  });
});

describe("normalizeTlsVersion", () => {
  it("keeps supported versions and falls back to 1.2", () => {
    expect(normalizeTlsVersion("1.3")).toBe("1.3");
    expect(normalizeTlsVersion("1.2")).toBe("1.2");
    expect(normalizeTlsVersion(undefined)).toBe("1.2");
    expect(normalizeTlsVersion("1.1")).toBe("1.2");
    expect(normalizeTlsVersion("unknown")).toBe("1.2");
  });
});

describe("channel edit endpoint hydration", () => {
  const protocols: ProtocolOption[] = [
    { value: 2, label: "IEC104", conn_types: [1, 2] },
  ];

  const createForm = (): ChannelCreateRequest => ({
    code: "iec104-client",
    name: "iec104-client",
    protocol_type: 2,
    conn_type: 1,
    ip: "10.20.30.40",
    port: 12404,
  });

  it("preserves persisted IP and port while channel details are hydrating", () => {
    const form = createForm();

    applyProtocolTypeDefaults(form, protocols, 2, true);
    applyConnectionTypeDefaults(form, 1, true);

    expect(form.ip).toBe("10.20.30.40");
    expect(form.port).toBe(12404);
  });

  it("still applies defaults for an explicit user connection-mode change", () => {
    const form = createForm();

    applyConnectionTypeDefaults(form, 1);

    expect(form.ip).toBe("127.0.0.1");
  });
});

describe("OPC UA M1 endpoint defaults", () => {
  const protocols: ProtocolOption[] = [
    { value: 7, label: "OPC UA", conn_types: [1, 2] },
  ];

  it("uses loopback for the server while NoSecurity is the only endpoint", () => {
    const form: ChannelCreateRequest = {
      code: "ua-server",
      name: "ua-server",
      protocol_type: 7,
      conn_type: 2,
      ip: "0.0.0.0",
      port: 502,
    };
    applyProtocolTypeDefaults(form, protocols, 7);
    expect(form.ip).toBe("127.0.0.1");
    expect(form.port).toBe(4840);
    applyConnectionTypeDefaults(form, 2);
    expect(form.ip).toBe("127.0.0.1");
  });
});

describe("media type protocol selection", () => {
  const protocols: ProtocolOption[] = [
    { value: 0, label: "Modbus RTU", conn_types: [0, 3] },
    { value: 1, label: "Modbus TCP", conn_types: [1, 2] },
    { value: 2, label: "IEC104", conn_types: [1, 2] },
  ];

  it("replaces a serial protocol with the first network protocol", () => {
    const form = {
      code: "serial-device",
      name: "serial-device",
      protocol_type: 0,
      conn_type: 3,
      ip: "0.0.0.0",
      port: 502,
    };

    selectFirstProtocolForConnectionType(form, protocols, 2);

    expect(form.conn_type).toBe(2);
    expect(form.protocol_type).toBe(1);
  });
});

describe("TLS material requirements", () => {
  it("requires only CA for a one-way TLS client", () => {
    expect(getTlsMaterialRequirements("one_way", 1)).toEqual({
      identity: false,
      caCertificate: true,
    });
  });

  it("requires only server identity for a one-way TLS server", () => {
    expect(getTlsMaterialRequirements("one_way", 2)).toEqual({
      identity: true,
      caCertificate: false,
    });
  });

  it("requires identity and CA for mutual TLS", () => {
    expect(getTlsMaterialRequirements("mutual", 1)).toEqual({
      identity: true,
      caCertificate: true,
    });
  });
});
