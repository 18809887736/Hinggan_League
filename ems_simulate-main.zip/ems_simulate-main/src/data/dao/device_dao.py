"""
设备数据访问层
提供设备的 CRUD 操作
"""

from src.data.controller.db import local_session
from src.data.log import log
from src.data.model.device import Device, DeviceDict


class DeviceDao:
    """设备数据访问对象"""

    def __init__(self):
        pass

    @classmethod
    def get_all_devices(cls) -> list[DeviceDict]:
        """获取所有设备"""
        try:
            with local_session() as session, session.begin():
                result = session.query(Device).where(Device.enable).all()
                return [item.to_dict() for item in result]
        except Exception as e:
            log.error(f"获取设备列表失败: {str(e)}")
            raise e

    @classmethod
    def get_device_by_code(cls, code: str) -> DeviceDict | None:
        """根据编码获取设备"""
        try:
            with local_session() as session, session.begin():
                result = session.query(Device).where(Device.code == code).first()
                return result.to_dict() if result else None
        except Exception as e:
            log.error(f"获取设备失败: {str(e)}")
            raise e

    @classmethod
    def get_device_by_id(cls, device_id: int) -> DeviceDict | None:
        """根据ID获取设备"""
        try:
            with local_session() as session, session.begin():
                result = session.query(Device).where(Device.id == device_id).first()
                return result.to_dict() if result else None
        except Exception as e:
            log.error(f"获取设备失败: {str(e)}")
            raise e

    @classmethod
    def create_device(cls, code: str, name: str, device_type: int = 0, group_id: int | None = None) -> int:
        """创建设备

        Returns:
            新设备ID
        """
        try:
            with local_session() as session, session.begin():
                device = Device(code=code, name=name, device_type=device_type, group_id=group_id)
                session.add(device)
                session.flush()
                return device.id
        except Exception as e:
            log.error(f"创建设备失败: {str(e)}")
            raise e

    @classmethod
    def update_device(cls, device_id: int, **kwargs) -> bool:
        """更新设备"""
        try:
            with local_session() as session, session.begin():
                result = session.query(Device).where(Device.id == device_id).first()
                if result:
                    for key, value in kwargs.items():
                        if hasattr(result, key):
                            setattr(result, key, value)
                    return True
                return False
        except Exception as e:
            log.error(f"更新设备失败: {str(e)}")
            raise e

    @classmethod
    def delete_device(cls, device_id: int) -> bool:
        """删除设备（软删除）"""
        try:
            with local_session() as session, session.begin():
                result = session.query(Device).where(Device.id == device_id).first()
                if result:
                    result.enable = False
                    return True
                return False
        except Exception as e:
            log.error(f"删除设备失败: {str(e)}")
            raise e

    # ==== IEC 61850 ICD 路径管理 ====

    @classmethod
    def set_device_icd_path(cls, device_id: int, icd_path: str, file_hash: str = "") -> bool:
        """设置设备的 ICD 文件路径"""
        try:
            with local_session() as session, session.begin():
                result = session.query(Device).where(Device.id == device_id).first()
                if result:
                    result.icd_path = icd_path
                    result.icd_file_hash = file_hash
                    return True
                return False
        except Exception as e:
            log.error(f"设置设备 ICD 路径失败: {str(e)}")
            raise e

    @classmethod
    def get_device_icd_path(cls, device_id: int) -> str | None:
        """获取设备的 ICD 文件路径"""
        try:
            with local_session() as session, session.begin():
                result = session.query(Device).where(Device.id == device_id).first()
                return result.icd_path if result else None
        except Exception as e:
            log.error(f"获取设备 ICD 路径失败: {str(e)}")
            return None

    @classmethod
    def get_devices_by_icd_path(cls, icd_path: str) -> list[DeviceDict]:
        """根据 ICD 文件路径查找关联的设备列表"""
        try:
            with local_session() as session, session.begin():
                results = session.query(Device).where(Device.icd_path == icd_path, Device.enable).all()
                return [item.to_dict() for item in results]
        except Exception as e:
            log.error(f"通过 ICD 路径查找设备失败: {str(e)}")
            return []
