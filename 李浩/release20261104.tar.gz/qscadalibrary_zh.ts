<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN" sourcelanguage="en">
<context>
    <name>Net Redundancy</name>
    <message>
        <location filename="qnetredundancy.cpp" line="211"/>
        <location filename="qnetredundancy.cpp" line="216"/>
        <location filename="qnetredundancy.cpp" line="236"/>
        <location filename="qnetredundancy.cpp" line="241"/>
        <location filename="qnetredundancy.cpp" line="767"/>
        <location filename="qnetredundancy.cpp" line="772"/>
        <location filename="qnetredundancy.cpp" line="801"/>
        <location filename="qnetredundancy.cpp" line="806"/>
        <location filename="qnetredundancy.cpp" line="847"/>
        <location filename="qnetredundancy.cpp" line="852"/>
        <location filename="qnetredundancy.cpp" line="892"/>
        <location filename="qnetredundancy.cpp" line="897"/>
        <location filename="qnetredundancy.cpp" line="922"/>
        <location filename="qnetredundancy.cpp" line="927"/>
        <source>Application downgrad to spare status</source>
        <translation>本机降级为备机</translation>
    </message>
    <message>
        <location filename="qnetredundancy.cpp" line="253"/>
        <source>Application upgrad to main status</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QAlarm</name>
    <message>
        <location filename="qalarm.cpp" line="121"/>
        <source>ALARM_PARA open failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qalarm.cpp" line="170"/>
        <source>clear</source>
        <translation>清除</translation>
    </message>
    <message>
        <location filename="qalarm.cpp" line="186"/>
        <source>alarm:act</source>
        <translation>报警：动作</translation>
    </message>
    <message>
        <location filename="qalarm.cpp" line="207"/>
        <source>alarm:resume</source>
        <translation>报警：复归</translation>
    </message>
</context>
<context>
    <name>QCanPortDlg</name>
    <message>
        <location filename="qcanportdlg.ui" line="14"/>
        <source>QCanPortDlg</source>
        <translation>CAN口设置</translation>
    </message>
    <message>
        <location filename="qcanportdlg.ui" line="26"/>
        <source>SetCanPort</source>
        <translation>设置CAN口</translation>
    </message>
    <message>
        <location filename="qcanportdlg.ui" line="38"/>
        <source>deviceNum</source>
        <translation>设备编号</translation>
    </message>
    <message>
        <location filename="qcanportdlg.ui" line="51"/>
        <source>portNum</source>
        <translation>端口编号</translation>
    </message>
    <message>
        <location filename="qcanportdlg.ui" line="64"/>
        <source>btr</source>
        <translation>波特率</translation>
    </message>
    <message>
        <location filename="qcanportdlg.ui" line="77"/>
        <source>canProtocolType</source>
        <translation>协议类型</translation>
    </message>
    <message>
        <location filename="qcanportdlg.ui" line="153"/>
        <source>Accept</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qcanportdlg.ui" line="166"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>QCheckUserDlg</name>
    <message>
        <location filename="qcheckuserdlg.cpp" line="91"/>
        <source>Administor Authentication </source>
        <translation>管理员认证</translation>
    </message>
    <message>
        <location filename="qcheckuserdlg.cpp" line="92"/>
        <source>Authentication Administor Password</source>
        <translation>认证管理员密码</translation>
    </message>
    <message>
        <location filename="qcheckuserdlg.cpp" line="93"/>
        <source>user</source>
        <translation>用户名</translation>
    </message>
    <message>
        <location filename="qcheckuserdlg.cpp" line="94"/>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <location filename="qcheckuserdlg.cpp" line="95"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qcheckuserdlg.cpp" line="96"/>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qcheckuserdlg.cpp" line="106"/>
        <location filename="qcheckuserdlg.cpp" line="162"/>
        <source>error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="qcheckuserdlg.cpp" line="107"/>
        <source>password error!</source>
        <translation>密码错误!</translation>
    </message>
    <message>
        <location filename="qcheckuserdlg.cpp" line="108"/>
        <location filename="qcheckuserdlg.cpp" line="164"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="qcheckuserdlg.cpp" line="163"/>
        <source>Password error!</source>
        <translation>密码错误!</translation>
    </message>
</context>
<context>
    <name>QChunnelConfigDlg</name>
    <message>
        <location filename="qchunnelconfigdlg.ui" line="14"/>
        <source>Dialog</source>
        <translation>通道组态</translation>
    </message>
    <message>
        <location filename="qchunnelconfigdlg.ui" line="32"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="qchunnelconfigdlg.ui" line="39"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="qchunnelconfigdlg.ui" line="46"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="qchunnelconfigdlg.cpp" line="70"/>
        <source>chunnel number</source>
        <translation>通道编号</translation>
    </message>
    <message>
        <location filename="qchunnelconfigdlg.cpp" line="72"/>
        <source>chunnel type</source>
        <translation>通道类型</translation>
    </message>
    <message>
        <location filename="qchunnelconfigdlg.cpp" line="74"/>
        <source>protocal type</source>
        <translation>协议类型</translation>
    </message>
    <message>
        <location filename="qchunnelconfigdlg.cpp" line="76"/>
        <source>port type</source>
        <translation>端口类型</translation>
    </message>
    <message>
        <location filename="qchunnelconfigdlg.cpp" line="78"/>
        <source>chunnel name</source>
        <translation>通道名称</translation>
    </message>
    <message>
        <location filename="qchunnelconfigdlg.cpp" line="80"/>
        <source>nick name</source>
        <translation>简称</translation>
    </message>
    <message>
        <location filename="qchunnelconfigdlg.cpp" line="82"/>
        <source>rtu address</source>
        <translation>站地址</translation>
    </message>
    <message>
        <location filename="qchunnelconfigdlg.cpp" line="84"/>
        <source>relate yx</source>
        <translation>关联遥信编号</translation>
    </message>
    <message>
        <location filename="qchunnelconfigdlg.cpp" line="86"/>
        <source>YcFunctionCode</source>
        <oldsource>iYcFunctionCode</oldsource>
        <translation>遥测功能码</translation>
    </message>
</context>
<context>
    <name>QChunnelEditDlg</name>
    <message>
        <location filename="qchunneleditdlg.ui" line="20"/>
        <source>QChunnelEditDlg</source>
        <translation>编辑通道</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.ui" line="175"/>
        <source>nickName</source>
        <translation>简称</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.ui" line="159"/>
        <source>chunnelName</source>
        <translation>通道名称</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.ui" line="214"/>
        <source>protocolType</source>
        <translation>协议类型</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.ui" line="260"/>
        <source>rtuAddr</source>
        <translation>站地址</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.ui" line="286"/>
        <source>iYcFunctionCode</source>
        <translation>遥测功能码</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.ui" line="237"/>
        <source>portType</source>
        <translation>端口类型</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.ui" line="191"/>
        <source>chunnelType</source>
        <translation>通道类型</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.ui" line="38"/>
        <source>Relate Yx</source>
        <translation>关联遥信编号</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.ui" line="66"/>
        <source>Rtu Name</source>
        <translation>站名称</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.ui" line="102"/>
        <source>Line Name</source>
        <translation>线路名称</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.ui" line="53"/>
        <source>Yx Name</source>
        <translation>遥信名称</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.ui" line="127"/>
        <source>setPortPara</source>
        <translation>设置端口参数</translation>
    </message>
    <message>
        <source>baud_name</source>
        <translation type="obsolete">波特率</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.cpp" line="159"/>
        <source>serial_name</source>
        <translation>串口名称</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.cpp" line="160"/>
        <source>baud_rate</source>
        <translation>波特率</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.cpp" line="161"/>
        <source>start_bit</source>
        <translation>起始位</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.cpp" line="162"/>
        <source>data_bit</source>
        <translation>数据位</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.cpp" line="163"/>
        <source>stop_bit</source>
        <translation>停止位</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.cpp" line="164"/>
        <source>check_tpye</source>
        <translation>校验</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.cpp" line="171"/>
        <source>local_address</source>
        <translation>本地地址</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.cpp" line="172"/>
        <source>local_port</source>
        <translation>本地端口</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.cpp" line="173"/>
        <source>remote_address</source>
        <translation>远方地址</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.cpp" line="174"/>
        <source>remote_port</source>
        <translation>远方端口</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.cpp" line="178"/>
        <source>device_num</source>
        <translation>设备编号</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.cpp" line="179"/>
        <source>port_num</source>
        <translation>端口编号</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.cpp" line="180"/>
        <source>btr0</source>
        <translation>btr0</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.cpp" line="181"/>
        <source>btr1</source>
        <translation>btr1</translation>
    </message>
    <message>
        <location filename="qchunneleditdlg.cpp" line="182"/>
        <source>can_protocol_type</source>
        <translation>CAN规约类型</translation>
    </message>
</context>
<context>
    <name>QCommMonitDlg</name>
    <message>
        <location filename="qcommmonitdlg.cpp" line="27"/>
        <source>data gether</source>
        <translation>数据采集</translation>
    </message>
    <message>
        <location filename="qcommmonitdlg.cpp" line="28"/>
        <source>data transmite</source>
        <translation>数据转发</translation>
    </message>
    <message>
        <location filename="qcommmonitdlg.cpp" line="43"/>
        <location filename="qcommmonitdlg.cpp" line="74"/>
        <source>chunnel name</source>
        <translation>通道名称</translation>
    </message>
    <message>
        <location filename="qcommmonitdlg.cpp" line="44"/>
        <location filename="qcommmonitdlg.cpp" line="75"/>
        <source>protocal type</source>
        <translation>协议类型</translation>
    </message>
    <message>
        <location filename="qcommmonitdlg.cpp" line="45"/>
        <location filename="qcommmonitdlg.cpp" line="76"/>
        <source>chunnel status</source>
        <translation>通道状态</translation>
    </message>
    <message>
        <location filename="qcommmonitdlg.cpp" line="46"/>
        <location filename="qcommmonitdlg.cpp" line="77"/>
        <source>port status</source>
        <oldsource>port</oldsource>
        <translation>端口状态</translation>
    </message>
    <message>
        <location filename="qcommmonitdlg.cpp" line="47"/>
        <location filename="qcommmonitdlg.cpp" line="78"/>
        <source>right count</source>
        <translation>正确码计数</translation>
    </message>
    <message>
        <location filename="qcommmonitdlg.cpp" line="48"/>
        <location filename="qcommmonitdlg.cpp" line="79"/>
        <source>error count</source>
        <translation>错误码计数</translation>
    </message>
    <message>
        <location filename="qcommmonitdlg.cpp" line="49"/>
        <location filename="qcommmonitdlg.cpp" line="80"/>
        <source>start time</source>
        <translation>起始时间</translation>
    </message>
    <message>
        <location filename="qcommmonitdlg.cpp" line="50"/>
        <location filename="qcommmonitdlg.cpp" line="81"/>
        <source>restore time</source>
        <translation>恢复时间</translation>
    </message>
    <message>
        <location filename="qcommmonitdlg.cpp" line="51"/>
        <location filename="qcommmonitdlg.cpp" line="82"/>
        <source>quit time</source>
        <translation>退出时间</translation>
    </message>
    <message>
        <location filename="qcommmonitdlg.cpp" line="96"/>
        <location filename="qcommmonitdlg.cpp" line="260"/>
        <source>server role:main</source>
        <translation>本机角色：主机</translation>
    </message>
    <message>
        <location filename="qcommmonitdlg.cpp" line="100"/>
        <location filename="qcommmonitdlg.cpp" line="264"/>
        <source>server role:slave</source>
        <translation>本机角色：备机</translation>
    </message>
    <message>
        <location filename="qcommmonitdlg.cpp" line="123"/>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qcommmonitdlg.cpp" line="124"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>QCtrlYcDialog</name>
    <message>
        <location filename="qctrlycdialog.ui" line="183"/>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.ui" line="196"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.ui" line="38"/>
        <source>station name</source>
        <translation>子站名称</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.ui" line="14"/>
        <source>QCtrlYcDialog</source>
        <translation>控制遥测</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.ui" line="26"/>
        <source>YC</source>
        <translation>遥测</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.ui" line="51"/>
        <source>line name</source>
        <translation>线路名称</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.ui" line="64"/>
        <source>yc name</source>
        <translation>遥测名称</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.ui" line="77"/>
        <source>current value</source>
        <translation>当前值</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.ui" line="133"/>
        <source>modify value</source>
        <translation>修改值</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.ui" line="146"/>
        <source>lock</source>
        <translation>闭锁</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.ui" line="159"/>
        <source>unlock</source>
        <translation>解锁</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.ui" line="209"/>
        <source>TextLabel</source>
        <translation>    </translation>
    </message>
    <message>
        <source>yc</source>
        <translation type="obsolete">遥测</translation>
    </message>
    <message>
        <source>control yc</source>
        <translation type="obsolete">控制遥测</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.cpp" line="189"/>
        <source>QCtrlYcDialog ycNum:</source>
        <translation>遥测设置对话框 遥测编号：</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.cpp" line="190"/>
        <source>, ycName:</source>
        <translation>，遥测名称：</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.cpp" line="191"/>
        <source>, currentValue:</source>
        <translation>，当前值：</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.cpp" line="192"/>
        <source>, modifiedValue:</source>
        <translation>，修改值：</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.cpp" line="207"/>
        <source>                Lock state</source>
        <translation>闭锁状态</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.cpp" line="211"/>
        <source>                unlock state</source>
        <translation>解锁状态</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.cpp" line="234"/>
        <source>                       lock state</source>
        <translation>闭锁状态</translation>
    </message>
    <message>
        <location filename="qctrlycdialog.cpp" line="238"/>
        <source>                       unlock state</source>
        <translation>解除闭锁状态</translation>
    </message>
</context>
<context>
    <name>QCtrlYkDialog</name>
    <message>
        <location filename="qctrlykdialog.cpp" line="39"/>
        <source>Select</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="40"/>
        <source>Execute</source>
        <translation>执行</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="41"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="42"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="68"/>
        <source>Substation name</source>
        <translation>子站名称</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="69"/>
        <source>Line Name</source>
        <translation>线路名称</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="70"/>
        <source>Yc Name</source>
        <translation>遥测名称</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="80"/>
        <location filename="qctrlykdialog.cpp" line="516"/>
        <source>Control Open</source>
        <translation>控分</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="81"/>
        <location filename="qctrlykdialog.cpp" line="518"/>
        <source>Control Close</source>
        <translation>控合</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="89"/>
        <source>YK</source>
        <translation>遥控</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="115"/>
        <source>Control YK</source>
        <translation>控制遥控</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="127"/>
        <source>correlation yk error!</source>
        <translation>相关的遥控量错误!</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="142"/>
        <source>correlation YX error</source>
        <translation>相关的遥信量错误</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="333"/>
        <location filename="qctrlykdialog.cpp" line="397"/>
        <source>Check YK condition error</source>
        <translation>检查遥控条件不满足</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="361"/>
        <source>YK Select Success</source>
        <translation>遥控选择成功</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="382"/>
        <source>YK Select Refused</source>
        <translation>遥控选择拒动</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="407"/>
        <source>If Execute?</source>
        <translation>是否执行！</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="418"/>
        <source> remote control </source>
        <translation>遥控</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="421"/>
        <source>close</source>
        <translation>控合</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="425"/>
        <source>open</source>
        <translation>控分</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="445"/>
        <source> YK Execute Success</source>
        <translation>遥控执行成功</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="470"/>
        <location filename="qctrlykdialog.cpp" line="473"/>
        <location filename="qctrlykdialog.cpp" line="476"/>
        <source>Processing</source>
        <translation>信号处理中</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="481"/>
        <source>YK Execute Refused</source>
        <translation>遥控执行拒动</translation>
    </message>
    <message>
        <location filename="qctrlykdialog.cpp" line="503"/>
        <source>YK Cancel,YK Execute Refused</source>
        <translation>遥控取消，遥控执行拒动</translation>
    </message>
</context>
<context>
    <name>QCtrlYsDialog</name>
    <message>
        <location filename="qctrlysdialog.cpp" line="36"/>
        <source>Select</source>
        <translation>选择</translation>
    </message>
    <message>
        <location filename="qctrlysdialog.cpp" line="37"/>
        <source>Execute</source>
        <translation>执行</translation>
    </message>
    <message>
        <location filename="qctrlysdialog.cpp" line="38"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="qctrlysdialog.cpp" line="57"/>
        <source>YS Name</source>
        <translation>遥设名称</translation>
    </message>
    <message>
        <location filename="qctrlysdialog.cpp" line="63"/>
        <source>current value</source>
        <translation>当前值</translation>
    </message>
    <message>
        <location filename="qctrlysdialog.cpp" line="68"/>
        <source>modify value</source>
        <translation>修改值</translation>
    </message>
    <message>
        <location filename="qctrlysdialog.cpp" line="74"/>
        <source>YS</source>
        <translation>遥设</translation>
    </message>
    <message>
        <location filename="qctrlysdialog.cpp" line="97"/>
        <source>Control YS</source>
        <translation>远程参数设定</translation>
    </message>
    <message>
        <location filename="qctrlysdialog.cpp" line="128"/>
        <source>Relate YS Error</source>
        <translation>远程参数设定错误</translation>
    </message>
    <message>
        <location filename="qctrlysdialog.cpp" line="198"/>
        <source>Ys Select success</source>
        <translation>遥设选择成功</translation>
    </message>
    <message>
        <location filename="qctrlysdialog.cpp" line="209"/>
        <location filename="qctrlysdialog.cpp" line="212"/>
        <location filename="qctrlysdialog.cpp" line="215"/>
        <source>Processing</source>
        <translation>信号处理中</translation>
    </message>
    <message>
        <location filename="qctrlysdialog.cpp" line="220"/>
        <source>YS Select Refused</source>
        <translation>遥设选择拒绝</translation>
    </message>
    <message>
        <location filename="qctrlysdialog.cpp" line="254"/>
        <source>If Execute?</source>
        <translation>是否执行？</translation>
    </message>
    <message>
        <location filename="qctrlysdialog.cpp" line="264"/>
        <source> remote setting </source>
        <translation>遥设</translation>
    </message>
    <message>
        <source>YS execute success</source>
        <translation type="obsolete">遥设执行成功</translation>
    </message>
</context>
<context>
    <name>QCtrlYtDialog</name>
    <message>
        <location filename="qctrlytdialog.cpp" line="35"/>
        <source>Select</source>
        <translation>选择</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="36"/>
        <source>Execute</source>
        <translation>执行</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="37"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="38"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="62"/>
        <source>YT Name</source>
        <translation>遥调名称</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="70"/>
        <location filename="qctrlytdialog.cpp" line="311"/>
        <source>Down</source>
        <translation>降</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="71"/>
        <location filename="qctrlytdialog.cpp" line="307"/>
        <source>Up</source>
        <translation>升</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="79"/>
        <source>YT</source>
        <translation>遥调</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="104"/>
        <source>Control YT</source>
        <translation>控制遥调</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="135"/>
        <source>Relate YT Error</source>
        <translation>相关的遥调量错误</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="167"/>
        <source>Invalid YT</source>
        <translation>无效的遥调</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="175"/>
        <source>Can not determine target up or down limit base on YT</source>
        <translation>不能通过遥调量决定目标的上下限</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="184"/>
        <source>Can not determine YC base on YT</source>
        <translation>不能通过遥调量决定遥测量</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="194"/>
        <source>Can not get relate YC data from YT</source>
        <translation>不能通过遥调量获得相关遥测数据</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="201"/>
        <location filename="qctrlytdialog.cpp" line="361"/>
        <location filename="qctrlytdialog.cpp" line="389"/>
        <source>Control YT DangWei is 1%dang</source>
        <translation>控制遥调挡位为1%挡</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="255"/>
        <source>Yt Select success</source>
        <translation>遥调选择成功</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="266"/>
        <location filename="qctrlytdialog.cpp" line="269"/>
        <location filename="qctrlytdialog.cpp" line="272"/>
        <location filename="qctrlytdialog.cpp" line="412"/>
        <location filename="qctrlytdialog.cpp" line="415"/>
        <location filename="qctrlytdialog.cpp" line="418"/>
        <location filename="qctrlytdialog.cpp" line="423"/>
        <source>Processing</source>
        <translation>信号处理中</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="277"/>
        <source>YT Select Refused</source>
        <translation>遥调选择拒动</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="304"/>
        <source> remote adjusting </source>
        <translation>遥调</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="331"/>
        <source>YT Cancel,YT execute refused</source>
        <translation>遥调取消，遥调执行拒动</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="353"/>
        <source>DangWei form 1% up to 2%,YT execute success</source>
        <translation>挡位从1%升挡到2%，遥调执行成功</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="355"/>
        <source>DangWei form 1% down to 2%,YT execute success</source>
        <translation>挡位从1%降挡到2%，遥调执行成功</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="382"/>
        <source>DangWei form 1% up to 2%,YT execute slip</source>
        <translation>挡位从1%升挡到2%，遥调执行滑挡</translation>
    </message>
    <message>
        <location filename="qctrlytdialog.cpp" line="384"/>
        <source>DangWei form 1% down to 2%,YT execute slip</source>
        <translation>挡位从1%降挡到2%，遥调执行滑挡</translation>
    </message>
</context>
<context>
    <name>QCtrlYxDialog</name>
    <message>
        <location filename="qctrlyxdialog.ui" line="186"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.ui" line="199"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>SubStation name</source>
        <translation type="obsolete">子站名称</translation>
    </message>
    <message>
        <source>Line Name</source>
        <translation type="obsolete">线路名称</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.ui" line="64"/>
        <source>Yx name</source>
        <oldsource>YC name</oldsource>
        <translation>遥信名称</translation>
    </message>
    <message>
        <source>Current state</source>
        <translation type="obsolete">当前状态</translation>
    </message>
    <message>
        <source>Lock</source>
        <translation type="obsolete">锁定</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.ui" line="172"/>
        <source>unlock</source>
        <translation>解除闭锁</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.ui" line="133"/>
        <location filename="qctrlyxdialog.cpp" line="259"/>
        <location filename="qctrlyxdialog.cpp" line="343"/>
        <source>Open</source>
        <translation>分</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.ui" line="14"/>
        <source>QCtrlYxDialog</source>
        <translation>控制遥信</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.ui" line="38"/>
        <source>station name</source>
        <translation>子站名称</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.ui" line="51"/>
        <source>line name</source>
        <translation>线路名称</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.ui" line="77"/>
        <source>current value</source>
        <translation>当前值</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.ui" line="146"/>
        <location filename="qctrlyxdialog.cpp" line="255"/>
        <location filename="qctrlyxdialog.cpp" line="339"/>
        <source>Close</source>
        <translation>合</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.ui" line="159"/>
        <source>lock</source>
        <translation>闭锁</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.ui" line="212"/>
        <source>TextLabel</source>
        <translation>    </translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.ui" line="26"/>
        <source>YX</source>
        <translation>遥信</translation>
    </message>
    <message>
        <source>Control YX</source>
        <translation type="obsolete">控制遥信</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.cpp" line="265"/>
        <location filename="qctrlyxdialog.cpp" line="331"/>
        <source>                lock state</source>
        <translation>锁定状态</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.cpp" line="269"/>
        <location filename="qctrlyxdialog.cpp" line="335"/>
        <source>                unlock state</source>
        <translation>解锁状态</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.cpp" line="316"/>
        <source>QCtrlYxDialog yxNum:</source>
        <translation>遥信设置对话框 遥信编号：</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.cpp" line="317"/>
        <source>, yxName:</source>
        <translation>，遥信名称：</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.cpp" line="318"/>
        <source>, currentState:</source>
        <translation>，当前状态：</translation>
    </message>
    <message>
        <location filename="qctrlyxdialog.cpp" line="319"/>
        <source>, modifiedState:</source>
        <translation>，修改状态：</translation>
    </message>
</context>
<context>
    <name>QDdTableView</name>
    <message>
        <location filename="qddtableview.cpp" line="21"/>
        <source>number</source>
        <translation>编号</translation>
    </message>
    <message>
        <location filename="qddtableview.cpp" line="22"/>
        <source>substation number</source>
        <translation>子站编号</translation>
    </message>
    <message>
        <location filename="qddtableview.cpp" line="23"/>
        <source>line number</source>
        <translation>线路编号</translation>
    </message>
    <message>
        <location filename="qddtableview.cpp" line="24"/>
        <source>name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="qddtableview.cpp" line="25"/>
        <source>attribute</source>
        <translation>属性</translation>
    </message>
    <message>
        <location filename="qddtableview.cpp" line="26"/>
        <source>process type</source>
        <translation>处理类型</translation>
    </message>
    <message>
        <source>coefficient</source>
        <translation type="obsolete">系数</translation>
    </message>
    <message>
        <source>raw data</source>
        <translation type="obsolete">生数据</translation>
    </message>
    <message>
        <location filename="qddtableview.cpp" line="27"/>
        <source>real value</source>
        <translation>实际值</translation>
    </message>
    <message>
        <location filename="qddtableview.cpp" line="28"/>
        <source>update time</source>
        <translation>更新时间</translation>
    </message>
</context>
<context>
    <name>QMultiDdSelectDlg</name>
    <message>
        <location filename="qmultiddselectdlg.ui" line="14"/>
        <source>QMultiDdSelectDlg</source>
        <translation>电度选择</translation>
    </message>
    <message>
        <location filename="qmultiddselectdlg.ui" line="58"/>
        <source>&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qmultiddselectdlg.ui" line="71"/>
        <source>&lt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qmultiddselectdlg.ui" line="84"/>
        <source>&gt;&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qmultiddselectdlg.ui" line="97"/>
        <source>&lt;&lt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qmultiddselectdlg.ui" line="130"/>
        <source>selectall</source>
        <translation>显示全部&gt;&gt;</translation>
    </message>
    <message>
        <location filename="qmultiddselectdlg.ui" line="143"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qmultiddselectdlg.ui" line="156"/>
        <source>CANCEL</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>QMultiYcSelectDlg</name>
    <message>
        <location filename="qmultiycselectdlg.ui" line="14"/>
        <source>QMultiYcSelectDlg</source>
        <translation>遥测选择</translation>
    </message>
    <message>
        <location filename="qmultiycselectdlg.ui" line="58"/>
        <source>&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qmultiycselectdlg.ui" line="71"/>
        <source>&lt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qmultiycselectdlg.ui" line="84"/>
        <source>&gt;&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qmultiycselectdlg.ui" line="97"/>
        <source>&lt;&lt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qmultiycselectdlg.ui" line="130"/>
        <source>selectall</source>
        <translation>显示全部&gt;&gt;</translation>
    </message>
    <message>
        <location filename="qmultiycselectdlg.ui" line="143"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qmultiycselectdlg.ui" line="156"/>
        <source>CANCEL</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>QMultiYxSelectDlg</name>
    <message>
        <location filename="qmultiyxselectdlg.ui" line="14"/>
        <source>QMultiYxSelectDlg</source>
        <translation>遥信选择</translation>
    </message>
    <message>
        <location filename="qmultiyxselectdlg.ui" line="58"/>
        <source>&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qmultiyxselectdlg.ui" line="71"/>
        <source>&lt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qmultiyxselectdlg.ui" line="84"/>
        <source>&gt;&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qmultiyxselectdlg.ui" line="97"/>
        <source>&lt;&lt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qmultiyxselectdlg.ui" line="130"/>
        <source>selectall</source>
        <translation>显示全部&gt;&gt;</translation>
    </message>
    <message>
        <location filename="qmultiyxselectdlg.ui" line="143"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qmultiyxselectdlg.ui" line="156"/>
        <source>CANCEL</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>QNetMonitDlg</name>
    <message>
        <location filename="qnetmonitdlg.ui" line="14"/>
        <source>QNetMonitDlg</source>
        <translation type="unfinished">网络监视对话框</translation>
    </message>
    <message>
        <location filename="qnetmonitdlg.cpp" line="46"/>
        <source>main</source>
        <translation type="unfinished">主机</translation>
    </message>
    <message>
        <location filename="qnetmonitdlg.cpp" line="50"/>
        <source>slave</source>
        <translation type="unfinished">备机</translation>
    </message>
    <message>
        <source>online</source>
        <translation type="obsolete">在线</translation>
    </message>
    <message>
        <source>offline</source>
        <translation type="obsolete">下线</translation>
    </message>
    <message>
        <location filename="qnetmonitdlg.cpp" line="60"/>
        <source>NodeNum</source>
        <translation type="unfinished">节点编号</translation>
    </message>
    <message>
        <location filename="qnetmonitdlg.cpp" line="61"/>
        <source>IP Adress</source>
        <translation type="unfinished">IP地址</translation>
    </message>
    <message>
        <location filename="qnetmonitdlg.cpp" line="62"/>
        <source>IsMain</source>
        <translation type="unfinished">主/备</translation>
    </message>
    <message>
        <location filename="qnetmonitdlg.cpp" line="64"/>
        <source>TmLast</source>
        <translation type="unfinished">上次发送时间</translation>
    </message>
    <message>
        <source>IsOnline</source>
        <translation type="obsolete">状态</translation>
    </message>
    <message>
        <location filename="qnetmonitdlg.cpp" line="63"/>
        <source>TmUp</source>
        <translation type="unfinished">上线时间</translation>
    </message>
    <message>
        <source>TmDown</source>
        <translation type="obsolete">下线时间</translation>
    </message>
</context>
<context>
    <name>QNetPortDlg</name>
    <message>
        <location filename="qnetportdlg.ui" line="14"/>
        <source>QNetPortDlg</source>
        <translation>网口设置对话框</translation>
    </message>
    <message>
        <location filename="qnetportdlg.ui" line="26"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qnetportdlg.ui" line="39"/>
        <source>Accept</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qnetportdlg.ui" line="52"/>
        <source>SetNetPort</source>
        <translation>设置网络端口</translation>
    </message>
    <message>
        <location filename="qnetportdlg.ui" line="64"/>
        <source>local_address</source>
        <translation>本地地址</translation>
    </message>
    <message>
        <location filename="qnetportdlg.ui" line="77"/>
        <source>local_port</source>
        <translation>本地端口</translation>
    </message>
    <message>
        <location filename="qnetportdlg.ui" line="90"/>
        <source>remote_address</source>
        <translation>远方地址</translation>
    </message>
    <message>
        <location filename="qnetportdlg.ui" line="103"/>
        <source>remote_port</source>
        <translation>远方端口</translation>
    </message>
</context>
<context>
    <name>QNetRedundancy</name>
    <message>
        <location filename="qnetredundancy.cpp" line="100"/>
        <source>Application start in case of spare status!</source>
        <translation>本机以备机身份启动!</translation>
    </message>
</context>
<context>
    <name>QOriCodeSelDlg</name>
    <message>
        <location filename="qoricodeselectdlg.cpp" line="32"/>
        <source>origin code select</source>
        <translation>源码选择</translation>
    </message>
    <message>
        <location filename="qoricodeselectdlg.cpp" line="37"/>
        <source>chunnel name</source>
        <translation>通道名称</translation>
    </message>
    <message>
        <location filename="qoricodeselectdlg.cpp" line="41"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qoricodeselectdlg.cpp" line="48"/>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qoricodeselectdlg.cpp" line="53"/>
        <source>Direction</source>
        <translation>方向</translation>
    </message>
    <message>
        <location filename="qoricodeselectdlg.cpp" line="57"/>
        <source>Up</source>
        <translation>上行</translation>
    </message>
    <message>
        <location filename="qoricodeselectdlg.cpp" line="61"/>
        <source>Down</source>
        <translation>下行</translation>
    </message>
    <message>
        <location filename="qoricodeselectdlg.cpp" line="65"/>
        <source>dual</source>
        <translation>双向</translation>
    </message>
    <message>
        <location filename="qoricodeselectdlg.cpp" line="88"/>
        <source>highlight1</source>
        <translation>特显1</translation>
    </message>
    <message>
        <location filename="qoricodeselectdlg.cpp" line="92"/>
        <source>highlight2</source>
        <translation>特显2</translation>
    </message>
    <message>
        <location filename="qoricodeselectdlg.cpp" line="96"/>
        <source>saveOriCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qoricodeselectdlg.cpp" line="183"/>
        <source>please select chunnel</source>
        <translation>请选择通道</translation>
    </message>
</context>
<context>
    <name>QOriCodeView</name>
    <message>
        <location filename="qoricodetview.cpp" line="122"/>
        <source>copy original code data</source>
        <translation>复制源码数据</translation>
    </message>
</context>
<context>
    <name>QSerialPortDlg</name>
    <message>
        <location filename="qserialportdlg.ui" line="14"/>
        <source>QSerialPortDlg</source>
        <translation>串口</translation>
    </message>
    <message>
        <location filename="qserialportdlg.ui" line="26"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qserialportdlg.ui" line="39"/>
        <source>Accept</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qserialportdlg.ui" line="52"/>
        <source>SetSerialPort</source>
        <translation>设置串口</translation>
    </message>
    <message>
        <location filename="qserialportdlg.ui" line="64"/>
        <source>serialName</source>
        <translation>串口名</translation>
    </message>
    <message>
        <location filename="qserialportdlg.ui" line="77"/>
        <source>baudRate</source>
        <translation>波特率</translation>
    </message>
    <message>
        <location filename="qserialportdlg.ui" line="90"/>
        <source>startBit</source>
        <translation>起始位</translation>
    </message>
    <message>
        <location filename="qserialportdlg.ui" line="123"/>
        <source>dataBit</source>
        <translation>数据位</translation>
    </message>
    <message>
        <location filename="qserialportdlg.ui" line="136"/>
        <source>stopBit</source>
        <translation>停止位</translation>
    </message>
    <message>
        <location filename="qserialportdlg.ui" line="149"/>
        <source>checkType</source>
        <translation>校验类型</translation>
    </message>
</context>
<context>
    <name>QTableModelEditDlg</name>
    <message>
        <location filename="tablemodeleditdlg.ui" line="20"/>
        <source>Dialog</source>
        <translation>通道组态</translation>
    </message>
    <message>
        <location filename="tablemodeleditdlg.ui" line="35"/>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
</context>
<context>
    <name>QYcCurveSelectDlg</name>
    <message>
        <location filename="qyccurveselectdlg.ui" line="14"/>
        <source>QYcCurveSelectDlg</source>
        <translation>曲线查询</translation>
    </message>
    <message>
        <location filename="qyccurveselectdlg.ui" line="36"/>
        <source>end time</source>
        <translation>结束时间</translation>
    </message>
    <message>
        <location filename="qyccurveselectdlg.ui" line="59"/>
        <source>query</source>
        <translation>查询</translation>
    </message>
    <message>
        <location filename="qyccurveselectdlg.ui" line="72"/>
        <source>close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="qyccurveselectdlg.ui" line="85"/>
        <source>start time</source>
        <translation>起始时间</translation>
    </message>
    <message>
        <location filename="qyccurveselectdlg.cpp" line="27"/>
        <source>yc_num</source>
        <translation>遥测编号</translation>
    </message>
    <message>
        <location filename="qyccurveselectdlg.cpp" line="28"/>
        <source>yc_time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="qyccurveselectdlg.cpp" line="29"/>
        <source>yc_data</source>
        <translation>数据</translation>
    </message>
</context>
<context>
    <name>QYcHistorySelectDlg</name>
    <message>
        <location filename="qychistoryselectdlg.ui" line="14"/>
        <source>QYcHistorySelectDlg</source>
        <translation>整点查询</translation>
    </message>
    <message>
        <location filename="qychistoryselectdlg.ui" line="36"/>
        <source>query</source>
        <translation>查询</translation>
    </message>
    <message>
        <location filename="qychistoryselectdlg.ui" line="49"/>
        <source>close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="qychistoryselectdlg.ui" line="62"/>
        <source>end time</source>
        <translation>结束时间</translation>
    </message>
    <message>
        <location filename="qychistoryselectdlg.ui" line="75"/>
        <source>start time</source>
        <translation>起始时间</translation>
    </message>
    <message>
        <location filename="qychistoryselectdlg.cpp" line="27"/>
        <source>yc_num</source>
        <translation>遥测编号</translation>
    </message>
    <message>
        <location filename="qychistoryselectdlg.cpp" line="28"/>
        <source>yc_time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="qychistoryselectdlg.cpp" line="29"/>
        <source>yc_data</source>
        <translation>数据</translation>
    </message>
</context>
<context>
    <name>QYcTableView</name>
    <message>
        <location filename="qyctableview.cpp" line="29"/>
        <source>number</source>
        <translation>编号</translation>
    </message>
    <message>
        <location filename="qyctableview.cpp" line="30"/>
        <source>substation number</source>
        <translation>子站编号</translation>
    </message>
    <message>
        <location filename="qyctableview.cpp" line="31"/>
        <source>line number</source>
        <translation>线路编号</translation>
    </message>
    <message>
        <location filename="qyctableview.cpp" line="32"/>
        <source>name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="qyctableview.cpp" line="33"/>
        <source>attribute</source>
        <translation>属性</translation>
    </message>
    <message>
        <location filename="qyctableview.cpp" line="35"/>
        <source>process type</source>
        <translation>处理类型</translation>
    </message>
    <message>
        <location filename="qyctableview.cpp" line="36"/>
        <source>run status</source>
        <translation>运行状态</translation>
    </message>
    <message>
        <location filename="qyctableview.cpp" line="45"/>
        <source>max interval</source>
        <translation>最大间隔</translation>
    </message>
    <message>
        <location filename="qyctableview.cpp" line="189"/>
        <source>User does not have permission</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qyctableview.cpp" line="43"/>
        <source>unit</source>
        <translation>单位</translation>
    </message>
    <message>
        <source>coeficient</source>
        <translation type="obsolete">系数</translation>
    </message>
    <message>
        <source>up limit</source>
        <translation type="obsolete">上限</translation>
    </message>
    <message>
        <source>up up limit</source>
        <translation type="obsolete">上上限</translation>
    </message>
    <message>
        <source>down limit</source>
        <translation type="obsolete">下限</translation>
    </message>
    <message>
        <source>down down limit</source>
        <translation type="obsolete">下下限</translation>
    </message>
    <message>
        <source>raw data</source>
        <translation type="obsolete">生数据</translation>
    </message>
    <message>
        <location filename="qyctableview.cpp" line="42"/>
        <source>real value</source>
        <translation>实际值</translation>
    </message>
    <message>
        <location filename="qyctableview.cpp" line="44"/>
        <source>update time</source>
        <translation>更新时间</translation>
    </message>
</context>
<context>
    <name>QYkTableView</name>
    <message>
        <location filename="qyktableview.cpp" line="20"/>
        <source>number</source>
        <translation>编号</translation>
    </message>
    <message>
        <location filename="qyktableview.cpp" line="21"/>
        <source>yk name</source>
        <oldsource>yx name</oldsource>
        <translation>遥控名称</translation>
    </message>
    <message>
        <location filename="qyktableview.cpp" line="22"/>
        <source>run status</source>
        <translation>运行状态</translation>
    </message>
    <message>
        <location filename="qyktableview.cpp" line="23"/>
        <source>yk status</source>
        <translation>遥控状态</translation>
    </message>
    <message>
        <location filename="qyktableview.cpp" line="24"/>
        <source>change time</source>
        <translation>变为时间</translation>
    </message>
</context>
<context>
    <name>QYsTableView</name>
    <message>
        <location filename="qystableview.cpp" line="17"/>
        <source>number</source>
        <translation>编号</translation>
    </message>
    <message>
        <location filename="qystableview.cpp" line="18"/>
        <source>name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="qystableview.cpp" line="19"/>
        <source>ysvalue</source>
        <translation>遥设名称</translation>
    </message>
    <message>
        <location filename="qystableview.cpp" line="20"/>
        <source>ysprocesstype</source>
        <translation>遥设处理类型</translation>
    </message>
    <message>
        <location filename="qystableview.cpp" line="21"/>
        <source>datatype</source>
        <translation>数据类型</translation>
    </message>
    <message>
        <location filename="qystableview.cpp" line="22"/>
        <source>relatenum</source>
        <translation>关联编号</translation>
    </message>
    <message>
        <location filename="qystableview.cpp" line="23"/>
        <source>isremote</source>
        <translation>远方就地</translation>
    </message>
    <message>
        <location filename="qystableview.cpp" line="24"/>
        <source>delay</source>
        <translation>延时</translation>
    </message>
    <message>
        <location filename="qystableview.cpp" line="25"/>
        <source>lastysvalue</source>
        <translation>上次遥设值</translation>
    </message>
    <message>
        <location filename="qystableview.cpp" line="26"/>
        <source>lastmoment</source>
        <translation>上次遥设时间</translation>
    </message>
    <message>
        <location filename="qystableview.cpp" line="27"/>
        <source>state</source>
        <translation>状态</translation>
    </message>
</context>
<context>
    <name>QYtTableView</name>
    <message>
        <location filename="qyttableview.cpp" line="20"/>
        <source>number</source>
        <translation>编号</translation>
    </message>
    <message>
        <location filename="qyttableview.cpp" line="21"/>
        <source>ytname</source>
        <oldsource>yc name</oldsource>
        <translation>遥调名称</translation>
    </message>
    <message>
        <location filename="qyttableview.cpp" line="22"/>
        <source>rational up limit</source>
        <translation>合理上限</translation>
    </message>
    <message>
        <location filename="qyttableview.cpp" line="23"/>
        <source>rational down limit</source>
        <translation>合理下限</translation>
    </message>
    <message>
        <location filename="qyttableview.cpp" line="24"/>
        <source>targe up limit</source>
        <translation>目标上限</translation>
    </message>
    <message>
        <location filename="qyttableview.cpp" line="25"/>
        <source>target down limit</source>
        <translation>目标下限</translation>
    </message>
    <message>
        <location filename="qyttableview.cpp" line="26"/>
        <source>run status</source>
        <translation>运行状态</translation>
    </message>
    <message>
        <location filename="qyttableview.cpp" line="27"/>
        <source>yt dw</source>
        <translation>遥调挡位</translation>
    </message>
    <message>
        <location filename="qyttableview.cpp" line="28"/>
        <source>update time</source>
        <translation>更新时间</translation>
    </message>
</context>
<context>
    <name>QYxTableView</name>
    <message>
        <location filename="qyxtableview.cpp" line="27"/>
        <source>number</source>
        <translation>编号</translation>
    </message>
    <message>
        <location filename="qyxtableview.cpp" line="28"/>
        <source>substation number</source>
        <translation>子站编号</translation>
    </message>
    <message>
        <location filename="qyxtableview.cpp" line="29"/>
        <source>line number</source>
        <translation>线路编号</translation>
    </message>
    <message>
        <location filename="qyxtableview.cpp" line="30"/>
        <source>name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="qyxtableview.cpp" line="31"/>
        <source>attribute</source>
        <translation>属性</translation>
    </message>
    <message>
        <location filename="qyxtableview.cpp" line="32"/>
        <source>process type</source>
        <translation>处理类型</translation>
    </message>
    <message>
        <location filename="qyxtableview.cpp" line="33"/>
        <source>status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="qyxtableview.cpp" line="34"/>
        <source>change time</source>
        <translation>变位时间</translation>
    </message>
    <message>
        <location filename="qyxtableview.cpp" line="35"/>
        <source>change interval</source>
        <translation>变位累计时间</translation>
    </message>
    <message>
        <location filename="qyxtableview.cpp" line="137"/>
        <source>User does not have permission</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
