<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN" sourcelanguage="en">
<context>
    <name>QAboutDialog</name>
    <message>
        <location filename="aboutdialog.ui" line="14"/>
        <source>about</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="42"/>
        <source>Auto volt and  reactive power  controler 2.0</source>
        <translation>发电厂电压无功自动调节器</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="55"/>
        <source>Shenyang Tianhe Automation engineering co., LTD</source>
        <translation>沈阳天河自动化工程有限公司</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="68"/>
        <source>Copy right  2016</source>
        <translation>版权所有 2016</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="81"/>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
</context>
<context>
    <name>AgcAdjuster</name>
    <message>
        <source>Adjust hang up 5 minute</source>
        <translation type="obsolete">调节挂起5分钟</translation>
    </message>
    <message>
        <source>Adjust exit</source>
        <translation type="obsolete">调整退出</translation>
    </message>
    <message>
        <source>Generator Adjuster%1</source>
        <translation type="obsolete">机组调节器%1</translation>
    </message>
    <message>
        <source>Get Generator average line volt failed</source>
        <translation type="obsolete">获取机组线电压平均值失败</translation>
    </message>
    <message>
        <source>Get Generator average phase current failed</source>
        <translation type="obsolete">获取机组相电流平均值失败</translation>
    </message>
    <message>
        <source>Get Generator frequency failed</source>
        <translation type="obsolete">获取机组频率失败</translation>
    </message>
    <message>
        <source>Get Generator cos failed</source>
        <translation type="obsolete">获取机组功率因数失败</translation>
    </message>
    <message>
        <source>Get Generator active power failed</source>
        <translation type="obsolete">获取机组有功失败</translation>
    </message>
    <message>
        <source>Get Generator reactive power failed</source>
        <translation type="obsolete">获取机组无功失败</translation>
    </message>
    <message>
        <source>Get Generator rotor current failed</source>
        <translation type="obsolete">获取机组转子电流失败</translation>
    </message>
    <message>
        <source>Get Generator factory volt A failed</source>
        <translation type="obsolete">获取机组厂用电A段失败</translation>
    </message>
    <message>
        <source>Get Generator factory volt B failed</source>
        <translation type="obsolete">获取机组厂用电B段失败</translation>
    </message>
    <message>
        <source>Get Generator second average line volt failed</source>
        <translation type="obsolete">获取备用量测线电压平均值失败</translation>
    </message>
    <message>
        <source>Get Generator second average current failed</source>
        <translation type="obsolete">获取备用量测电流平均值失败</translation>
    </message>
    <message>
        <source>Get Generator second average frequency failed</source>
        <translation type="obsolete">获取备用量测频率值失败</translation>
    </message>
    <message>
        <source>Get Generator second cos failed</source>
        <translation type="obsolete">获取备用量测功率因数失败</translation>
    </message>
    <message>
        <source>Get Generator second active power failed</source>
        <translation type="obsolete">获取备用量测有功值失败</translation>
    </message>
    <message>
        <source>Get Generator second reactive power failed</source>
        <translation type="obsolete">获取备用量测无功值失败</translation>
    </message>
    <message>
        <source>Get Generator second rotor current failed</source>
        <translation type="obsolete">获取备用量测转子电流值失败</translation>
    </message>
    <message>
        <source>Get Generator second factory volt A failed</source>
        <translation type="obsolete">获取备用量测厂用电A段值失败</translation>
    </message>
    <message>
        <source>Get Generator second factory volt B failed</source>
        <translation type="obsolete">获取备用量测厂用电B段值失败</translation>
    </message>
    <message>
        <source>pulse %1 ms output.if execute?</source>
        <translation type="obsolete">脉冲%1ms输出，是否执行?</translation>
    </message>
    <message>
        <source>Adjust waiting</source>
        <translation type="obsolete">调节等待</translation>
    </message>
    <message>
        <source>generator work status lock</source>
        <translation type="obsolete">机组工作状态闭锁</translation>
    </message>
    <message>
        <source>hand control exit lock</source>
        <translation type="obsolete">手柄退出闭锁</translation>
    </message>
    <message>
        <source>invalid plan value</source>
        <translation type="obsolete">无效计划值</translation>
    </message>
    <message>
        <source>YC lock</source>
        <translation type="obsolete">遥测闭锁</translation>
    </message>
    <message>
        <source>Adjust idle</source>
        <translation type="obsolete">调节空闲</translation>
    </message>
    <message>
        <source>Download command failed</source>
        <translation type="obsolete">下发指令失败</translation>
    </message>
</context>
<context>
    <name>AvrAdjuster</name>
    <message>
        <source>Adjust exit</source>
        <translation type="obsolete">调整退出</translation>
    </message>
    <message>
        <source>Generator Adjuster%1</source>
        <translation type="obsolete">机组调节器%1</translation>
    </message>
    <message>
        <source>Get Generator average line volt failed</source>
        <translation type="obsolete">获取机组线电压平均值失败</translation>
    </message>
    <message>
        <source>Get Generator average phase volt failed</source>
        <translation type="obsolete">获取机组相电压平均值失败</translation>
    </message>
    <message>
        <source>Get Generator average phase current failed</source>
        <translation type="obsolete">获取机组相电流平均值失败</translation>
    </message>
    <message>
        <source>Get Generator frequency failed</source>
        <translation type="obsolete">获取机组频率失败</translation>
    </message>
    <message>
        <source>Get Generator cos failed</source>
        <translation type="obsolete">获取机组功率因数失败</translation>
    </message>
    <message>
        <source>Get Generator active power failed</source>
        <translation type="obsolete">获取机组有功失败</translation>
    </message>
    <message>
        <source>Get Generator reactive power failed</source>
        <translation type="obsolete">获取机组无功失败</translation>
    </message>
    <message>
        <source>Get Generator rotor current failed</source>
        <translation type="obsolete">获取机组转子电流失败</translation>
    </message>
    <message>
        <source>Get Generator factory volt A failed</source>
        <translation type="obsolete">获取机组厂用电A段失败</translation>
    </message>
    <message>
        <source>Get Generator factory volt B failed</source>
        <translation type="obsolete">获取机组厂用电B段失败</translation>
    </message>
    <message>
        <source>Get Generator second average line volt failed</source>
        <translation type="obsolete">获取备用量测线电压平均值失败</translation>
    </message>
    <message>
        <source>pulse %1 ms output.if execute?</source>
        <translation type="obsolete">脉冲%1ms输出，是否执行?</translation>
    </message>
    <message>
        <source>Get Generator second average phase volt failed</source>
        <translation type="obsolete">获取备用量测相电压平均值失败</translation>
    </message>
    <message>
        <source>Get Generator second average current failed</source>
        <translation type="obsolete">获取备用量测电流平均值失败</translation>
    </message>
    <message>
        <source>Get Generator second average frequency failed</source>
        <translation type="obsolete">获取备用量测频率值失败</translation>
    </message>
    <message>
        <source>Get Generator second cos failed</source>
        <translation type="obsolete">获取备用量测功率因数失败</translation>
    </message>
    <message>
        <source>Get Generator second active power failed</source>
        <translation type="obsolete">获取备用量测有功值失败</translation>
    </message>
    <message>
        <source>Get Generator second reactive power failed</source>
        <translation type="obsolete">获取备用量测无功值失败</translation>
    </message>
    <message>
        <source>Get Generator second rotor current failed</source>
        <translation type="obsolete">获取备用量测转子电流值失败</translation>
    </message>
    <message>
        <source>Get Generator second factory volt A failed</source>
        <translation type="obsolete">获取备用量测厂用电A段值失败</translation>
    </message>
    <message>
        <source>Get Generator second factory volt B failed</source>
        <translation type="obsolete">获取备用量测厂用电B段值失败</translation>
    </message>
    <message>
        <source>AdjustUpAble:GetGenerator220KV failed!</source>
        <translation type="obsolete">AdjustUpAble:GetGenerator220KV失败!</translation>
    </message>
    <message>
        <source>GetQytParameter return FALSE!</source>
        <translation type="obsolete">GetQytParameter 返回 FALSE!</translation>
    </message>
    <message>
        <source>pulse %1 ms output</source>
        <translation type="obsolete">脉冲 %1 ms 输出</translation>
    </message>
    <message>
        <source>adjust up,Whether or not to perform?</source>
        <translation type="obsolete">增磁，是否执行?</translation>
    </message>
    <message>
        <source>adjust down,Whether or not to perform?</source>
        <translation type="obsolete">增磁，是否执行?</translation>
    </message>
    <message>
        <source>AVC</source>
        <translation type="obsolete">自动电压无功控制</translation>
    </message>
    <message>
        <source>Adjust hang up 5 minute</source>
        <translation type="obsolete">调节挂起5分钟</translation>
    </message>
    <message>
        <source>Adjust waiting</source>
        <translation type="obsolete">调节等待</translation>
    </message>
    <message>
        <source>generator work status lock</source>
        <translation type="obsolete">机组工作状态闭锁</translation>
    </message>
    <message>
        <source>hand control exit lock</source>
        <translation type="obsolete">手柄退出闭锁</translation>
    </message>
    <message>
        <source>invalid plan value</source>
        <translation type="obsolete">无效计划值</translation>
    </message>
    <message>
        <source>YC lock</source>
        <translation type="obsolete">遥测闭锁</translation>
    </message>
    <message>
        <source>Adjust idle</source>
        <translation type="obsolete">调节空闲</translation>
    </message>
    <message>
        <source>Download command failed</source>
        <translation type="obsolete">下发指令失败</translation>
    </message>
</context>
<context>
    <name>BOILER_AGC_LOCK</name>
    <message>
        <location filename="qboilerlock.cpp" line="321"/>
        <source>locktype error</source>
        <translation>闭锁类型错误</translation>
    </message>
</context>
<context>
    <name>BUSBAR_AGC_LOCK</name>
    <message>
        <location filename="qbusbarlock.cpp" line="321"/>
        <source>locktype error</source>
        <translation>闭锁类型错误</translation>
    </message>
</context>
<context>
    <name>CHistoryData</name>
    <message>
        <source>Failed to connect to driver!</source>
        <translation type="obsolete">连接驱动失败!</translation>
    </message>
    <message>
        <source>Failed to open database!</source>
        <translation type="obsolete">打开数据库失败!</translation>
    </message>
</context>
<context>
    <name>CheckUserDlg</name>
    <message>
        <source>Administor Authentication </source>
        <translation type="obsolete">管理员认证</translation>
    </message>
    <message>
        <source>Authentication Administor Password</source>
        <translation type="obsolete">认证管理员密码</translation>
    </message>
    <message>
        <source>user</source>
        <translation type="obsolete">用户名</translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="obsolete">密码</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">取消</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="obsolete">确定</translation>
    </message>
    <message>
        <source>error</source>
        <translation type="obsolete">错误</translation>
    </message>
    <message>
        <source>password error!</source>
        <translation type="obsolete">密码错误!</translation>
    </message>
    <message>
        <source>Password error!</source>
        <translation type="obsolete">密码错误!</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation type="obsolete">退出</translation>
    </message>
</context>
<context>
    <name>CtrlScoutDlg</name>
    <message>
        <source>data gether</source>
        <translation type="obsolete">数据采集</translation>
    </message>
    <message>
        <source>data transmite</source>
        <translation type="obsolete">数据转发</translation>
    </message>
    <message>
        <source>chunnel name</source>
        <translation type="obsolete">通道名称</translation>
    </message>
    <message>
        <source>protocal type</source>
        <translation type="obsolete">协议类型</translation>
    </message>
    <message>
        <source>chunnel status</source>
        <translation type="obsolete">通道状态</translation>
    </message>
    <message>
        <source>port</source>
        <translation type="obsolete">端口</translation>
    </message>
    <message>
        <source>right count</source>
        <translation type="obsolete">正确码计数</translation>
    </message>
    <message>
        <source>error count</source>
        <translation type="obsolete">错误码计数</translation>
    </message>
    <message>
        <source>start time</source>
        <translation type="obsolete">起始时间</translation>
    </message>
    <message>
        <source>restore time</source>
        <translation type="obsolete">恢复时间</translation>
    </message>
    <message>
        <source>quit time</source>
        <translation type="obsolete">退出时间</translation>
    </message>
    <message>
        <source>server role:main</source>
        <translation type="obsolete">本机角色：主机</translation>
    </message>
    <message>
        <source>server role:slave</source>
        <translation type="obsolete">本机角色：备机</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="obsolete">确定</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">取消</translation>
    </message>
</context>
<context>
    <name>CtrlYcDialog</name>
    <message>
        <source>Ok</source>
        <translation type="obsolete">确定</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">取消</translation>
    </message>
    <message>
        <source>station name</source>
        <translation type="obsolete">子站名称</translation>
    </message>
    <message>
        <source>line name</source>
        <translation type="obsolete">线路名称</translation>
    </message>
    <message>
        <source>yc name</source>
        <translation type="obsolete">遥测名称</translation>
    </message>
    <message>
        <source>current value</source>
        <translation type="obsolete">当前值</translation>
    </message>
    <message>
        <source>modify value</source>
        <translation type="obsolete">修改值</translation>
    </message>
    <message>
        <source>lock</source>
        <translation type="obsolete">闭锁</translation>
    </message>
    <message>
        <source>unlock</source>
        <translation type="obsolete">解除闭锁</translation>
    </message>
    <message>
        <source>yc</source>
        <translation type="obsolete">遥测</translation>
    </message>
    <message>
        <source>control yc</source>
        <translation type="obsolete">控制遥测</translation>
    </message>
    <message>
        <source>                Lock state</source>
        <translation type="obsolete">                闭锁状态</translation>
    </message>
    <message>
        <source>                unlock state</source>
        <translation type="obsolete">                解除闭锁状态</translation>
    </message>
    <message>
        <source>                       lock state</source>
        <translation type="obsolete">                       闭锁状态</translation>
    </message>
    <message>
        <source>                       unlock state</source>
        <translation type="obsolete">                       解除闭锁状态</translation>
    </message>
</context>
<context>
    <name>CtrlYkDialog</name>
    <message>
        <source>Select</source>
        <translation type="obsolete">选择</translation>
    </message>
    <message>
        <source>Execute</source>
        <translation type="obsolete">执行</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">撤销</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation type="obsolete">退出</translation>
    </message>
    <message>
        <source>Substation name</source>
        <translation type="obsolete">子站名称</translation>
    </message>
    <message>
        <source>Line Name</source>
        <translation type="obsolete">线路名称</translation>
    </message>
    <message>
        <source>Yc Name</source>
        <translation type="obsolete">遥测名称</translation>
    </message>
    <message>
        <source>Control Open</source>
        <translation type="obsolete">控分</translation>
    </message>
    <message>
        <source>Control Close</source>
        <translation type="obsolete">控合</translation>
    </message>
    <message>
        <source>YK</source>
        <translation type="obsolete">遥控</translation>
    </message>
    <message>
        <source>Control YK</source>
        <translation type="obsolete">控制遥控</translation>
    </message>
    <message>
        <source>correlation yk error!</source>
        <translation type="obsolete">相关的遥控量错误!</translation>
    </message>
    <message>
        <source>correlation YX error</source>
        <translation type="obsolete">相关的遥信量错误</translation>
    </message>
    <message>
        <source>Check YK condition error</source>
        <translation type="obsolete">检查遥控条件不满足</translation>
    </message>
    <message>
        <source>YK Select Success</source>
        <translation type="obsolete">遥控选择成功</translation>
    </message>
    <message>
        <source>YK Select Refused</source>
        <translation type="obsolete">遥控选择拒动</translation>
    </message>
    <message>
        <source> YK Execute Success</source>
        <translation type="obsolete">遥控执行成功</translation>
    </message>
    <message>
        <source>Processing</source>
        <translation type="obsolete">信号处理中</translation>
    </message>
    <message>
        <source>YK Execute Refused</source>
        <translation type="obsolete">遥控执行拒动</translation>
    </message>
    <message>
        <source>YK Cancel,YK Execute Refused</source>
        <translation type="obsolete">遥控取消，遥控执行拒动</translation>
    </message>
</context>
<context>
    <name>CtrlYtDialog</name>
    <message>
        <source>Select</source>
        <translation type="obsolete">选择</translation>
    </message>
    <message>
        <source>Execute</source>
        <translation type="obsolete">执行</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">撤销</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation type="obsolete">退出</translation>
    </message>
    <message>
        <source>YT Name</source>
        <translation type="obsolete">遥调名称</translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="obsolete">降挡</translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="obsolete">升挡</translation>
    </message>
    <message>
        <source>YT</source>
        <translation type="obsolete">遥调</translation>
    </message>
    <message>
        <source>Control YT</source>
        <translation type="obsolete">控制遥调</translation>
    </message>
    <message>
        <source>Relate YT Error</source>
        <translation type="obsolete">相关的遥调量错误</translation>
    </message>
    <message>
        <source>Invalid YT</source>
        <translation type="obsolete">无效的遥调</translation>
    </message>
    <message>
        <source>Can not determine target up or down limit base on YT</source>
        <translation type="obsolete">不能通过遥调量决定目标的上下限</translation>
    </message>
    <message>
        <source>Can not determine YC base on YT</source>
        <translation type="obsolete">不能通过遥调量决定遥测量</translation>
    </message>
    <message>
        <source>Can not get relate YC data from YT</source>
        <translation type="obsolete">不能通过遥调量获得相关遥测数据</translation>
    </message>
    <message>
        <source>Control YT DangWei is 1%dang</source>
        <translation type="obsolete">控制遥调挡位为1%挡</translation>
    </message>
    <message>
        <source>Yt Select success</source>
        <translation type="obsolete">遥调选择成功</translation>
    </message>
    <message>
        <source>Processing</source>
        <translation type="obsolete">信号处理中</translation>
    </message>
    <message>
        <source>YT Select Refused</source>
        <translation type="obsolete">遥调选择拒动</translation>
    </message>
    <message>
        <source>YT Cancel,YT execute refused</source>
        <translation type="obsolete">遥调取消，遥调执行拒动</translation>
    </message>
    <message>
        <source>DangWei form 1% up to 2%,YT execute success</source>
        <translation type="obsolete">挡位从1%升挡到2%，遥调执行成功</translation>
    </message>
    <message>
        <source>DangWei form 1% down to 2%,YT execute success</source>
        <translation type="obsolete">挡位从1%降挡到2%，遥调执行成功</translation>
    </message>
    <message>
        <source>DangWei form 1% up to 2%,YT execute slip</source>
        <translation type="obsolete">挡位从1%升挡到2%，遥调执行滑挡</translation>
    </message>
    <message>
        <source>DangWei form 1% down to 2%,YT execute slip</source>
        <translation type="obsolete">挡位从1%降挡到2%，遥调执行滑挡</translation>
    </message>
</context>
<context>
    <name>CtrlYxDialog</name>
    <message>
        <source>OK</source>
        <translation type="obsolete">确定</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">撤销</translation>
    </message>
    <message>
        <source>SubStation name</source>
        <translation type="obsolete">子站名称</translation>
    </message>
    <message>
        <source>Line Name</source>
        <translation type="obsolete">线路名称</translation>
    </message>
    <message>
        <source>YC name</source>
        <translation type="obsolete">遥测名称</translation>
    </message>
    <message>
        <source>Current state</source>
        <translation type="obsolete">当前状态</translation>
    </message>
    <message>
        <source>Lock</source>
        <translation type="obsolete">锁定</translation>
    </message>
    <message>
        <source>unlock</source>
        <translation type="obsolete">解除锁定</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="obsolete">分</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="obsolete">合</translation>
    </message>
    <message>
        <source>YX</source>
        <translation type="obsolete">遥信</translation>
    </message>
    <message>
        <source>Control YX</source>
        <translation type="obsolete">控制遥信</translation>
    </message>
    <message>
        <source>                lock state</source>
        <translation type="obsolete">                锁定状态</translation>
    </message>
    <message>
        <source>                unlock state</source>
        <translation type="obsolete">                解除锁定状态</translation>
    </message>
</context>
<context>
    <name>Distributer</name>
    <message>
        <source>AVC adjust exit</source>
        <translation type="obsolete">AVC调节退出</translation>
    </message>
    <message>
        <source>Busbar reactive power distributer %1</source>
        <translation type="obsolete">母线无功分配器%1</translation>
    </message>
    <message>
        <source>Get busbar MIN Target failed!</source>
        <translation type="obsolete">获取母线最小目标值失败!</translation>
    </message>
    <message>
        <source>Get busbar MAX Target failed!</source>
        <translation type="obsolete">获取母线最大目标值失败!</translation>
    </message>
    <message>
        <source>Get Busbar single Max Voltage failed!</source>
        <translation type="obsolete">获取母线单次最大目标增量值失败!</translation>
    </message>
    <message>
        <source>get busbar MIN Target failed!</source>
        <translation type="obsolete">获取母线最小目标值失败!</translation>
    </message>
    <message>
        <source>Get Busbar Dead Limit failed!</source>
        <translation type="obsolete">获取母线死区值失败!</translation>
    </message>
    <message>
        <source>Wait AVC Adjusting</source>
        <translation type="obsolete">AVC调节等待</translation>
    </message>
    <message>
        <source>AVC hang up</source>
        <translation type="obsolete">AVC挂起</translation>
    </message>
    <message>
        <source>not main busbar,adjust quit!</source>
        <translation type="obsolete">非主母线，调节退出!</translation>
    </message>
    <message>
        <source>AVC local to remote sleeping</source>
        <translation type="obsolete">AVC就地切到远方等待</translation>
    </message>
    <message>
        <source>VAdjustDistributing:GetBusbarplanVExcute failed!</source>
        <translation type="obsolete">VAdjustDistributing:GetBusbarplanVExcute 失败!</translation>
    </message>
    <message>
        <source>VAdjustDistributing:GetBusbarIsUseLocalCurve failed!</source>
        <translation type="obsolete">VAdjustDistributing:GetBusbarIsUseLocalCurve 失败!</translation>
    </message>
    <message>
        <source>check AVC remote/local status locked</source>
        <translation type="obsolete">检查AVC远方就地状态闭锁</translation>
    </message>
    <message>
        <source>VAdjustDistributing:GetBusbarIsMainBusbar failed!</source>
        <translation type="obsolete">VAdjustDistributing:GetBusbarIsMainBusbar 失败!</translation>
    </message>
    <message>
        <source>GetJoinGenerator failed!</source>
        <translation type="obsolete">获取参加调节的机组失败!</translation>
    </message>
    <message>
        <source>no generator can be used to be adjust</source>
        <translation type="obsolete">无机组无功设备可调</translation>
    </message>
    <message>
        <source>VAdjustDistributing:GetBusbarplanV failed!</source>
        <translation type="obsolete">VAdjustDistributing:GetBusbarplanV 失败!</translation>
    </message>
    <message>
        <source>AVC adjust lock!</source>
        <translation type="obsolete">AVC 调节闭锁!</translation>
    </message>
    <message>
        <source>VAdjustDistributing:GetBusbarUpLimit failed!</source>
        <translation type="obsolete">VAdjustDistributing:GetBusbarUpLimit 失败!</translation>
    </message>
    <message>
        <source>VAdjustDistributing:GetBusbarDownLimit failed!</source>
        <translation type="obsolete">VAdjustDistributing:GetBusbarDownLimit 失败!</translation>
    </message>
    <message>
        <source>Get busbar Target MIN failed!</source>
        <translation type="obsolete">获取母线目标最小值失败!</translation>
    </message>
    <message>
        <source>get busbar Target MAX failed!</source>
        <translation type="obsolete">获取母线目标最大值失败!</translation>
    </message>
    <message>
        <source>invalid plan value</source>
        <translation type="obsolete">无效计划值</translation>
    </message>
    <message>
        <source>AVC adjust idle</source>
        <translation type="obsolete">AVC调节空闲</translation>
    </message>
    <message>
        <source>AVC adjust locked</source>
        <translation type="obsolete">AVC调节闭锁</translation>
    </message>
    <message>
        <source>calculate delta reactive power base on target volt failed</source>
        <translation type="obsolete">利用目标电压计算无功增量失败</translation>
    </message>
    <message>
        <source>Distribute reactive power failed</source>
        <translation type="obsolete">无功分配失败</translation>
    </message>
    <message>
        <source>adjust times over</source>
        <translation type="obsolete">连续调节超过</translation>
    </message>
    <message>
        <source>,adjust sleep 5 minute</source>
        <translation type="obsolete">次，挂起5分钟</translation>
    </message>
    <message>
        <source>Invalid Gens Plan Delta Q</source>
        <translation type="obsolete">无效的多机组计划无功增量</translation>
    </message>
    <message>
        <source>adjust times over 40,adjust sleep 5 minute</source>
        <translation type="obsolete">连续调节超过40次，挂起5分钟</translation>
    </message>
    <message>
        <source>get busbar up up limit failed!</source>
        <translation type="obsolete">获取母线上上限失败!</translation>
    </message>
    <message>
        <source>Get busbar down down limit failed!</source>
        <translation type="obsolete">获取母线下下限失败!</translation>
    </message>
    <message>
        <source>Get busbar volt failed!</source>
        <translation type="obsolete">获取母线电压失败!</translation>
    </message>
    <message>
        <source>Get plan curve failed!</source>
        <translation type="obsolete">获取计划值失败!</translation>
    </message>
    <message>
        <source>Get busbar Dead limit failed</source>
        <translation type="obsolete">获取母线死区失败</translation>
    </message>
    <message>
        <source>Get busbar remote lock flag failed!</source>
        <translation type="obsolete">获取母线远程闭锁标志失败!</translation>
    </message>
    <message>
        <source>VAdjustDistributing:GetIsBusDoubleVLock failed!</source>
        <translation type="obsolete">VAdjustDistributing:GetIsBusDoubleVLock 失败!</translation>
    </message>
    <message>
        <source>VAdjustDistributing:GetIsBusDoublePTLock failed!</source>
        <translation type="obsolete">VAdjustDistributing:GetIsBusDoublePTLock 失败!</translation>
    </message>
    <message>
        <source>VAdjustDistributing:GetBusbarIsUseQLimit failed!</source>
        <translation type="obsolete">VAdjustDistributing:GetBusbarIsUseQLimit 失败!</translation>
    </message>
    <message>
        <source>VAdjustDistributing:GetBusbarPlanQUplimit failed!</source>
        <translation type="obsolete">VAdjustDistributing:GetBusbarPlanQUplimit 失败!</translation>
    </message>
    <message>
        <source>VAdjustDistributing:GetBusbarPlanQDownlimit failed!</source>
        <translation type="obsolete">VAdjustDistributing:GetBusbarPlanQDownlimit 失败!</translation>
    </message>
</context>
<context>
    <name>GENERATOR_AGC_LOCK</name>
    <message>
        <location filename="qgeneratorlock.cpp" line="323"/>
        <source>locktype error</source>
        <translation>闭锁类型错误</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="main.cpp" line="70"/>
        <source>a same pplation is running!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="78"/>
        <location filename="main.cpp" line="106"/>
        <source>Failed to connect to driver!</source>
        <translation>连接驱动失败!</translation>
    </message>
    <message>
        <location filename="main.cpp" line="82"/>
        <location filename="main.cpp" line="97"/>
        <location filename="main.cpp" line="110"/>
        <location filename="main.cpp" line="124"/>
        <source>data source has been reseted.please restart the application!</source>
        <translation>数据源重置，重启生效!</translation>
    </message>
    <message>
        <location filename="main.cpp" line="93"/>
        <source>Failed to open database!</source>
        <translation>打开数据库失败!</translation>
    </message>
    <message>
        <location filename="main.cpp" line="120"/>
        <source>Failed to open His database!</source>
        <translation>打开历史数据库失败！</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <location filename="warninfoqueryselectdialog.ui" line="14"/>
        <source>MainWindow</source>
        <translation>发电厂有功功率调节器</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="32"/>
        <source>System</source>
        <translation>系统</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="45"/>
        <source>RealData</source>
        <translation>实时数据</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="56"/>
        <source>SourceCode</source>
        <translation>源码</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="65"/>
        <source>Control</source>
        <translation>控制</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="75"/>
        <source>Monitor</source>
        <translation>监视</translation>
    </message>
    <message>
        <source>History</source>
        <translation type="obsolete">历史</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="81"/>
        <source>HisData</source>
        <translation>历史数据</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="90"/>
        <source>RealCurve</source>
        <translation>实时曲线</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="99"/>
        <source>Hiscurve</source>
        <translation>历史曲线</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="108"/>
        <source>View</source>
        <translation>视图</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="649"/>
        <source>Tool Bar</source>
        <translation>工具条</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="128"/>
        <source>Info Bar</source>
        <translation>报警信息</translation>
    </message>
    <message>
        <source>toolBar</source>
        <translation type="obsolete">工具栏</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="673"/>
        <source>MainPage</source>
        <translation>主页</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="682"/>
        <source>DataSource</source>
        <translation>数据源设置</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="691"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="700"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="709"/>
        <location filename="mainwindow.ui" line="829"/>
        <source>Yc</source>
        <translation>遥测</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="718"/>
        <location filename="mainwindow.ui" line="838"/>
        <source>Yx</source>
        <translation>遥信</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="727"/>
        <source>Dd</source>
        <translation>电度</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="736"/>
        <location filename="mainwindow.ui" line="793"/>
        <source>Yk</source>
        <translation>遥控</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="745"/>
        <location filename="mainwindow.ui" line="802"/>
        <source>Yt</source>
        <translation>遥调</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="754"/>
        <source>Select</source>
        <translation>选择</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="757"/>
        <source>CodeSelect</source>
        <translation>源码选择</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="766"/>
        <source>DisPlay</source>
        <translation>显示</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="775"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="784"/>
        <source>Refresh</source>
        <translation>刷新</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="811"/>
        <source>Chunnel</source>
        <translation>通道</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="820"/>
        <source>ParameteConfig</source>
        <translation>参数配置</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="847"/>
        <source>warn_info</source>
        <translation>报警记录查询</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="856"/>
        <source>adjust_info</source>
        <translation>调整信息查询</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="865"/>
        <source>his_curve</source>
        <translation>机组数据查询</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="874"/>
        <source>his_curve_sv</source>
        <translation>母线数据查询</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="879"/>
        <location filename="mainwindow.ui" line="882"/>
        <source>Factory Volt</source>
        <translation>厂用电</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="891"/>
        <source>Busbarp</source>
        <translation>母线有功</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="900"/>
        <source>Generatorp</source>
        <translation>机组有功</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="909"/>
        <source>busbar p</source>
        <translation>母线有功</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="918"/>
        <source>generator p</source>
        <translation>机组有功</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="991"/>
        <source>TestFitting</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1000"/>
        <source>generator thermal</source>
        <translation>机组热功率</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1009"/>
        <source>generator coal</source>
        <translation>机组煤耗</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1018"/>
        <source>Clear Alarm</source>
        <translation>清除告警</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1027"/>
        <source>GenThermal</source>
        <translation>机组热功率</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1036"/>
        <location filename="mainwindow.ui" line="1041"/>
        <source>GenCoal</source>
        <translation>机组煤耗</translation>
    </message>
    <message>
        <source>BusbarV</source>
        <translation type="obsolete">母线电压</translation>
    </message>
    <message>
        <source>GeneratorQ</source>
        <translation type="obsolete">机组无功</translation>
    </message>
    <message>
        <source>busbar Volt</source>
        <oldsource>busbar</oldsource>
        <translation type="obsolete">母线电压</translation>
    </message>
    <message>
        <source>generator Reactive Power</source>
        <translation type="obsolete">机组无功</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="945"/>
        <source>Cascad</source>
        <translation>层叠</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="950"/>
        <source>Title</source>
        <translation>平铺</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="959"/>
        <location filename="mainwindow.ui" line="968"/>
        <source>Ys</source>
        <translation>遥设</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="977"/>
        <source>ManualSetYes</source>
        <translation>人工设定确定</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="986"/>
        <source>Clear Lock</source>
        <translation>清除闭锁</translation>
    </message>
    <message>
        <source>generator</source>
        <translation type="obsolete">机组</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="929"/>
        <source>warnInfoVisble</source>
        <translation>告警信息可见</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="940"/>
        <source>toolBarVisble</source>
        <translation>工具条可见</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="78"/>
        <source>Main Page</source>
        <translation>主页</translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="obsolete">输出</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="113"/>
        <source>Heat agc system start </source>
        <translation>火力发电厂电压有功功率控制系统启动 </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="82"/>
        <source>warninfo</source>
        <translation>调整信息</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="158"/>
        <source>Main page</source>
        <translation>主页</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="168"/>
        <source>data source has been reseted.please restart the application!</source>
        <translation>数据源重置，重启生效!</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="195"/>
        <source>Yc search</source>
        <oldsource>Yc search%1</oldsource>
        <translation>遥测查询</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="218"/>
        <source>Yx search</source>
        <oldsource>Yx search %1</oldsource>
        <translation>遥信查询</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="240"/>
        <source>Dd search</source>
        <oldsource>Dd search %1</oldsource>
        <translation>电度查询</translation>
    </message>
    <message>
        <source>Js search %1</source>
        <translation type="obsolete">计算量查询%1</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="265"/>
        <source>User Picture</source>
        <oldsource>User Picture %1</oldsource>
        <translation>用户图形</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="284"/>
        <source>Yk search</source>
        <oldsource>Yk search %1</oldsource>
        <translation>遥控查询</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="300"/>
        <source>Yt search</source>
        <oldsource>Yt search %1</oldsource>
        <translation>遥调查询</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="316"/>
        <source>Ys search</source>
        <translation>遥设查询</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="336"/>
        <location filename="mainwindow.cpp" line="378"/>
        <location filename="mainwindow.cpp" line="401"/>
        <location filename="mainwindow.cpp" line="423"/>
        <location filename="mainwindow.cpp" line="444"/>
        <location filename="mainwindow.cpp" line="462"/>
        <location filename="mainwindow.cpp" line="481"/>
        <location filename="mainwindow.cpp" line="502"/>
        <location filename="mainwindow.cpp" line="522"/>
        <location filename="mainwindow.cpp" line="542"/>
        <source>mainwindows information</source>
        <translation>窗口信息</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="336"/>
        <location filename="mainwindow.cpp" line="378"/>
        <location filename="mainwindow.cpp" line="401"/>
        <location filename="mainwindow.cpp" line="423"/>
        <location filename="mainwindow.cpp" line="444"/>
        <location filename="mainwindow.cpp" line="462"/>
        <location filename="mainwindow.cpp" line="481"/>
        <location filename="mainwindow.cpp" line="502"/>
        <location filename="mainwindow.cpp" line="522"/>
        <location filename="mainwindow.cpp" line="542"/>
        <source>This function used only in main server</source>
        <translation>此功能只能在主机使用</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="357"/>
        <source>Origin Code</source>
        <translation>源码</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="449"/>
        <location filename="mainwindow.cpp" line="467"/>
        <location filename="mainwindow.cpp" line="486"/>
        <location filename="mainwindow.cpp" line="507"/>
        <location filename="mainwindow.cpp" line="528"/>
        <location filename="mainwindow.cpp" line="559"/>
        <location filename="mainwindow.cpp" line="1267"/>
        <location filename="mainwindow.cpp" line="1273"/>
        <location filename="mainwindow.cpp" line="1290"/>
        <location filename="mainwindow.cpp" line="1312"/>
        <location filename="mainwindow.cpp" line="1318"/>
        <location filename="mainwindow.cpp" line="1335"/>
        <location filename="mainwindow.cpp" line="1355"/>
        <location filename="mainwindow.cpp" line="1361"/>
        <location filename="mainwindow.cpp" line="1378"/>
        <source>AGC</source>
        <translation>登录</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="449"/>
        <location filename="mainwindow.cpp" line="467"/>
        <location filename="mainwindow.cpp" line="486"/>
        <location filename="mainwindow.cpp" line="507"/>
        <location filename="mainwindow.cpp" line="528"/>
        <location filename="mainwindow.cpp" line="559"/>
        <location filename="mainwindow.cpp" line="1267"/>
        <location filename="mainwindow.cpp" line="1312"/>
        <location filename="mainwindow.cpp" line="1355"/>
        <location filename="mainwindow.cpp" line="1399"/>
        <location filename="mainwindow.cpp" line="1417"/>
        <location filename="mainwindow.cpp" line="1434"/>
        <location filename="mainwindow.cpp" line="1451"/>
        <source>Please login first!</source>
        <translation>请先登录！</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="568"/>
        <source>manu set</source>
        <translation>人工设定</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="822"/>
        <source>YX Changed</source>
        <translation>遥信变为</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="825"/>
        <source>Close!</source>
        <translation>合!</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="829"/>
        <location filename="mainwindow.cpp" line="856"/>
        <source>Open!</source>
        <translation>分!</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="836"/>
        <source>	Sub station number:%1,	YX number:%2,	YX name:%3.</source>
        <translation>	子站编号:%1,	遥信编号:%2,	遥信名称:%3.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="904"/>
        <source>Application exit,Operator:</source>
        <translation>应用退出，操作员：</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1096"/>
        <source>user exit</source>
        <translation>用户退出</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1122"/>
        <location filename="mainwindow.cpp" line="1162"/>
        <source>user login</source>
        <translation>用户登录</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1221"/>
        <source>alarm state is cleared!</source>
        <translation>告警状态清除！</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1273"/>
        <source>Factory AGC Put Off,If Execute!</source>
        <translation>厂用电AGC退出,是否执行?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1285"/>
        <source>Factory AGC Put Off,operator </source>
        <translation>厂用电AGC退出，操作员</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1290"/>
        <source>Factory AGC Put On,If Execute!</source>
        <translation>厂用电AGC投入,是否执行?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1302"/>
        <location filename="mainwindow.cpp" line="1390"/>
        <source>Factory AGC Put On,operator </source>
        <translation>厂用电AGC投入，操作员</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1318"/>
        <source>Generator AGC Put Off,If Execute!</source>
        <translation>机组AGC退出,是否执行?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1330"/>
        <source>Generator AGC Put Off,operator </source>
        <translation>机组AGC退出，操作员</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1335"/>
        <source>Generator AGC Put On,If Execute!</source>
        <translation>机组AGC投入,是否执行?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1347"/>
        <source>Generator AGC Put On,operator </source>
        <translation>机组AGC投入，操作员</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1361"/>
        <source>Boiler AGC Put Off,If Execute!</source>
        <translation>锅炉AGC退出,是否执行?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1373"/>
        <source>Boiler AGC Put Off,operator </source>
        <translation>锅炉AGC退出，操作员</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1378"/>
        <source>Boiler AGC Put On,If Execute!</source>
        <translation>锅炉AGC投入,是否执行?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1399"/>
        <location filename="mainwindow.cpp" line="1404"/>
        <location filename="mainwindow.cpp" line="1417"/>
        <location filename="mainwindow.cpp" line="1422"/>
        <location filename="mainwindow.cpp" line="1434"/>
        <location filename="mainwindow.cpp" line="1438"/>
        <location filename="mainwindow.cpp" line="1451"/>
        <location filename="mainwindow.cpp" line="1454"/>
        <source>AGC?</source>
        <translation>提示</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1404"/>
        <source>BUS Put On,If Execute!</source>
        <translation>MEGC投入,是否执行?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1422"/>
        <source>BUS Put Off,If Execute!</source>
        <translation>MEGC退出,是否执行?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1438"/>
        <source>AGC Put On,If Execute!</source>
        <translation>MEGC允许调节,是否执行?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1454"/>
        <source>AGC Put Off,If Execute!</source>
        <translation>MEGC禁止调节,是否执行?</translation>
    </message>
    <message>
        <source>	Sub station number:%1,	YX number:%2,	YX name:%3。</source>
        <translation type="obsolete">	子站编号:%1,	遥信编号:%2,	遥信名称:%3。</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="852"/>
        <source>Close</source>
        <translation>合</translation>
    </message>
    <message>
        <source>System exit! operater:</source>
        <translation type="obsolete">系统退出!操作员:</translation>
    </message>
    <message>
        <location filename="warninfoqueryselectdialog.ui" line="27"/>
        <location filename="warninfoqueryselectdialog.ui" line="40"/>
        <source>yyyy/MM/dd hh:mm:ss</source>
        <translation></translation>
    </message>
    <message>
        <location filename="warninfoqueryselectdialog.ui" line="53"/>
        <source>start time</source>
        <translation>起始时间</translation>
    </message>
    <message>
        <location filename="warninfoqueryselectdialog.ui" line="66"/>
        <source>End Time</source>
        <translation>结束时间</translation>
    </message>
</context>
<context>
    <name>ManualSetPageAvcInfo</name>
    <message>
        <source>Dialog</source>
        <translation type="obsolete">数据源设置</translation>
    </message>
    <message>
        <source>AVC SUbstation Start/exit</source>
        <translation type="obsolete">AVC子站投退</translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="obsolete">投入</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation type="obsolete">退出</translation>
    </message>
    <message>
        <source>Plan</source>
        <translation type="obsolete">计划</translation>
    </message>
    <message>
        <source>Total Factory</source>
        <translation type="obsolete">全厂</translation>
    </message>
    <message>
        <source>Single Generator</source>
        <translation type="obsolete">单机</translation>
    </message>
    <message>
        <source>Control Model</source>
        <translation type="obsolete">控制模式</translation>
    </message>
    <message>
        <source>Close Loop</source>
        <translation type="obsolete">闭环</translation>
    </message>
    <message>
        <source>Open Loop</source>
        <translation type="obsolete">开环</translation>
    </message>
    <message>
        <source>Semi Close Loop</source>
        <translation type="obsolete">半闭环</translation>
    </message>
</context>
<context>
    <name>QManualSetSheetDialog</name>
    <message>
        <source>Factory Volt A</source>
        <translation type="obsolete">厂用电A段</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="14"/>
        <source>Manu Setting</source>
        <translation>人工设定</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="26"/>
        <location filename="manualsetsheetdialog.ui" line="174"/>
        <location filename="manualsetsheetdialog.ui" line="859"/>
        <location filename="manualsetsheetdialog.ui" line="1773"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="46"/>
        <source>Total Control Parameter</source>
        <translation>总控参数</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="58"/>
        <source>Control Model</source>
        <translation>控制模式</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="70"/>
        <source>Close Loop</source>
        <translation>闭环</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="83"/>
        <source>Open Loop</source>
        <translation>开环</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="96"/>
        <source>Semi Close Loop</source>
        <translation>半闭环</translation>
    </message>
    <message>
        <source>AVC Substation Start/Exit</source>
        <translation type="obsolete">AVC子站投退</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="161"/>
        <location filename="manualsetsheetdialog.ui" line="846"/>
        <location filename="manualsetsheetdialog.ui" line="1760"/>
        <source>Start</source>
        <translation>投入</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="110"/>
        <source>Plan</source>
        <translation>计划</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="122"/>
        <source>Total Factory</source>
        <translation>全厂</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="135"/>
        <source>Single Generator</source>
        <translation>单机</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="149"/>
        <source>AGC Substation Start/Exit</source>
        <translation>MEGC允许调节</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="216"/>
        <source>upDeadLimitP</source>
        <translation>有功死区上限</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="229"/>
        <source>maxAdjustCount</source>
        <translation>最大调节次数</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="262"/>
        <location filename="manualsetsheetdialog.ui" line="308"/>
        <location filename="manualsetsheetdialog.ui" line="494"/>
        <location filename="manualsetsheetdialog.ui" line="507"/>
        <location filename="manualsetsheetdialog.ui" line="520"/>
        <location filename="manualsetsheetdialog.ui" line="546"/>
        <location filename="manualsetsheetdialog.ui" line="559"/>
        <location filename="manualsetsheetdialog.ui" line="641"/>
        <location filename="manualsetsheetdialog.ui" line="886"/>
        <location filename="manualsetsheetdialog.ui" line="986"/>
        <location filename="manualsetsheetdialog.ui" line="1022"/>
        <location filename="manualsetsheetdialog.ui" line="1071"/>
        <location filename="manualsetsheetdialog.ui" line="1501"/>
        <location filename="manualsetsheetdialog.ui" line="1514"/>
        <location filename="manualsetsheetdialog.ui" line="1527"/>
        <location filename="manualsetsheetdialog.ui" line="1540"/>
        <location filename="manualsetsheetdialog.ui" line="1553"/>
        <location filename="manualsetsheetdialog.ui" line="1566"/>
        <source>MW</source>
        <translation>MW</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="275"/>
        <location filename="manualsetsheetdialog.ui" line="1009"/>
        <location filename="manualsetsheetdialog.ui" line="1337"/>
        <source>singleMaxDeltaP</source>
        <translation>单次最大有功增量</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="321"/>
        <source>downDeadLimitP</source>
        <translation>有功死区下限</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="334"/>
        <source>adjustWaitTime</source>
        <translation>调节等待时间</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="370"/>
        <source>minuteMaxDeltaP</source>
        <translation>有功每分钟最大增量</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="405"/>
        <location filename="manualsetsheetdialog.ui" line="758"/>
        <location filename="manualsetsheetdialog.ui" line="1119"/>
        <location filename="manualsetsheetdialog.ui" line="1197"/>
        <location filename="manualsetsheetdialog.ui" line="1598"/>
        <source>target value</source>
        <translation>目标值</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="418"/>
        <location filename="manualsetsheetdialog.ui" line="771"/>
        <location filename="manualsetsheetdialog.ui" line="1132"/>
        <location filename="manualsetsheetdialog.ui" line="1210"/>
        <location filename="manualsetsheetdialog.ui" line="1605"/>
        <source>increment</source>
        <translation>增量</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="432"/>
        <source>OverCount</source>
        <translation>连续进入死区次数</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="746"/>
        <location filename="manualsetsheetdialog.ui" line="1592"/>
        <source>planType</source>
        <translation>计划类型</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="811"/>
        <source>AdjustProrate</source>
        <translation>固定比例分配占比</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="834"/>
        <source>GEN Start/Exit</source>
        <translation>机组投/退</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="873"/>
        <source>setpower</source>
        <translation>设定负荷</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="909"/>
        <source>adjustpower</source>
        <translation>单机定负荷调整</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="922"/>
        <location filename="manualsetsheetdialog.ui" line="1237"/>
        <location filename="manualsetsheetdialog.ui" line="1735"/>
        <source>lock</source>
        <translation>自定义闭锁</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1478"/>
        <source>tenminuteMaxDeltaP</source>
        <translation>有功每十分钟最大增量</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1646"/>
        <source>averivage increment</source>
        <translation>增量平均</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1659"/>
        <source>ratio increment</source>
        <translation>增量与余量成比例</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1672"/>
        <source>Fixed proportion</source>
        <translation>按固定比例分配</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1748"/>
        <source>Busbar Start/Exit</source>
        <translation>母线MEGC投/退</translation>
    </message>
    <message>
        <source>average target</source>
        <translation type="obsolete">目标平均</translation>
    </message>
    <message>
        <source>ratio target</source>
        <translation type="obsolete">目标与容量成比例</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1686"/>
        <source>If Optimize</source>
        <translation>是否优化</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1722"/>
        <source>maxCommandInterval</source>
        <translation>最大指令间隔</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="455"/>
        <source>outputType</source>
        <translation>输出类型</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="467"/>
        <location filename="manualsetsheetdialog.ui" line="1158"/>
        <source>ys</source>
        <translation>遥设（数字）</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="480"/>
        <location filename="manualsetsheetdialog.ui" line="1171"/>
        <source>yt</source>
        <translation>遥调（脉冲）</translation>
    </message>
    <message>
        <source>ratingCos</source>
        <translation type="obsolete">额定功率因数</translation>
    </message>
    <message>
        <source>linkReactance</source>
        <translation type="obsolete">联系电抗</translation>
    </message>
    <message>
        <source>shortReactance</source>
        <translation type="obsolete">短路阻抗</translation>
    </message>
    <message>
        <source>synReactance</source>
        <translation type="obsolete">同步阻抗</translation>
    </message>
    <message>
        <source>maxStatorVolt</source>
        <translation type="obsolete">定子电压最大值</translation>
    </message>
    <message>
        <source>maxStatorCurrent</source>
        <translation type="obsolete">定子电流最大值</translation>
    </message>
    <message>
        <source>ratingStatorVolt</source>
        <translation type="obsolete">转子电压额定值</translation>
    </message>
    <message>
        <source>ratingStatorCurrent</source>
        <translation type="obsolete">定子电流额定值</translation>
    </message>
    <message>
        <source>ratingRotorVolt</source>
        <translation type="obsolete">转子电压额定值</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="572"/>
        <source>ratingPPower</source>
        <translation>有功功率额定值</translation>
    </message>
    <message>
        <source>maxRotorCurrent</source>
        <translation type="obsolete">转子电流最大值</translation>
    </message>
    <message>
        <source>maxRotorVolt</source>
        <translation type="obsolete">转子电压最大值</translation>
    </message>
    <message>
        <source>ratingQPower</source>
        <translation type="obsolete">无功功率额定值</translation>
    </message>
    <message>
        <source>ratingRotorCurrent</source>
        <translation type="obsolete">转子电流额定值</translation>
    </message>
    <message>
        <source>maxDelta</source>
        <translation type="obsolete">最大功角</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="533"/>
        <source>maxPPower</source>
        <translation>有功功率最大值</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="585"/>
        <source>minPPower</source>
        <translation>有功功率最小值</translation>
    </message>
    <message>
        <source>maxQPower</source>
        <translation type="obsolete">无功功率最大值</translation>
    </message>
    <message>
        <source>minQPower</source>
        <translation type="obsolete">无功功率最小值</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1304"/>
        <source>TargetMAX</source>
        <translation>目标最大值</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1383"/>
        <source>StartChangeSleep</source>
        <translation>投入后等待时间</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1396"/>
        <source>workStatusChangeSleep</source>
        <translation>远方就地切换后分配等待时间</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1419"/>
        <source>TargetMIN</source>
        <translation>目标最小值</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1442"/>
        <source>DownDeadLimit</source>
        <translation>死区下限</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1465"/>
        <source>UpDeadLimit</source>
        <translation>死区上限</translation>
    </message>
    <message>
        <source>basicMode</source>
        <translation type="obsolete">基本功率模式</translation>
    </message>
    <message>
        <source>ssgl</source>
        <translation type="obsolete">实时功率</translation>
    </message>
    <message>
        <source>jhkz</source>
        <translation type="obsolete">计划控制</translation>
    </message>
    <message>
        <source>rgjh</source>
        <translation type="obsolete">人工基荷调节</translation>
    </message>
    <message>
        <source>ssdd</source>
        <translation type="obsolete">实时调度调节</translation>
    </message>
    <message>
        <source>dtjbl</source>
        <translation type="obsolete">等调节比例</translation>
    </message>
    <message>
        <source>fhyc</source>
        <translation type="obsolete">负荷预测</translation>
    </message>
    <message>
        <source>dmgz</source>
        <translation type="obsolete">断面跟踪</translation>
    </message>
    <message>
        <source>ycjd</source>
        <translation type="obsolete">遥测基点</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1185"/>
        <source>AdjustMode</source>
        <translation>调节模式</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="928"/>
        <source>Boiler Parameter</source>
        <translation>锅炉参数</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="940"/>
        <source>Select Boiler</source>
        <translation>选择锅炉</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="973"/>
        <source>RatingPower</source>
        <translation>额定有功</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="654"/>
        <location filename="manualsetsheetdialog.ui" line="1035"/>
        <source>singleMinDeltaP</source>
        <translation>单次最小有功增量</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="628"/>
        <location filename="manualsetsheetdialog.ui" line="1224"/>
        <location filename="manualsetsheetdialog.ui" line="1621"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="677"/>
        <source>CoalCoefficent2</source>
        <translation>煤系数2</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="700"/>
        <source>CoalCoefficent1</source>
        <translation>煤系数1</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="723"/>
        <source>CoalCoefficent0</source>
        <translation>煤系数0</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1084"/>
        <source>AdjustWaitTime</source>
        <translation>调节等待时间</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1107"/>
        <source>BoilerType</source>
        <translation>锅炉类型</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1146"/>
        <source>OutputMode</source>
        <translation>输出方式</translation>
    </message>
    <message>
        <source>Straight Condensing</source>
        <translation type="obsolete">纯凝</translation>
    </message>
    <message>
        <source>Heating Supply</source>
        <translation type="obsolete">供热</translation>
    </message>
    <message>
        <source>Peak-load Regulation</source>
        <translation type="obsolete">调峰</translation>
    </message>
    <message>
        <source>normalAdjust</source>
        <translation type="obsolete">正常调节</translation>
    </message>
    <message>
        <source>nonAdjust</source>
        <translation type="obsolete">不调节</translation>
    </message>
    <message>
        <source>urgentAdjust</source>
        <translation type="obsolete">紧急调节</translation>
    </message>
    <message>
        <source>secondary</source>
        <translation type="obsolete">次紧急调节</translation>
    </message>
    <message>
        <source>pMAX</source>
        <translation type="obsolete">最大有功</translation>
    </message>
    <message>
        <source>pMIN</source>
        <translation type="obsolete">最小有功</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1634"/>
        <source>distributeMethod</source>
        <translation>分配方式</translation>
    </message>
    <message>
        <source>Equal cos</source>
        <translation type="obsolete">等功率因数</translation>
    </message>
    <message>
        <source>Equal increment rate</source>
        <translation type="obsolete">等微增率（需变压器参数）</translation>
    </message>
    <message>
        <source> equal distribution</source>
        <translation type="obsolete">平均分配</translation>
    </message>
    <message>
        <source>Proportional to capacity</source>
        <translation type="obsolete">与容量成比例</translation>
    </message>
    <message>
        <source>vGrade</source>
        <translation type="obsolete">电压等级</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1789"/>
        <source>Confirm Modify</source>
        <translation>确认修改</translation>
    </message>
    <message>
        <source>CallbackMode</source>
        <translation type="obsolete">回调方式</translation>
    </message>
    <message>
        <source>notCallBack</source>
        <translation type="obsolete">不回调</translation>
    </message>
    <message>
        <source>jddyCallBack</source>
        <translation type="obsolete">机端电压越限回调</translation>
    </message>
    <message>
        <source>ReactivePowerBack</source>
        <translation type="obsolete">无功越限回调</translation>
    </message>
    <message>
        <source>sysVUpDownCallBack</source>
        <translation type="obsolete">系统电压越上下限</translation>
    </message>
    <message>
        <source>sysVUpUpDownDownCallBack</source>
        <translation type="obsolete">系统电压越合理限</translation>
    </message>
    <message>
        <source>Adjuster Parameter</source>
        <translation type="obsolete">调节参数</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="193"/>
        <source>Select Generator</source>
        <translation>机组选择</translation>
    </message>
    <message>
        <source>Lock Setting</source>
        <translation type="obsolete">闭锁设置</translation>
    </message>
    <message>
        <source>RTU无功误差(KVar)</source>
        <translation type="obsolete">RTU无功误差(KVar)</translation>
    </message>
    <message>
        <source>Lower Limit</source>
        <translation type="obsolete">下限</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <translation type="obsolete">上限</translation>
    </message>
    <message>
        <source>Continue step in dead limit count</source>
        <translation type="obsolete">连续进入死区次数</translation>
    </message>
    <message>
        <source>Max Ajust count limit</source>
        <translation type="obsolete">最大调节次数限制</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="357"/>
        <location filename="manualsetsheetdialog.ui" line="1048"/>
        <location filename="manualsetsheetdialog.ui" line="1360"/>
        <location filename="manualsetsheetdialog.ui" line="1579"/>
        <location filename="manualsetsheetdialog.ui" line="1709"/>
        <source>Second</source>
        <translation>秒</translation>
    </message>
    <message>
        <source>RTU Download Waiting Interval</source>
        <translation type="obsolete">RTU下发指令等待时间</translation>
    </message>
    <message>
        <source>RTU Fault Waiting Interval</source>
        <translation type="obsolete">RTU错误等待时间</translation>
    </message>
    <message>
        <source>Adjusting Waiting Interval</source>
        <translation type="obsolete">调节等待时间</translation>
    </message>
    <message>
        <source>PQ Valid Scope</source>
        <translation type="obsolete">PQ有效范围</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="obsolete">确定</translation>
    </message>
    <message>
        <source>Plan Reactive Power</source>
        <translation type="obsolete">计划无功</translation>
    </message>
    <message>
        <source>Stator Volt</source>
        <translation type="obsolete">定子电压</translation>
    </message>
    <message>
        <source>Up Up Limit</source>
        <oldsource>Up Up Limit Lock</oldsource>
        <translation type="obsolete">上上限</translation>
    </message>
    <message>
        <source>Up Adjustable/down inadjustable</source>
        <translation type="obsolete">允许上调/禁止下调</translation>
    </message>
    <message>
        <source>Down Down Limit</source>
        <oldsource>Down Down Limit Lock</oldsource>
        <translation type="obsolete">下下限</translation>
    </message>
    <message>
        <source>Up Inadjustable/Down Adjustable</source>
        <translation type="obsolete">禁止上调/允许下调</translation>
    </message>
    <message>
        <source>Factory Volt</source>
        <translation type="obsolete">厂用电</translation>
    </message>
    <message>
        <source>Up Adjustable/Down Inadjustable</source>
        <translation type="obsolete">允许上调/禁止下调</translation>
    </message>
    <message>
        <source>机组无功误差(KVar)</source>
        <translation type="obsolete">机组无功误差(KVar)</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <translation type="obsolete">下限</translation>
    </message>
    <message>
        <source>Rotor Current</source>
        <translation type="obsolete">转子电流</translation>
    </message>
    <message>
        <source>Up Adjustable/Down inadjustable</source>
        <translation type="obsolete">允许上调/禁止下调</translation>
    </message>
    <message>
        <source>Stator Current</source>
        <translation type="obsolete">定子电流</translation>
    </message>
    <message>
        <source>Active Power Up Inadjustable/Down Adjustable</source>
        <translation type="obsolete">有功禁止上调/语允许下调</translation>
    </message>
    <message>
        <source>Active Power Up Up Limit Lock</source>
        <translation type="obsolete">有功上上限闭锁</translation>
    </message>
    <message>
        <source>Active Power Down Down Limit Lock</source>
        <translation type="obsolete">有功下下限闭锁</translation>
    </message>
    <message>
        <source>Reactive Power UpUP Limit Lock</source>
        <translation type="obsolete">无功上上限闭锁</translation>
    </message>
    <message>
        <source>Reactive Power Up Adjustable/Down inadjustable</source>
        <translation type="obsolete">无功允许上调/禁止下调</translation>
    </message>
    <message>
        <source>Reactive Power DownDown Limit Lock</source>
        <translation type="obsolete">无功下下限闭锁</translation>
    </message>
    <message>
        <source>Reactive Power Up Inadjustable/Down Adjustable</source>
        <translation type="obsolete">无功禁止上调/允许下调</translation>
    </message>
    <message>
        <source>Single Max Delta Reactive Power</source>
        <translation type="obsolete">单次最大无功增量</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="393"/>
        <source>Adjust Type</source>
        <oldsource>Adjust Model</oldsource>
        <translation>调节模式</translation>
    </message>
    <message>
        <source>Volt</source>
        <translation type="obsolete">电压</translation>
    </message>
    <message>
        <source>Reactive Power</source>
        <translation type="obsolete">无功</translation>
    </message>
    <message>
        <source>Up UP Limit</source>
        <translation type="obsolete">上上限</translation>
    </message>
    <message>
        <source>if use double mesure</source>
        <translation type="obsolete">是否使用双量测</translation>
    </message>
    <message>
        <source>Confirm modify</source>
        <translation type="obsolete">确认修改</translation>
    </message>
    <message>
        <source>Factory Volt B</source>
        <translation type="obsolete">厂用电B段</translation>
    </message>
    <message>
        <source>second measurement is set as the main measure</source>
        <translation type="obsolete">是否使用第二量测为主量测</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="181"/>
        <source>Generator Parameter</source>
        <translation>机组参数</translation>
    </message>
    <message>
        <source>First Point</source>
        <translation type="obsolete">第一点</translation>
    </message>
    <message>
        <source>Fourth Point</source>
        <translation type="obsolete">第四点</translation>
    </message>
    <message>
        <source>Second Point</source>
        <translation type="obsolete">第二点</translation>
    </message>
    <message>
        <source>Third Point</source>
        <translation type="obsolete">第三点</translation>
    </message>
    <message>
        <source> segmentation number between 1 and 2 Point</source>
        <translation type="obsolete">1、2点之间的分段数</translation>
    </message>
    <message>
        <source>segmentation number between 2 and 3 Point</source>
        <translation type="obsolete">2、3点之间的分段数</translation>
    </message>
    <message>
        <source>segmentation number between 3 and 4 Point</source>
        <translation type="obsolete">3、4点之间的分段数</translation>
    </message>
    <message>
        <source>Rating Factory Volt A</source>
        <translation type="obsolete">额定厂用电压</translation>
    </message>
    <message>
        <source>synchronous reactance</source>
        <translation type="obsolete">同步电抗</translation>
    </message>
    <message>
        <source>Connected reactance</source>
        <translation type="obsolete">联系电抗</translation>
    </message>
    <message>
        <source>Rating Stator Volt</source>
        <translation type="obsolete">额定定子电压</translation>
    </message>
    <message>
        <source>Rator Stator Current</source>
        <translation type="obsolete">额定定子电流</translation>
    </message>
    <message>
        <source>Rating Rotor Volt</source>
        <translation type="obsolete">额定转子电压</translation>
    </message>
    <message>
        <source>Rating Rotor Current</source>
        <translation type="obsolete">额定转子电流</translation>
    </message>
    <message>
        <source>Rating Cos</source>
        <translation type="obsolete">额定功率因数</translation>
    </message>
    <message>
        <source>Min Active Power</source>
        <translation type="obsolete">最小有功</translation>
    </message>
    <message>
        <source>Rating Reactive Power</source>
        <translation type="obsolete">额定无功</translation>
    </message>
    <message>
        <source>Rating Active Power</source>
        <translation type="obsolete">额定有功</translation>
    </message>
    <message>
        <source>Degree</source>
        <translation type="obsolete">度</translation>
    </message>
    <message>
        <source>Max Active Power</source>
        <translation type="obsolete">最大有功</translation>
    </message>
    <message>
        <source>Max power angle</source>
        <translation type="obsolete">最大功角</translation>
    </message>
    <message>
        <source>QTIME</source>
        <translation type="obsolete">无功脉冲</translation>
    </message>
    <message>
        <source>PQLIMIT</source>
        <translation type="obsolete">有功-无功上下限</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1243"/>
        <source>Busbar Parameter</source>
        <translation>母线参数</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1265"/>
        <source>Select Busbar</source>
        <translation>母线选择</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="785"/>
        <location filename="manualsetsheetdialog.ui" line="1278"/>
        <source>Use Local Plan Curve</source>
        <translation>使用就地曲线</translation>
    </message>
    <message>
        <source>Busbar Double Mesure Alarm</source>
        <translation type="obsolete">母线双量测报警</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.ui" line="1291"/>
        <source>Main Busbar</source>
        <translation>主母线</translation>
    </message>
    <message>
        <source>Use Reactive Power Up/Down Limit</source>
        <translation type="obsolete">使用无功上下限</translation>
    </message>
    <message>
        <source>Close Loop Double PTAlarm</source>
        <translation type="obsolete">合环双PT报警</translation>
    </message>
    <message>
        <source>Use Double Mesure</source>
        <translation type="obsolete">使用双量测</translation>
    </message>
    <message>
        <source>Volt Curve Modify</source>
        <translation type="obsolete">电压曲线修改</translation>
    </message>
    <message>
        <source>Display</source>
        <translation type="obsolete">显示</translation>
    </message>
    <message>
        <source>31days Plan Curve</source>
        <translation type="obsolete">31天计划曲线</translation>
    </message>
    <message>
        <source>Auto Read</source>
        <translation type="obsolete">自动读取</translation>
    </message>
    <message>
        <source>Dead Limit</source>
        <translation type="obsolete">死区</translation>
    </message>
    <message>
        <source>Distribute Mode</source>
        <translation type="obsolete">分配模式</translation>
    </message>
    <message>
        <source>Plan Type</source>
        <translation type="obsolete">计划类型</translation>
    </message>
    <message>
        <source>Busbar Volt Grade</source>
        <translation type="obsolete">母线电压等级</translation>
    </message>
    <message>
        <source>Volt UpUp Limit</source>
        <translation type="obsolete">电压上上限</translation>
    </message>
    <message>
        <source>Volt DownDown Limit</source>
        <translation type="obsolete">电压下下限</translation>
    </message>
    <message>
        <source>Single Max Delte Volt</source>
        <translation type="obsolete">单次最大电压增量</translation>
    </message>
    <message>
        <source>Close Loop Double PT Limit</source>
        <translation type="obsolete">合环双PT限制</translation>
    </message>
    <message>
        <source>Local to Remote Wait Interval</source>
        <translation type="obsolete">就地切远方等待时间</translation>
    </message>
    <message>
        <source>V_Q</source>
        <translation type="obsolete">电压-无功</translation>
    </message>
    <message>
        <source>Active Power</source>
        <translation type="obsolete">有功</translation>
    </message>
    <message>
        <source>VQ Table</source>
        <translation type="obsolete">VQ对照表</translation>
    </message>
    <message>
        <source>manual test ok!</source>
        <translation type="obsolete">人工测试OK!</translation>
    </message>
    <message>
        <source>agc_info:</source>
        <translation type="obsolete">AVC信息：</translation>
    </message>
    <message>
        <source> AvcStatus:</source>
        <translation type="obsolete">AVC状态：</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="270"/>
        <source>AGC_PARA:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="271"/>
        <source> AgcStatus:</source>
        <translation>AGC状态：</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="272"/>
        <source>, ControlMode:</source>
        <translation>，控制模式：</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="273"/>
        <source>, PlanMode:</source>
        <translation>，计划模式：</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="416"/>
        <location filename="manualsetsheetdialog.cpp" line="969"/>
        <location filename="manualsetsheetdialog.cpp" line="1137"/>
        <source>OnParaOkBtn</source>
        <translation>提示</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="440"/>
        <location filename="manualsetsheetdialog.cpp" line="1158"/>
        <source>GENERATOR:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="441"/>
        <source> generatorNum:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="442"/>
        <source>, adjustWaitTime:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="443"/>
        <source>, maxAdjustCount:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="445"/>
        <source>, upDeadLimitP:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="446"/>
        <source>, downDeadLimitP:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="447"/>
        <location filename="manualsetsheetdialog.cpp" line="986"/>
        <location filename="manualsetsheetdialog.cpp" line="1166"/>
        <source>, singleMaxDeltaP:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="449"/>
        <location filename="manualsetsheetdialog.cpp" line="1167"/>
        <source>, minuteMaxDeltaP:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="450"/>
        <location filename="manualsetsheetdialog.cpp" line="1164"/>
        <source>, planType:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="451"/>
        <source>, AdjustType:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="452"/>
        <source>, outputType:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="453"/>
        <source>, CoalCoefficent2:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="454"/>
        <source>, CoalCoefficent1:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="455"/>
        <source>, CoalCoefficent0:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="457"/>
        <source>, AdjustProrate:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="458"/>
        <source>, ratingPPower:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="459"/>
        <source>, maxPPower:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="460"/>
        <source>, minPPower:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="461"/>
        <source> ,GenRunningStatus:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="982"/>
        <source>BOILER:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="983"/>
        <source> BoilerNum:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="984"/>
        <source>, BoilerType:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="985"/>
        <source>, RatingPower:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="1175"/>
        <source>, maxCommandInterval:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="1263"/>
        <source>please enter the power!</source>
        <translation>请输入负荷调整固定值!</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="1279"/>
        <location filename="manualsetsheetdialog.cpp" line="1287"/>
        <location filename="manualsetsheetdialog.cpp" line="1297"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="1298"/>
        <source>CANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="448"/>
        <location filename="manualsetsheetdialog.cpp" line="987"/>
        <source>, singleMinDeltaP:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="36"/>
        <source>Chunnel Parameter</source>
        <translation>通道参数</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="162"/>
        <source>QManualSetSheetDialog</source>
        <translation>提示</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="269"/>
        <source>OnTotalControlChanged</source>
        <translation>提示</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="988"/>
        <source>, AdjustWaitTime:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="989"/>
        <source>, AdjustMode:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="990"/>
        <source>, OutputMode:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="1159"/>
        <source> busbarNum:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="1160"/>
        <source>, TargetMAX:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="1161"/>
        <source>, TargetMIN:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="1162"/>
        <source>, UpDeadLimit:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="1163"/>
        <source>, DownDeadLimit:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="1168"/>
        <source>, distributeMethod:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="1169"/>
        <source>, IsMainBusBar:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="456"/>
        <location filename="manualsetsheetdialog.cpp" line="1170"/>
        <source>, IsUseLocalCurve:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="1171"/>
        <source>, workStatusChangeSleep:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="1172"/>
        <source>, StartChangeSleep:</source>
        <translation></translation>
    </message>
    <message>
        <source>AdjustPara:</source>
        <translation type="obsolete">调节参数：</translation>
    </message>
    <message>
        <source> genNum:</source>
        <translation type="obsolete">机组编号：</translation>
    </message>
    <message>
        <source>, qValueMax:</source>
        <translation type="obsolete">，RTU上限死区：</translation>
    </message>
    <message>
        <source>, qValueMin:</source>
        <translation type="obsolete">，RTU下限死区：</translation>
    </message>
    <message>
        <source>, genQMax:</source>
        <translation type="obsolete">，机组无功上限死区：</translation>
    </message>
    <message>
        <source>, genQMin:</source>
        <translation type="obsolete">，机组无功下限死区：</translation>
    </message>
    <message>
        <source>, AdjustTime:</source>
        <translation type="obsolete">，调节等待时间：</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="444"/>
        <source>, OverCount:</source>
        <translation></translation>
    </message>
    <message>
        <source>, MaxCount:</source>
        <translation type="obsolete">，最大调整次数：</translation>
    </message>
    <message>
        <source>, RTUERRORWaitTime:</source>
        <translation type="obsolete">，RTU错误等待时间：</translation>
    </message>
    <message>
        <source>, RTUSENDDOWNWaitTime:</source>
        <translation type="obsolete">，RTU发送等待时间：</translation>
    </message>
    <message>
        <source>, vUpUpLimit:</source>
        <translation type="obsolete">，电压上上限：</translation>
    </message>
    <message>
        <source>, vDownDownLimit:</source>
        <translation type="obsolete">，电压下下限：</translation>
    </message>
    <message>
        <source>, SVLPUpUnAbleDownAble:</source>
        <translation type="obsolete">，定子电压上限：</translation>
    </message>
    <message>
        <source>, SVLPUpAbleDownUnAble:</source>
        <translation type="obsolete">，定子电压下限：</translation>
    </message>
    <message>
        <source>, RCLPUpUnAbleDownAble:</source>
        <translation type="obsolete">转子电流上限：</translation>
    </message>
    <message>
        <source>, RCLPUpAbleDownUnAble:</source>
        <translation type="obsolete">转子电流下限：</translation>
    </message>
    <message>
        <source>, SCLPUpAbleDownUnAble:</source>
        <translation type="obsolete">，定子电流下限：</translation>
    </message>
    <message>
        <source> singleMaxReactive:</source>
        <translation type="obsolete">，单次最大无功增量：</translation>
    </message>
    <message>
        <source> SCLPUpUnAbleDownAble:</source>
        <translation type="obsolete">，定子电流上限：</translation>
    </message>
    <message>
        <source> cydyAUpUpLimit:</source>
        <translation type="obsolete">厂用点A段上上限：</translation>
    </message>
    <message>
        <source> cydyADownDownLimit:</source>
        <translation type="obsolete">厂用点A段下下限：</translation>
    </message>
    <message>
        <source> cydyBUpUpLimit:</source>
        <translation type="obsolete">厂用点B段上上限：</translation>
    </message>
    <message>
        <source> cydyBDownDownLimit:</source>
        <translation type="obsolete">厂用点B段下下限：</translation>
    </message>
    <message>
        <source> plantPowerADownLimit:</source>
        <translation type="obsolete">厂用点A段下限：</translation>
    </message>
    <message>
        <source> plantPowerBDownLimit:</source>
        <translation type="obsolete">厂用点B段下限：</translation>
    </message>
    <message>
        <source> pUpUpLimit:</source>
        <translation type="obsolete">有功上上限：</translation>
    </message>
    <message>
        <source> pDownDownLimit:</source>
        <translation type="obsolete">有功下下限：</translation>
    </message>
    <message>
        <source> pUpLimit:</source>
        <translation type="obsolete">有功上限：</translation>
    </message>
    <message>
        <source> IsDoubleYC:</source>
        <translation type="obsolete">是否上两侧：</translation>
    </message>
    <message>
        <source> Adjustmode:</source>
        <translation type="obsolete">调节模式：</translation>
    </message>
    <message>
        <source> plantPowerAUpLimit:</source>
        <translation type="obsolete">厂用点A段上限：</translation>
    </message>
    <message>
        <source> plantPowerBUpLimit:</source>
        <translation type="obsolete">厂用点B段上限：</translation>
    </message>
    <message>
        <source> qUpUpLimit:</source>
        <translation type="obsolete">无功上上限：</translation>
    </message>
    <message>
        <source> qDownDownLimit:</source>
        <translation type="obsolete">无功下下限：</translation>
    </message>
    <message>
        <source> pDownLimit:</source>
        <translation type="obsolete">有功下限：</translation>
    </message>
    <message>
        <source>Set up success!</source>
        <translation type="obsolete">设置成功!</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="162"/>
        <source>confirm modify parameter!</source>
        <translation>确认修改！</translation>
    </message>
</context>
<context>
    <name>Net Redundancy</name>
    <message>
        <location filename="qagcnetredundancy.cpp" line="50"/>
        <source>Application start in case of spare status!</source>
        <translation>本机以备机身份启动!</translation>
    </message>
    <message>
        <location filename="qagcnetredundancy.cpp" line="74"/>
        <location filename="qagcnetredundancy.cpp" line="209"/>
        <source>Application upgrad to main status</source>
        <translation>本机升级为主机</translation>
    </message>
    <message>
        <location filename="qagcnetredundancy.cpp" line="183"/>
        <location filename="qagcnetredundancy.cpp" line="200"/>
        <location filename="qagcnetredundancy.cpp" line="630"/>
        <location filename="qagcnetredundancy.cpp" line="668"/>
        <location filename="qagcnetredundancy.cpp" line="699"/>
        <source>Application downgrad to spare status</source>
        <translation>本机降级为备机</translation>
    </message>
</context>
<context>
    <name>QPlanCurveDispDlg</name>
    <message>
        <location filename="plancurvedispdlg.ui" line="14"/>
        <source>Plan Curve</source>
        <translation>计划曲线</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.ui" line="30"/>
        <source>Today</source>
        <oldsource>Tab 1</oldsource>
        <translation>当日</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.ui" line="42"/>
        <source>Seting</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.ui" line="54"/>
        <location filename="plancurvedispdlg.ui" line="251"/>
        <source>Plan Up Limit</source>
        <translation>计划上限</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.ui" line="77"/>
        <location filename="plancurvedispdlg.ui" line="103"/>
        <source>kV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.ui" line="90"/>
        <location filename="plancurvedispdlg.ui" line="287"/>
        <source>Plan Lower Limit</source>
        <translation>计划下限</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.ui" line="126"/>
        <source>Confirm Midify</source>
        <translation>确认修改</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.ui" line="139"/>
        <location filename="plancurvedispdlg.ui" line="336"/>
        <source>Start Time</source>
        <translation>起始时间</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.ui" line="152"/>
        <location filename="plancurvedispdlg.ui" line="349"/>
        <source>End Time</source>
        <translation>结束时间</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.ui" line="185"/>
        <location filename="plancurvedispdlg.ui" line="382"/>
        <source>Return</source>
        <translation>返回</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.ui" line="215"/>
        <source>NextDay</source>
        <translation>次日</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.ui" line="239"/>
        <source>Setting</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.ui" line="323"/>
        <source>Confirm Modify</source>
        <translation>确认修改</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.ui" line="274"/>
        <location filename="plancurvedispdlg.ui" line="300"/>
        <source>KV</source>
        <translation></translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.cpp" line="140"/>
        <location filename="plancurvedispdlg.cpp" line="436"/>
        <source>PLAN_CURVE open failed!</source>
        <translation>打开计划曲线失败！</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.cpp" line="189"/>
        <source>Input data is out of adjustable range!</source>
        <translation>输入数据不在可调范围！</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.cpp" line="194"/>
        <source>The lower limit of planned voltage should not be higher than the upper limit!</source>
        <translation>计划电压下限不可高于上限！</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.cpp" line="202"/>
        <source>The starting time shall not be greater than the ending time!</source>
        <translation>开始时间不可大于结束时间！</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.cpp" line="282"/>
        <source>Set up successfully!</source>
        <translation>设置成功！</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.cpp" line="296"/>
        <location filename="plancurvedispdlg.cpp" line="357"/>
        <source>vUpLimit</source>
        <translation>电压上限</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.cpp" line="297"/>
        <location filename="plancurvedispdlg.cpp" line="358"/>
        <source>vDownLimit</source>
        <translation>电压下限</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.cpp" line="299"/>
        <location filename="plancurvedispdlg.cpp" line="360"/>
        <source>Busbar History Curve</source>
        <translation>母线电压历史曲线</translation>
    </message>
    <message>
        <location filename="plancurvedispdlg.cpp" line="470"/>
        <source>PlanCurve</source>
        <translation>计划曲线</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.cpp" line="27"/>
        <source>pUpLimit</source>
        <translation>有功上限</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.cpp" line="28"/>
        <source>pDownLimit</source>
        <translation>有功下限</translation>
    </message>
</context>
<context>
    <name>QAddBoilerDlg</name>
    <message>
        <location filename="qaddboilerdlg.ui" line="14"/>
        <source>QAddBoilerDlg</source>
        <translation>添加锅炉</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.ui" line="26"/>
        <source>OutputMode</source>
        <translation>输出方式</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.ui" line="38"/>
        <source>ys</source>
        <translation>遥设（数字）</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.ui" line="51"/>
        <source>yt</source>
        <translation>遥调（脉冲）</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.ui" line="75"/>
        <source>RatingPower</source>
        <translation>额定有功</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.ui" line="88"/>
        <source>AdjustWaitTime</source>
        <translation>调节等待时间</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.ui" line="101"/>
        <source>A</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.ui" line="114"/>
        <source>BoilerType</source>
        <translation>锅炉类型</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.ui" line="126"/>
        <location filename="qaddboilerdlg.ui" line="224"/>
        <source>target value</source>
        <translation>目标值</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.ui" line="139"/>
        <location filename="qaddboilerdlg.ui" line="237"/>
        <source>increment</source>
        <translation>增量</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.ui" line="163"/>
        <source>singleMinDeltaP</source>
        <translation>单词最小有功增量</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.ui" line="176"/>
        <source>MW</source>
        <oldsource>kV</oldsource>
        <translation>MW</translation>
    </message>
    <message utf8="true">
        <location filename="qaddboilerdlg.ui" line="189"/>
        <location filename="qaddboilerdlg.ui" line="251"/>
        <source>Ω</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.ui" line="212"/>
        <source>AdjustMode</source>
        <translation>调节模式</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.ui" line="264"/>
        <source>singleMaxDeltaP</source>
        <translation>单次最大有功增量</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.ui" line="297"/>
        <source>boiName</source>
        <translation>锅炉名称</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.ui" line="310"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.ui" line="323"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="12"/>
        <source>PYcNum</source>
        <translation>有功功率</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="13"/>
        <source>Ia</source>
        <translation>A相电流</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="14"/>
        <source>Ib</source>
        <translation>B相电流</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="15"/>
        <source>Ic</source>
        <translation>C相电流</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="16"/>
        <source>ExTargetPYcNum</source>
        <translation>目标有功执行值</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="17"/>
        <source>PlanPYcNum</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="18"/>
        <source>PUpLimitYcNum</source>
        <translation>有功功率上限</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="19"/>
        <source>PDownLimitYcNum</source>
        <translation>有功功率下限</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="21"/>
        <source>IsRunningYxNum</source>
        <translation>运行状态</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="22"/>
        <source>Switch</source>
        <translation>开关</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="23"/>
        <source>protecttotal</source>
        <translation>保护总</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="25"/>
        <source>DigitalYsNum</source>
        <translation>数字遥设指令</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="26"/>
        <source>PulseUpYsNum</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="27"/>
        <source>PulseDownYsNum</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="57"/>
        <source>please select BoilerType!</source>
        <translation>请选择锅炉类型！</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="71"/>
        <source>please select AdjustMode!</source>
        <translation>请选择调节模式！</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="85"/>
        <source>please select OutputMode!</source>
        <translation>请选择输出方式！</translation>
    </message>
    <message>
        <location filename="qaddboilerdlg.cpp" line="154"/>
        <source>Add successfully, the program will take effect after restart!</source>
        <translation>添加成功,请重启程序生效！</translation>
    </message>
</context>
<context>
    <name>QAddBusbarDlg</name>
    <message>
        <location filename="qaddbusbardlg.ui" line="14"/>
        <source>QAddBusbarDlg</source>
        <translation>添加母线</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="26"/>
        <location filename="qaddbusbardlg.ui" line="39"/>
        <location filename="qaddbusbardlg.ui" line="144"/>
        <location filename="qaddbusbardlg.ui" line="157"/>
        <location filename="qaddbusbardlg.ui" line="353"/>
        <location filename="qaddbusbardlg.ui" line="379"/>
        <source>MW</source>
        <oldsource>kW</oldsource>
        <translation>MW</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="52"/>
        <source>Use Local Plan Curve</source>
        <translation>使用就地曲线</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="65"/>
        <source>singleMaxDeltaP</source>
        <translation>单次最大有功增量</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="78"/>
        <source>minuteMaxDeltaP</source>
        <translation>有功每分钟最大增量</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="91"/>
        <source>Main Busbar</source>
        <translation>主母线</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="183"/>
        <source>planType</source>
        <translation>计划类型</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="195"/>
        <source>target value</source>
        <translation>目标值</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="208"/>
        <source>increment</source>
        <translation>增量</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="232"/>
        <source>UpDeadLimit</source>
        <translation>死区上限</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="245"/>
        <location filename="qaddbusbardlg.ui" line="392"/>
        <location filename="qaddbusbardlg.ui" line="500"/>
        <source>Second</source>
        <translation>秒</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="258"/>
        <source>TargetMAX</source>
        <translation>目标最大值</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="271"/>
        <source>workStatusChangeSleep</source>
        <translation>远方就地切换后分配等待时间</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="294"/>
        <source>DownDeadLimit</source>
        <translation>死区下限</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="477"/>
        <source>maxCommandInterval</source>
        <translation>最大指令间隔</translation>
    </message>
    <message>
        <source>pMAX</source>
        <translation type="obsolete">最大有功</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="327"/>
        <source>TargetMIN</source>
        <translation>目标最小值</translation>
    </message>
    <message>
        <source>pMIN</source>
        <translation type="obsolete">最小有功</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="340"/>
        <source>StartChangeSleep</source>
        <translation>投入后等待时间</translation>
    </message>
    <message>
        <source>vGrade</source>
        <translation type="obsolete">电压等级</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="415"/>
        <source>distributeMethod</source>
        <translation>分配方式</translation>
    </message>
    <message>
        <source>AdjustMode</source>
        <translation type="obsolete">调节模式</translation>
    </message>
    <message>
        <source>basicMode</source>
        <translation type="obsolete">基本功率模式</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="428"/>
        <source>busName</source>
        <translation>母线名称</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="451"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.ui" line="464"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="12"/>
        <source>pYcNum</source>
        <translation>系统有功功率</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="22"/>
        <source>planPYcNum</source>
        <translation>计划有功返回值</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="23"/>
        <source>planPExcuteYcNum</source>
        <translation>计划有功执行值</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="24"/>
        <source>runStateYcNum</source>
        <translation>运行状态</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="13"/>
        <source>q</source>
        <translation>无功功率</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="14"/>
        <source>cos</source>
        <translation>功率因数</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="15"/>
        <source>f</source>
        <translation>频率</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="16"/>
        <source>Uab</source>
        <translation>线电压Uab</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="17"/>
        <source>Ubc</source>
        <translation>线电压Ubc</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="18"/>
        <source>Uca</source>
        <translation>线电压Uca</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="19"/>
        <source>Ua</source>
        <translation>A相电压</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="20"/>
        <source>Ub</source>
        <translation>B相电压</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="21"/>
        <source>Uc</source>
        <translation>C相电压</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="41"/>
        <source>Fixed proportion</source>
        <translation>按固定比例分配</translation>
    </message>
    <message>
        <source>Ia</source>
        <translation type="obsolete">A相电流</translation>
    </message>
    <message>
        <source>Ib</source>
        <translation type="obsolete">B相电流</translation>
    </message>
    <message>
        <source>Ic</source>
        <translation type="obsolete">C相电流</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="25"/>
        <source>puplimit</source>
        <translation>有功上限</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="26"/>
        <source>pdownlimit</source>
        <translation>有功下限</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="27"/>
        <source>pUpRate</source>
        <translation>有功上升速率</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="28"/>
        <source>pDownRate</source>
        <translation>有功下降速率</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="31"/>
        <source>UpLockYxNum</source>
        <translation>上闭锁</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="32"/>
        <source>DownLockYxNum</source>
        <translation>下闭锁</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="33"/>
        <source>WorkStatusYXNum</source>
        <translation>工作状态</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="34"/>
        <source>IsRunningYXNum</source>
        <translation>投入\退出</translation>
    </message>
    <message>
        <source>Breaker</source>
        <translation type="obsolete">断路器</translation>
    </message>
    <message>
        <source>Switch</source>
        <translation type="obsolete">开关</translation>
    </message>
    <message>
        <source>Remote/local</source>
        <translation type="obsolete">远方(1)/就地(0)</translation>
    </message>
    <message>
        <source>AGCInput/Exit</source>
        <translation type="obsolete">AGC投/退</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="35"/>
        <source>ComFailureLock</source>
        <translation>通讯故障闭锁</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="36"/>
        <source>DataErrorLock</source>
        <translation>数据错误闭锁</translation>
    </message>
    <message>
        <source>Equal increment rate</source>
        <translation type="obsolete">等微增率（需变压器参数）</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="39"/>
        <source>average increment</source>
        <oldsource>averivage increment</oldsource>
        <translation>增量平均</translation>
    </message>
    <message>
        <source>average target</source>
        <translation type="obsolete">目标平均</translation>
    </message>
    <message>
        <source>ratio target</source>
        <translation type="obsolete">目标与容量成比例</translation>
    </message>
    <message>
        <source>Straight Condensing</source>
        <translation type="obsolete">纯凝</translation>
    </message>
    <message>
        <source>Heating Supply</source>
        <translation type="obsolete">供热</translation>
    </message>
    <message>
        <source>Peak-load Regulation</source>
        <translation type="obsolete">调峰</translation>
    </message>
    <message>
        <source>Equal cos</source>
        <translation type="obsolete">等功率因数</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="40"/>
        <source>ratio increment</source>
        <oldsource>Equal increment rate</oldsource>
        <translation>增量与余量成比例</translation>
    </message>
    <message>
        <source>equal distribution</source>
        <translation type="obsolete">平均分配</translation>
    </message>
    <message>
        <source>Proportional to capacity</source>
        <translation type="obsolete">与容量成比例</translation>
    </message>
    <message>
        <source>nonAdjust</source>
        <translation type="obsolete">不调节</translation>
    </message>
    <message>
        <source>normalAdjust</source>
        <translation type="obsolete">正常调节</translation>
    </message>
    <message>
        <source>secondary</source>
        <translation type="obsolete">次紧急调节</translation>
    </message>
    <message>
        <source>urgentAdjust</source>
        <translation type="obsolete">紧急调节</translation>
    </message>
    <message>
        <source>ssgl</source>
        <translation type="obsolete">实时功率</translation>
    </message>
    <message>
        <source>jhkz</source>
        <translation type="obsolete">计划控制</translation>
    </message>
    <message>
        <source>rgjh</source>
        <translation type="obsolete">人工基荷调节</translation>
    </message>
    <message>
        <source>ssdd</source>
        <translation type="obsolete">实时调度调节</translation>
    </message>
    <message>
        <source>dtjbl</source>
        <translation type="obsolete">等调节比例</translation>
    </message>
    <message>
        <source>fhyc</source>
        <translation type="obsolete">负荷预测</translation>
    </message>
    <message>
        <source>dmgz</source>
        <translation type="obsolete">断面跟踪</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="92"/>
        <source>please select planType!</source>
        <oldsource>please select vGrade!</oldsource>
        <translation>请选择计划类型！</translation>
    </message>
    <message>
        <location filename="qaddbusbardlg.cpp" line="182"/>
        <source>Add successfully, the program will take effect after restart!</source>
        <translation>添加成功,请重启程序生效！</translation>
    </message>
</context>
<context>
    <name>QAddGenDlg</name>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="112"/>
        <source>please select AdjustMode!</source>
        <translation>请选择调节模式！</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="126"/>
        <source>please select planType!</source>
        <translation>请选择计划类型！</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="140"/>
        <source>please select outputMode!</source>
        <translation>请选择输出方式！</translation>
    </message>
</context>
<context>
    <name>QAddGeneratorDlg</name>
    <message>
        <location filename="qaddgeneratordlg.ui" line="14"/>
        <source>QAddGeneratorDlg</source>
        <translation>增加机组</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="26"/>
        <location filename="qaddgeneratordlg.ui" line="49"/>
        <location filename="qaddgeneratordlg.ui" line="108"/>
        <location filename="qaddgeneratordlg.ui" line="167"/>
        <location filename="qaddgeneratordlg.ui" line="245"/>
        <location filename="qaddgeneratordlg.ui" line="307"/>
        <location filename="qaddgeneratordlg.ui" line="438"/>
        <location filename="qaddgeneratordlg.ui" line="543"/>
        <source>MW</source>
        <oldsource>kW</oldsource>
        <translation>MW</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="72"/>
        <source>minPPower</source>
        <translation>有功功率最小值</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="95"/>
        <source>adjustWaitTime</source>
        <translation>调节等待时间</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="121"/>
        <source>maxAdjustCount</source>
        <translation>最大调节次数</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="144"/>
        <source>OverCount</source>
        <translation>连续进入死区次数</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="579"/>
        <source>planType</source>
        <translation>计划类型</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="270"/>
        <location filename="qaddgeneratordlg.ui" line="591"/>
        <source>target value</source>
        <translation>目标值</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="283"/>
        <location filename="qaddgeneratordlg.ui" line="604"/>
        <source>increment</source>
        <translation>增量</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="379"/>
        <source>outputType</source>
        <translation>输出类型</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="391"/>
        <source>ys</source>
        <translation>遥设（数字）</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="404"/>
        <source>yt</source>
        <translation>遥调（脉冲）</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="180"/>
        <source>downDeadLimitP</source>
        <translation>有功死区下限</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="193"/>
        <source>maxPPower</source>
        <translation>有功功率最大值</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="206"/>
        <source>upDeadLimitP</source>
        <translation>有功死区上限</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="219"/>
        <source>genName</source>
        <translation>机组名称</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="232"/>
        <source>minuteMaxDeltaP</source>
        <translation>有功每分钟最大增量</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="258"/>
        <source>Adjust Type</source>
        <translation>调节模式</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="320"/>
        <source>Second</source>
        <translation>秒</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="333"/>
        <source>singleMaxDeltaP</source>
        <translation>单次最大有功增量</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="346"/>
        <source>ratingPPower</source>
        <translation>有功功率额定值</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="621"/>
        <source>chunnelConfig</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="634"/>
        <source>Use Local Plan Curve</source>
        <translation>使用就地曲线</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="670"/>
        <source>AdjustProrate</source>
        <translation>调节比例值</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">确定</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="451"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="484"/>
        <source>CoalCoefficent0</source>
        <translation>煤系数0</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="507"/>
        <source>CoalCoefficent2</source>
        <translation>煤系数2</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="530"/>
        <source>CoalCoefficent1</source>
        <translation>煤系数1</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.ui" line="566"/>
        <source>singleMinDeltaP</source>
        <translation>单词最小有功增量</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="33"/>
        <source>pYcNum</source>
        <translation>系统有功功率</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="34"/>
        <source>q</source>
        <translation>系统无功功率</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="35"/>
        <source>cos</source>
        <translation>系统功率因数</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="36"/>
        <source>fYcNum</source>
        <translation>系统频率</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="37"/>
        <source>planPYcNum</source>
        <translation>计划有功返回值</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="38"/>
        <source>planPExcuteYcNum</source>
        <translation>计划有功执行值</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="39"/>
        <source>ExTargetPYcNum</source>
        <translation>目标有功执行值</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="40"/>
        <source>PUpLimitYcNum</source>
        <translation>有功功率上限</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="41"/>
        <source>PDownLimitYcNum</source>
        <translation>有功功率下限</translation>
    </message>
    <message>
        <source>rotor current</source>
        <translation type="obsolete">转子电流</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="42"/>
        <source>lineUab</source>
        <translation>线电压Uab</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="43"/>
        <source>lineUbc</source>
        <translation>线电压Ubc</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="44"/>
        <source>lineUca</source>
        <translation>线电压Uca</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="45"/>
        <source>A phase current</source>
        <translation>A相电流</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="46"/>
        <source>B phase current</source>
        <translation>B相电流</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="47"/>
        <source>C phase current</source>
        <translation>C相电流</translation>
    </message>
    <message>
        <source>factoryAUab</source>
        <translation type="obsolete">A段厂用电Uab</translation>
    </message>
    <message>
        <source>factoryBUab</source>
        <translation type="obsolete">B段厂用电Uab</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="48"/>
        <source>speedUpLimit</source>
        <translation>速度上限</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="49"/>
        <source>speedDownLimit</source>
        <translation>速度下限</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="50"/>
        <source>coalConsumption</source>
        <translation>煤耗</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="51"/>
        <source>thermalPower</source>
        <translation>热功率</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="52"/>
        <source>thermalPlan</source>
        <translation>热功率计划值</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="53"/>
        <source>dust</source>
        <translation>除尘</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="54"/>
        <source>SO2</source>
        <translation>二氧化硫</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="55"/>
        <source>NOX</source>
        <translation>氮氧化物</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="57"/>
        <source>isRunningYXNum</source>
        <translation>运行状态</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="58"/>
        <source>maxAdjustYxNum</source>
        <translation>多次调整无效闭锁</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="60"/>
        <source>invalidMeasureYxNum</source>
        <translation>无效量测闭锁</translation>
    </message>
    <message>
        <source>TransHighBreaker</source>
        <translation type="obsolete">主变高压侧断路器开关</translation>
    </message>
    <message>
        <source>TransHighMainBusSwitch</source>
        <translation type="obsolete">主变高压侧正母闸刀</translation>
    </message>
    <message>
        <source>TransHighSecondBusSwitch</source>
        <translation type="obsolete">主变高压侧副母闸刀</translation>
    </message>
    <message>
        <source>RemoteHandle</source>
        <translation type="obsolete">远方手柄</translation>
    </message>
    <message>
        <source>CabinetHandle</source>
        <translation type="obsolete">机柜手柄</translation>
    </message>
    <message>
        <source>AVRAbnormalSignalTotal</source>
        <translation type="obsolete">AVR异常信号总</translation>
    </message>
    <message>
        <source>ProtectActionAndFault</source>
        <translation type="obsolete">保护动作及故障</translation>
    </message>
    <message>
        <source>AGCInput/Exit</source>
        <translation type="obsolete">AGC投/退</translation>
    </message>
    <message>
        <source>NoUpAdjust</source>
        <translation type="obsolete">禁止上调</translation>
    </message>
    <message>
        <source>NoDownAdjust</source>
        <translation type="obsolete">禁止下调</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="59"/>
        <source>ComFailureLock</source>
        <translation>通讯故障闭锁</translation>
    </message>
    <message>
        <source>DataErrorLock</source>
        <translation type="obsolete">数据错误闭锁</translation>
    </message>
    <message>
        <source>AVRFault</source>
        <translation type="obsolete">AVR故障</translation>
    </message>
    <message>
        <source>CallbackAlarm</source>
        <translation type="obsolete">回调报警</translation>
    </message>
    <message>
        <source>FOverLimitLock</source>
        <translation type="obsolete">频率越限闭锁</translation>
    </message>
    <message>
        <source>LowFOscLock</source>
        <translation type="obsolete">低频震荡闭锁</translation>
    </message>
    <message>
        <source>DoubleLargeDevLock</source>
        <translation type="obsolete">双量测偏差大闭锁</translation>
    </message>
    <message>
        <source>PQUpLimitLock</source>
        <translation type="obsolete">PQ图越上限闭锁</translation>
    </message>
    <message>
        <source>PQDownLimitLock</source>
        <translation type="obsolete">PQ图越下限闭锁</translation>
    </message>
    <message>
        <source>RotorCurrentUpLimitLock</source>
        <translation type="obsolete">转子电流越上限闭锁</translation>
    </message>
    <message>
        <source>RotorCurrentDownLimitLock</source>
        <translation type="obsolete">转子电流越下限闭锁</translation>
    </message>
    <message>
        <source>SysVUpLimitLock</source>
        <translation type="obsolete">系统电压越上限闭锁</translation>
    </message>
    <message>
        <source>SysVDownLimitLock</source>
        <translation type="obsolete">系统电压越下限闭锁</translation>
    </message>
    <message>
        <source>VUpLimitLock</source>
        <translation type="obsolete">机端电压越上限闭锁</translation>
    </message>
    <message>
        <source>VDownLimitLock</source>
        <translation type="obsolete">机端电压越下限闭锁</translation>
    </message>
    <message>
        <source>StatorCurrentUpLimitLock</source>
        <translation type="obsolete">定子电流越上限闭锁</translation>
    </message>
    <message>
        <source>StatorCurrentDownLimitLock</source>
        <translation type="obsolete">定子电流越下限闭锁</translation>
    </message>
    <message>
        <source>PUpLimitLock</source>
        <translation type="obsolete">有功越上限闭锁</translation>
    </message>
    <message>
        <source>QUpLimitLock</source>
        <translation type="obsolete">无功越上限闭锁</translation>
    </message>
    <message>
        <source>QDownLimitLock</source>
        <translation type="obsolete">无功越下限闭锁</translation>
    </message>
    <message>
        <source>FactoryVUpLimitLock</source>
        <translation type="obsolete">厂用电电压越上限闭锁</translation>
    </message>
    <message>
        <source>FactoryVDownLimitLock</source>
        <translation type="obsolete">厂用电电压越下限闭锁</translation>
    </message>
    <message>
        <source>VUpUp/DownDownLimitLock</source>
        <translation type="obsolete">机端电压越上上限\下下限闭锁</translation>
    </message>
    <message>
        <source>PUpUp/DownDownLimitLock</source>
        <translation type="obsolete">有功越上上限\下下限闭锁</translation>
    </message>
    <message>
        <source>QUpUp/DownDownLimitLock</source>
        <translation type="obsolete">无功越上上限\下下限闭锁</translation>
    </message>
    <message>
        <source>FactoryVUpUp/DownDownLimitLock</source>
        <translation type="obsolete">厂用电电压越上上限\下下限闭锁</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="61"/>
        <source>megcPermitYxNum</source>
        <translation>AGC允许</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="62"/>
        <source>rb</source>
        <translation>RB</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="63"/>
        <source>gridConnect</source>
        <translation>电网连接</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="64"/>
        <source>forbidAdd</source>
        <translation>禁止增</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="65"/>
        <source>forbidSub</source>
        <translation>禁止减</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="66"/>
        <source>protect</source>
        <translation>保护</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="67"/>
        <source>thermalRunning</source>
        <translation>热功率投/退</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="71"/>
        <source>digitalYsNum</source>
        <translation>数字遥设指令</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="72"/>
        <source>pulseUpYsNum</source>
        <translation>增磁指令</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="73"/>
        <source>pulseDownYsNum</source>
        <translation>减磁指令</translation>
    </message>
    <message>
        <location filename="qaddgeneratordlg.cpp" line="279"/>
        <source>Add successfully, the program will take effect after restart!</source>
        <translation>添加成功,请重启程序生效！</translation>
    </message>
</context>
<context>
    <name>QAdjustInfoQueryDlg</name>
    <message>
        <location filename="qadjustinfoquerydlg.ui" line="14"/>
        <source>QAdjustInfoQueryDlg</source>
        <translation>调整信息查询</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.ui" line="26"/>
        <source>start time</source>
        <translation>起始时间</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.ui" line="39"/>
        <source>yyyy/MM/dd HH:mm:ss</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.ui" line="55"/>
        <source>end time</source>
        <translation>终止时间</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.ui" line="68"/>
        <source>yyyy/MM/dd hh:mm:ss</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.ui" line="133"/>
        <source>Next Page</source>
        <translation>下一页</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.ui" line="165"/>
        <source>Previous Page</source>
        <translation>上一页</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.ui" line="178"/>
        <source>Current Page</source>
        <translation>当前页</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.ui" line="191"/>
        <source>To</source>
        <translation>转到</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.ui" line="207"/>
        <source>Go</source>
        <translation>执行</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.ui" line="233"/>
        <source>Total Page</source>
        <translation>总页数</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.ui" line="246"/>
        <source>export</source>
        <translation>导出</translation>
    </message>
    <message>
        <source>select gen</source>
        <translation type="obsolete">选择机组</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.ui" line="91"/>
        <source>query</source>
        <translation>查询</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.ui" line="104"/>
        <source>close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.cpp" line="162"/>
        <location filename="qadjustinfoquerydlg.cpp" line="280"/>
        <source>Increase</source>
        <translation>增磁</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.cpp" line="166"/>
        <location filename="qadjustinfoquerydlg.cpp" line="284"/>
        <source>Decrease</source>
        <translation>减磁</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.cpp" line="104"/>
        <source>Time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.cpp" line="53"/>
        <source>adjust_info open failed!</source>
        <translation>打开调节信息失败！</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.cpp" line="105"/>
        <source>Generator</source>
        <translation>机组</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.cpp" line="106"/>
        <location filename="qadjustinfoquerydlg.cpp" line="260"/>
        <source>Trend</source>
        <translation>趋势（升/降）</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.cpp" line="107"/>
        <location filename="qadjustinfoquerydlg.cpp" line="261"/>
        <source>Range</source>
        <translation>幅度</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.cpp" line="237"/>
        <source>Excel file</source>
        <translation>报表文件</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.cpp" line="237"/>
        <source>Files (*.csv)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.cpp" line="254"/>
        <source>adjust info</source>
        <translation>调整信息</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.cpp" line="257"/>
        <source>num</source>
        <translation>编号</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.cpp" line="258"/>
        <source>adjust time</source>
        <translation>调整时间</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.cpp" line="259"/>
        <source>generator</source>
        <translation>机组</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.cpp" line="296"/>
        <source>Export data succeeded</source>
        <translation>导出数据成功</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.cpp" line="296"/>
        <source>Information saved in</source>
        <translation>信息已保存在</translation>
    </message>
    <message>
        <source>Information saved in%1£¡</source>
        <translation type="obsolete">信息已保存在</translation>
    </message>
    <message>
        <location filename="qadjustinfoquerydlg.cpp" line="296"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <source>Content</source>
        <translation type="obsolete">内容</translation>
    </message>
    <message>
        <source>All Gens</source>
        <translation type="obsolete">所有机组</translation>
    </message>
</context>
<context>
    <name>QPlantAgcBusbarControler</name>
    <message>
        <location filename="agcbusbarcontroler.cpp" line="296"/>
        <source>AGC  check remote/local status locked</source>
        <translation>AGC远方就地状态检查</translation>
    </message>
    <message>
        <location filename="agcbusbarcontroler.cpp" line="310"/>
        <source>InValidMeasure,AGC Adjust Locked</source>
        <oldsource>InValidMeasure��AGC Adjust Locked</oldsource>
        <translation>无效量测，AGC调节闭锁</translation>
    </message>
    <message>
        <location filename="agcbusbarcontroler.cpp" line="343"/>
        <source>User Define Locked,AGC Adjust Locked</source>
        <oldsource>User Define Locked��AGC Adjust Locked</oldsource>
        <translation>用户定义闭锁，AGC调整闭锁</translation>
    </message>
    <message>
        <location filename="agcbusbarcontroler.cpp" line="326"/>
        <source> AGC invalid plan value</source>
        <translation>AGC无效计划值</translation>
    </message>
    <message>
        <location filename="agcbusbarcontroler.cpp" line="368"/>
        <location filename="agcbusbarcontroler.cpp" line="381"/>
        <location filename="agcbusbarcontroler.cpp" line="416"/>
        <source>AGC adjust waiting</source>
        <translation>AGC调整等待</translation>
    </message>
    <message>
        <location filename="agcbusbarcontroler.cpp" line="394"/>
        <source>AGC no dev to be used</source>
        <translation>AGC无可用设备</translation>
    </message>
    <message>
        <location filename="agcbusbarcontroler.cpp" line="451"/>
        <source>AGC Adjust Free</source>
        <translation>AGC调节空闲</translation>
    </message>
    <message>
        <source>reject</source>
        <translation type="obsolete">拒动</translation>
    </message>
</context>
<context>
    <name>QPlantAgcHistoryData</name>
    <message>
        <location filename="qagchistorydata.cpp" line="53"/>
        <source>SAVE_PARA open failed!</source>
        <translation>打开保存参数失败！</translation>
    </message>
    <message>
        <location filename="qagchistorydata.cpp" line="722"/>
        <source>PLAN_CURVE_31DAY open failed!</source>
        <translation>打开31天计划曲线失败！</translation>
    </message>
</context>
<context>
    <name>QPlantAgcRtdbManager</name>
    <message>
        <source>command over max delta scope or value scope.</source>
        <translation type="obsolete">指令超过限制范围或增量范围.</translation>
    </message>
    <message>
        <source>command over target max or target min.</source>
        <translation type="obsolete">指令超过最大值或最小值.</translation>
    </message>
    <message>
        <source>command over max delta scope.</source>
        <translation type="obsolete">指令增量超过最大值.</translation>
    </message>
    <message>
        <source>delta scope of real value and reference value over limit.</source>
        <translation type="obsolete">实际值与参考值差值越限.</translation>
    </message>
    <message>
        <source> command over max delta scope.</source>
        <translation type="obsolete">指令增量超过最大值.</translation>
    </message>
    <message>
        <source>Volt up:%1.</source>
        <translation type="obsolete">增磁:%1.</translation>
    </message>
    <message>
        <source>Volt down:%1.</source>
        <translation type="obsolete">减磁:%1.</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="198"/>
        <source>AGC_PARA open failed!</source>
        <translation>打开AGC参数失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="222"/>
        <source>BUSBAR open failed!</source>
        <translation>打开BUSBAR失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="277"/>
        <source>BUSBAR_AGC_LOCK open failed!</source>
        <translation>打开BUSBAR_AGC_LOCK失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="323"/>
        <source>BUSBAR_AGC_LOCK_CONDITION_YC open failed!</source>
        <translation>打开BUSBAR_AGC_LOCK_CONDITION_YC失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="352"/>
        <source>BUSBAR_AGC_LOCK_CONDITION_YX open failed!</source>
        <translation>打开BUSBAR_AGC_LOCK_CONDITION_YX失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="374"/>
        <source>GENERATOR open failed!</source>
        <translation>打开GENERATOR失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="456"/>
        <source>GENERATOR_AGC_LOCK open failed!</source>
        <translation>打开GENERATOR_AGC_LOCK失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="503"/>
        <source>GENERATOR_AGC_LOCK_CONDITION_YC open failed!</source>
        <translation>打开GENERATOR_AGC_LOCK_CONDITION_YC失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="526"/>
        <source>GENERATOR_AGC_LOCK_CONDITION_YX open failed!</source>
        <translation>打开GENERATOR_AGC_LOCK_CONDITION_YX失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="545"/>
        <source>GENERATOR_P_TIME open failed!</source>
        <translation>打开GENERATOR_P_TIME失败！</translation>
    </message>
    <message>
        <source>GENERATOR_AGC_ACCELERATE open failed!</source>
        <translation type="obsolete">打开GENERATOR_AGC_ACCELERATE失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="79"/>
        <source>RTU open failed!</source>
        <translation>打开RTU表失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="82"/>
        <source>LINE open failed!</source>
        <translation>打开LINE表失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="85"/>
        <source>YC_DATA open failed!</source>
        <translation>yc_data打开失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="88"/>
        <source>YX_DATA open failed!</source>
        <translation>yx_data打开失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="91"/>
        <source>DD_DATA open failed!</source>
        <translation>DD_DATA打开失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="94"/>
        <source>YK_DATA open failed!</source>
        <translation>yk_data打开失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="97"/>
        <source>YT_DATA open failed!</source>
        <translation>yt_data打开失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="100"/>
        <source>YS_DATA open failed!</source>
        <translation>ys_data打开失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="103"/>
        <source>PLAN_CURVE open failed!</source>
        <translation>打开PLAN_CURVE失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="574"/>
        <source>GENERATOR_AGC_CRITICAL_COAL open failed!</source>
        <translation>打开GENERATOR_AGC_CRITICAL_COAL失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="604"/>
        <source>BOILER open failed!</source>
        <translation>打开BOILER失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="644"/>
        <source>BOILER_AGC_LOCK open failed!</source>
        <translation>打开BOILER_AGC_LOCK失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="691"/>
        <source>BOILER_AGC_LOCK_CONDITION_YC open failed!</source>
        <translation>打开BOILER_AGC_LOCK_CONDITION_YC失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="714"/>
        <source>BOILER_AGC_LOCK_CONDITION_YX open failed!</source>
        <translation>打开BOILER_AGC_LOCK_CONDITION_YX失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="733"/>
        <source>BOILER_P_TIME open failed!</source>
        <translation>打开BOILER_P_TIME失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="1235"/>
        <source>%1 receive remote adjust conmmand:%2.</source>
        <translation>%1 受到遥调指令:%2.</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="1305"/>
        <source>receive remote adjust conmmand:%1 ,%2.</source>
        <translation>收到远方遥调指令:%1,%2.</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="1450"/>
        <location filename="qagcrtdbmanager.cpp" line="1466"/>
        <source>digital output:%1.</source>
        <translation>数字量输出%1.</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="1454"/>
        <location filename="qagcrtdbmanager.cpp" line="1470"/>
        <source>power up:%1.</source>
        <translation>增有功%1.</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="1458"/>
        <location filename="qagcrtdbmanager.cpp" line="1474"/>
        <source>power down:%1.</source>
        <translation>减有功%1.</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="1506"/>
        <source>Open</source>
        <translation>分</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="1510"/>
        <source>Close</source>
        <translation>合</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="1637"/>
        <source>BUSBAR_AGC_UP_ADJUST open failed!</source>
        <translation>打开BUSBAR_AGC_UP_ADJUST失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="1661"/>
        <source>BUSBAR_AGC_UP_ADJUST_DEV open failed!</source>
        <translation>打开BUSBAR_AGC_UP_ADJUST_DEV失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="1678"/>
        <source>BUSBAR_AGC_DOWN_ADJUST open failed!</source>
        <translation>打开BUSBAR_AGC_DOWN_ADJUST失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="1702"/>
        <source>BUSBAR_AGC_DOWN_ADJUST_DEV open failed!</source>
        <translation>打开BUSBAR_AGC_DOWN_ADJUST_DEV失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="1719"/>
        <source>BUSBAR_AGC_EXCHANGE open failed!</source>
        <translation>打开BUSBAR_AGC_EXCHANGE失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="1745"/>
        <source>BUSBAR_AGC_EXCHANGE_FROM open failed!</source>
        <translation>打开BUSBAR_AGC_EXCHANGE_FROM失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="1762"/>
        <source>BUSBAR_AGC_EXCHANGE_TO open failed!</source>
        <translation>打开BUSBAR_AGC_EXCHANGE_TO失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="1779"/>
        <source>BUSBAR_AGC_OPTIMIZE open failed!</source>
        <translation>打开BUSBAR_AGC_OPTIMIZE失败！</translation>
    </message>
    <message>
        <location filename="qagcrtdbmanager.cpp" line="1801"/>
        <source>BUSBAR_AGC_OPTIMIZE_DEV open failed!</source>
        <translation>打开BUSBAR_AGC_OPTIMIZE_DEV失败！</translation>
    </message>
</context>
<context>
    <name>QAppSettingDlg</name>
    <message>
        <source>Data Source Set</source>
        <translation type="obsolete">数据源设置</translation>
    </message>
    <message>
        <source>Database</source>
        <translation type="obsolete">数据库</translation>
    </message>
    <message>
        <source>Database rtdb</source>
        <translation type="obsolete">实时数据库</translation>
    </message>
    <message>
        <source>Database hisdb</source>
        <translation type="obsolete">历史数据库</translation>
    </message>
    <message>
        <source>Driver</source>
        <translation type="obsolete">驱动程序</translation>
    </message>
    <message>
        <source>Server</source>
        <translation type="obsolete">服务器</translation>
    </message>
    <message>
        <source>user</source>
        <translation type="obsolete">用户名</translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="obsolete">密码</translation>
    </message>
    <message>
        <source>NodeNum</source>
        <translation type="obsolete">节点编号</translation>
    </message>
    <message>
        <location filename="qappsettingdlg.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished">数据源设置</translation>
    </message>
    <message utf8="true">
        <location filename="qappsettingdlg.ui" line="20"/>
        <source>数据库连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="qappsettingdlg.ui" line="26"/>
        <source>主机</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="qappsettingdlg.ui" line="39"/>
        <source>用户名</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="qappsettingdlg.ui" line="61"/>
        <source>实时数据库</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="qappsettingdlg.ui" line="68"/>
        <source>数据源</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="qappsettingdlg.ui" line="84"/>
        <source>历史数据库</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="qappsettingdlg.ui" line="91"/>
        <source>驱动程序</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="qappsettingdlg.ui" line="104"/>
        <source>密码</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="qappsettingdlg.ui" line="130"/>
        <source>节点编号</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QAvcHistoryData</name>
    <message>
        <source>Failed to connect to driver!</source>
        <translation type="obsolete">连接驱动失败!</translation>
    </message>
    <message>
        <source>Failed to open database!</source>
        <translation type="obsolete">打开数据库失败!</translation>
    </message>
</context>
<context>
    <name>QAvcRtdbManager</name>
    <message>
        <source>Application program can start only one case!</source>
        <translation type="obsolete">应用程序只能启动一个实例!</translation>
    </message>
    <message>
        <source>Data Source error,please reset data source,then restart program!</source>
        <translation type="obsolete">数据源错误，请重新设置数据源，然后重启程序！</translation>
    </message>
    <message>
        <source>Failed to connect to driver!</source>
        <translation type="obsolete">连接驱动失败!</translation>
    </message>
    <message>
        <source>Failed to open database!</source>
        <translation type="obsolete">打开数据库失败!</translation>
    </message>
    <message>
        <source>Open!</source>
        <translation type="obsolete">分!</translation>
    </message>
    <message>
        <source>Close!</source>
        <translation type="obsolete">合!</translation>
    </message>
    <message>
        <source>Volt Target</source>
        <translation type="obsolete">电压目标</translation>
    </message>
    <message>
        <source>Volt Delta</source>
        <translation type="obsolete">电压增量</translation>
    </message>
    <message>
        <source>Reactive Delta</source>
        <translation type="obsolete">无功增量</translation>
    </message>
    <message>
        <source>command over max delta scope or value scope.</source>
        <oldsource>Reactive power command over max delta scope or value scope.</oldsource>
        <translation type="obsolete">指令超过限制范围或增量范围.</translation>
    </message>
    <message>
        <source>command over target max or target min.</source>
        <oldsource>Reactive command over target max or target min.</oldsource>
        <translation type="obsolete">指令超过最大值或最小值.</translation>
    </message>
    <message>
        <source>command over max delta scope.</source>
        <oldsource>Reactive command over over max delta scope.</oldsource>
        <translation type="obsolete">指令增量超过最大值.</translation>
    </message>
    <message>
        <source>delta scope of real value and reference value over limit.</source>
        <translation type="obsolete">实际值与参考值差值越限.</translation>
    </message>
    <message>
        <source> command over max delta scope.</source>
        <translation type="obsolete">指令增量超过最大值.</translation>
    </message>
    <message>
        <source>Volt up:%1.</source>
        <translation type="obsolete">增磁:%1.</translation>
    </message>
    <message>
        <source>Volt down:%1.</source>
        <translation type="obsolete">减磁:%1.</translation>
    </message>
    <message>
        <source>%1 receive remote adjust conmmand:%2.</source>
        <translation type="obsolete">%1 受到遥调指令:%2.</translation>
    </message>
    <message>
        <source>receive remote adjust conmmand:%1 ,%2.</source>
        <translation type="obsolete">收到远方遥调指令:%1,%2.</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="obsolete">分</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="obsolete">合</translation>
    </message>
</context>
<context>
    <name>QBoiChunnelInfoConfigDlg</name>
    <message>
        <location filename="qboichunnelinfoconfigdlg.ui" line="14"/>
        <source>QBoiChunnelInfoConfigDlg</source>
        <translation>锅炉通道组态</translation>
    </message>
    <message>
        <location filename="qboichunnelinfoconfigdlg.ui" line="26"/>
        <source>quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="qboichunnelinfoconfigdlg.ui" line="39"/>
        <source>Ic</source>
        <translation>C相电流</translation>
    </message>
    <message>
        <location filename="qboichunnelinfoconfigdlg.ui" line="62"/>
        <source>Ia</source>
        <translation>A相电流</translation>
    </message>
    <message>
        <location filename="qboichunnelinfoconfigdlg.ui" line="75"/>
        <source>pYcNum</source>
        <translation>系统有功功率</translation>
    </message>
    <message>
        <location filename="qboichunnelinfoconfigdlg.ui" line="88"/>
        <source>select chunnel</source>
        <translation>选择通道</translation>
    </message>
    <message>
        <location filename="qboichunnelinfoconfigdlg.ui" line="101"/>
        <source>addToCurrentChunnel</source>
        <translation>添加到通道</translation>
    </message>
    <message>
        <location filename="qboichunnelinfoconfigdlg.ui" line="114"/>
        <source>CHUNNEL_YX</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboichunnelinfoconfigdlg.ui" line="126"/>
        <source>boilerprotecttotal</source>
        <translation>保护总</translation>
    </message>
    <message>
        <location filename="qboichunnelinfoconfigdlg.ui" line="139"/>
        <source>switch</source>
        <translation>开关</translation>
    </message>
    <message>
        <location filename="qboichunnelinfoconfigdlg.ui" line="153"/>
        <source>CHUNNEL_YS</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboichunnelinfoconfigdlg.ui" line="165"/>
        <source>pulseUpYs</source>
        <translation>升脉冲指令</translation>
    </message>
    <message>
        <location filename="qboichunnelinfoconfigdlg.ui" line="178"/>
        <source>pulseDown</source>
        <translation>降脉冲指令</translation>
    </message>
    <message>
        <location filename="qboichunnelinfoconfigdlg.ui" line="192"/>
        <source>CHUNNEL_YC</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboichunnelinfoconfigdlg.ui" line="205"/>
        <source>Ib</source>
        <translation>B相电流</translation>
    </message>
    <message>
        <location filename="qboichunnelinfoconfigdlg.cpp" line="45"/>
        <source>chunnel open failed!</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboichunnelinfoconfigdlg.cpp" line="62"/>
        <source>add to the current channel£¿</source>
        <translation>确认添加到当前通道?</translation>
    </message>
</context>
<context>
    <name>QBoiler</name>
    <message>
        <location filename="boiler.cpp" line="626"/>
        <source>Digital output:</source>
        <translation>数字量输出：</translation>
    </message>
    <message>
        <location filename="boiler.cpp" line="653"/>
        <source>Add Pulse output :</source>
        <translation>增脉冲输出：</translation>
    </message>
    <message>
        <location filename="boiler.cpp" line="657"/>
        <source>Sub Pulse output :</source>
        <translation>减脉冲输出：</translation>
    </message>
</context>
<context>
    <name>QBoilerLock</name>
    <message>
        <location filename="qboilerlock.ui" line="14"/>
        <source>QBoilerLock</source>
        <translation>锅炉自定义闭锁</translation>
    </message>
    <message>
        <location filename="qboilerlock.ui" line="26"/>
        <source>IDC_YC</source>
        <translation>遥测条件</translation>
    </message>
    <message>
        <location filename="qboilerlock.ui" line="62"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qboilerlock.ui" line="75"/>
        <source>boiler</source>
        <translation>锅炉</translation>
    </message>
    <message>
        <location filename="qboilerlock.ui" line="88"/>
        <source>restoreWaitTime</source>
        <translation>恢复时间</translation>
    </message>
    <message>
        <location filename="qboilerlock.ui" line="111"/>
        <source>restoreType</source>
        <translation>恢复类型</translation>
    </message>
    <message>
        <location filename="qboilerlock.ui" line="123"/>
        <source>auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <location filename="qboilerlock.ui" line="136"/>
        <source>man</source>
        <translation>人工</translation>
    </message>
    <message>
        <location filename="qboilerlock.ui" line="160"/>
        <source>lockname</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qboilerlock.ui" line="173"/>
        <source>relatedYx</source>
        <translation>关联遥信</translation>
    </message>
    <message>
        <location filename="qboilerlock.ui" line="206"/>
        <source>IDC_YX</source>
        <translation>遥信条件</translation>
    </message>
    <message>
        <location filename="qboilerlock.ui" line="219"/>
        <source>IDC_LOCK_ADD</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="qboilerlock.ui" line="232"/>
        <source>IDC_DELETE</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="qboilerlock.ui" line="245"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qboilerlock.ui" line="258"/>
        <source>IDOK</source>
        <translation>修改</translation>
    </message>
    <message>
        <location filename="qboilerlock.cpp" line="25"/>
        <source>total lock</source>
        <translation>总闭锁</translation>
    </message>
    <message>
        <location filename="qboilerlock.cpp" line="27"/>
        <source>lock up</source>
        <translation>上闭锁</translation>
    </message>
    <message>
        <location filename="qboilerlock.cpp" line="29"/>
        <source>lock down</source>
        <translation>下闭锁</translation>
    </message>
    <message>
        <location filename="qboilerlock.cpp" line="282"/>
        <source>really delete?</source>
        <translation>确定删除？</translation>
    </message>
    <message>
        <location filename="qboilerlock.cpp" line="331"/>
        <source>deleted</source>
        <translation>已删除！</translation>
    </message>
    <message>
        <location filename="qboilerlock.cpp" line="549"/>
        <location filename="qboilerlockconditionycdlg.cpp" line="385"/>
        <source>manuset table open faulse!</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QBoilerLockConditionYCDlg</name>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="14"/>
        <source>QBoilerLockConditionYCDlg</source>
        <translation>闭锁遥测条件</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="26"/>
        <source>threshold</source>
        <translation>门槛值</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="39"/>
        <source>relatedYc</source>
        <oldsource>relatedYx</oldsource>
        <translation>关联遥测</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="52"/>
        <source>IDOK</source>
        <translation>修改</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="65"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="78"/>
        <source>deadArea</source>
        <translation>死区</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="101"/>
        <source>conditionnum</source>
        <translation>条件编号</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="114"/>
        <source>boiler</source>
        <translation>锅炉</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="150"/>
        <source>lockname</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="163"/>
        <source>checkType</source>
        <translation>比较类型</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="175"/>
        <source>&gt;=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="188"/>
        <source>&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="201"/>
        <source>=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="214"/>
        <source>&lt;=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="227"/>
        <source>&lt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="251"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="304"/>
        <source>IDC_ADD</source>
        <translation>遥测条件</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.ui" line="317"/>
        <source>IDC_DELETE</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboilerlock.cpp" line="411"/>
        <location filename="qboilerlockconditionycdlg.cpp" line="275"/>
        <source>update faulse!!!</source>
        <translation>更新失败！</translation>
    </message>
    <message>
        <location filename="qboilerlock.cpp" line="416"/>
        <source>updated!!!</source>
        <translation>修改成功！</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.cpp" line="47"/>
        <source>really delete?</source>
        <translation>确定删除？</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.cpp" line="110"/>
        <location filename="qboilerlockconditionycdlg.cpp" line="335"/>
        <location filename="qboilerlockconditionycdlg.cpp" line="435"/>
        <source>locktype error</source>
        <translation>闭锁类型错误</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.cpp" line="119"/>
        <source>deleted</source>
        <translation>已删除！</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionycdlg.cpp" line="125"/>
        <source>no record </source>
        <translation>无记录！</translation>
    </message>
</context>
<context>
    <name>QBoilerLockConditionYC_ADD</name>
    <message>
        <location filename="qboilerlockconditionyc_add.ui" line="14"/>
        <source>QBoilerLockConditionYC_ADD</source>
        <translation>添加遥测条件</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.ui" line="26"/>
        <source>boiler</source>
        <translation>锅炉</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.ui" line="52"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.ui" line="78"/>
        <source>lockNAME</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.ui" line="104"/>
        <source>conditionnum</source>
        <translation>条件编号</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.ui" line="130"/>
        <source>checkType</source>
        <translation>比较类型</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.ui" line="142"/>
        <source>&gt;=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.ui" line="155"/>
        <source>&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.ui" line="168"/>
        <source>=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.ui" line="181"/>
        <source>&lt;=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.ui" line="194"/>
        <source>&lt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.ui" line="231"/>
        <source>threshold</source>
        <translation>门槛值</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.ui" line="254"/>
        <source>deadArea</source>
        <translation>死区</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.ui" line="277"/>
        <source>IDOKADD</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.ui" line="290"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.ui" line="303"/>
        <source>relatedYc</source>
        <oldsource>relatedYx</oldsource>
        <translation>关联遥测</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.cpp" line="123"/>
        <source>please unter checktype</source>
        <translation>请输入比较类型！</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.cpp" line="189"/>
        <source>INSERT</source>
        <translation>添加成功！</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyc_add.cpp" line="228"/>
        <source>YC_DATA open failed!</source>
        <translation>yc_data打开失败！</translation>
    </message>
</context>
<context>
    <name>QBoilerLockConditionYXDlg</name>
    <message>
        <location filename="qboilerlockconditionyxdlg.ui" line="14"/>
        <source>QBoilerLockConditionYXDlg</source>
        <translation>闭锁遥信条件</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyxdlg.ui" line="56"/>
        <source>threshold</source>
        <translation>门槛值</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyxdlg.ui" line="89"/>
        <source>conditionnum</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyxdlg.ui" line="112"/>
        <source>IDC_DELETE</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyxdlg.ui" line="125"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyxdlg.ui" line="151"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyxdlg.ui" line="164"/>
        <source>IDC_ADD</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyxdlg.ui" line="177"/>
        <source>IDOK</source>
        <translation>修改</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyxdlg.ui" line="190"/>
        <source>boiler</source>
        <translation>锅炉</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyxdlg.ui" line="203"/>
        <source>lockname</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyxdlg.ui" line="216"/>
        <source>relatedYx</source>
        <translation>关联遥信</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyxdlg.cpp" line="45"/>
        <source>really delete?</source>
        <translation>确定删除？</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyxdlg.cpp" line="103"/>
        <location filename="qboilerlockconditionyxdlg.cpp" line="229"/>
        <location filename="qboilerlockconditionyxdlg.cpp" line="469"/>
        <source>locktype error</source>
        <translation>闭锁类型错误</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyxdlg.cpp" line="110"/>
        <source>deleted</source>
        <translation>已删除！</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyxdlg.cpp" line="116"/>
        <source>no record </source>
        <translation>无记录！</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyxdlg.cpp" line="153"/>
        <source>update faulse!!!</source>
        <translation>更新失败！</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyxdlg.cpp" line="312"/>
        <source>manuset table open faulse!</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QBoilerLockConditionYX_ADD</name>
    <message>
        <location filename="qboilerlockconditionyx_add.ui" line="14"/>
        <source>QBoilerLockConditionYX_ADD</source>
        <translation>添加遥信条件</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyx_add.ui" line="39"/>
        <source>conditionnum</source>
        <translation>条件编号</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyx_add.ui" line="65"/>
        <source>lockname</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyx_add.ui" line="111"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyx_add.ui" line="124"/>
        <source>threshold</source>
        <translation>门槛值</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyx_add.ui" line="150"/>
        <source>boiler</source>
        <translation>锅炉</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyx_add.ui" line="176"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyx_add.ui" line="189"/>
        <source>IDOKADD</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyx_add.ui" line="202"/>
        <source>relatedYx</source>
        <translation>关联遥信</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyx_add.cpp" line="33"/>
        <source>exist </source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyx_add.cpp" line="97"/>
        <source>inserted</source>
        <translation>添加成功！</translation>
    </message>
    <message>
        <location filename="qboilerlockconditionyx_add.cpp" line="220"/>
        <source>YX_DATA open failed!</source>
        <translation>yx_data打开失败！</translation>
    </message>
</context>
<context>
    <name>QBoilerLock_ADD</name>
    <message>
        <location filename="qboilerlock_add.ui" line="14"/>
        <source>QBoilerLock_ADD</source>
        <translation>添加闭锁</translation>
    </message>
    <message>
        <location filename="qboilerlock_add.ui" line="39"/>
        <source>lockname</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qboilerlock_add.ui" line="62"/>
        <source>locknum</source>
        <translation>闭锁编号</translation>
    </message>
    <message>
        <location filename="qboilerlock_add.ui" line="85"/>
        <source>restoreWaitTime</source>
        <translation>恢复时间</translation>
    </message>
    <message>
        <location filename="qboilerlock_add.ui" line="121"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qboilerlock_add.ui" line="147"/>
        <source>boiler</source>
        <translation>锅炉</translation>
    </message>
    <message>
        <location filename="qboilerlock_add.ui" line="173"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qboilerlock_add.ui" line="186"/>
        <source>IDOKADD</source>
        <oldsource>IDOK</oldsource>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qboilerlock_add.ui" line="199"/>
        <source>relatedYx</source>
        <translation>关联遥信</translation>
    </message>
    <message>
        <location filename="qboilerlock_add.ui" line="212"/>
        <source>restoreType</source>
        <translation>恢复类型</translation>
    </message>
    <message>
        <location filename="qboilerlock_add.ui" line="224"/>
        <source>auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <location filename="qboilerlock_add.ui" line="237"/>
        <source>man</source>
        <translation>人工</translation>
    </message>
    <message>
        <location filename="qboilerlock_add.cpp" line="93"/>
        <source>please enter restoretype </source>
        <translation>请输入恢复类型！</translation>
    </message>
    <message>
        <location filename="qboilerlock_add.cpp" line="99"/>
        <source>please enter lock name</source>
        <translation>请输入闭锁名称！</translation>
    </message>
    <message>
        <location filename="qboilerlock_add.cpp" line="114"/>
        <source>exist </source>
        <translation></translation>
    </message>
    <message>
        <location filename="qboilerlock_add.cpp" line="166"/>
        <source>inserted</source>
        <translation>添加成功！</translation>
    </message>
    <message>
        <location filename="qboilerlock_add.cpp" line="186"/>
        <location filename="qboilerlock_add.cpp" line="209"/>
        <source>YX_DATA open failed!</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QBusChunnelInfoConfigDlg</name>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="14"/>
        <source>QBusChunnelInfoConfigDlg</source>
        <translation>母线通道组态</translation>
    </message>
    <message>
        <source>Ib</source>
        <translation type="obsolete">B相电流</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="26"/>
        <source>CHUNNEL_YC</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="46"/>
        <source>cos</source>
        <translation>功率因数</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="144"/>
        <source>pDownRateYcNum</source>
        <translation>有功下降速率</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="102"/>
        <source>planPYcNum</source>
        <translation>计划有功返回值</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="137"/>
        <source>pUpRateYcNum</source>
        <translation>有功上升速率</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="109"/>
        <source>planPExcuteYcNum</source>
        <translation>计划有功执行值</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="130"/>
        <source>pDownLimitYcNum</source>
        <translation>有功功率下限</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="123"/>
        <source>pUpLimitYcNum</source>
        <translation>有功功率上限</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="116"/>
        <source>runStateYcNum</source>
        <translation>运行状态</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="81"/>
        <source>Ua</source>
        <translation>A相电压</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="74"/>
        <source>Uca</source>
        <translation>线电压Uca</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="160"/>
        <source>quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <source>AGCInput/Exit</source>
        <translation type="obsolete">AGC投/退</translation>
    </message>
    <message>
        <source>Remote/local</source>
        <translation type="obsolete">远方(1)/就地(0)</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="273"/>
        <source>ComFailureLock</source>
        <translation>通讯故障闭锁</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="286"/>
        <source>DataErrorLock</source>
        <translation>数据错误闭锁</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="67"/>
        <source>Ubc</source>
        <translation>线电压Ubc</translation>
    </message>
    <message>
        <source>Ic</source>
        <translation type="obsolete">C相电流</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="60"/>
        <source>Uab</source>
        <translation>线电压Uab</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="53"/>
        <source>f</source>
        <translation>频率</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="39"/>
        <source>q</source>
        <translation>无功功率</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="32"/>
        <source>pYcNum</source>
        <translation>有功功率</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="183"/>
        <source>select chunnel</source>
        <translation>选择通道</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="95"/>
        <source>Uc</source>
        <translation>C相电压</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="88"/>
        <source>Ub</source>
        <translation>B相电压</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="196"/>
        <source>addToCurrentChunnel</source>
        <translation>添加到通道</translation>
    </message>
    <message>
        <source>Ia</source>
        <translation type="obsolete">A相电流</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="209"/>
        <source>CHUNNEL_YX</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="221"/>
        <source>UpLockYxNum</source>
        <translation>上闭锁</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="234"/>
        <source>DownLockYxNum</source>
        <translation>下闭锁</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="247"/>
        <source>IsRunningYXNum</source>
        <translation>运行状态</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.ui" line="260"/>
        <source>WorkStatusYXNum</source>
        <translation>工作状态</translation>
    </message>
    <message>
        <source>Switch</source>
        <translation type="obsolete">开关</translation>
    </message>
    <message>
        <source>Breaker</source>
        <translation type="obsolete">断路器</translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.cpp" line="56"/>
        <source>chunnel open failed!</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbuschunnelinfoconfigdlg.cpp" line="74"/>
        <source>add to the current channel£¿</source>
        <translation>确认添加到当前通道?</translation>
    </message>
</context>
<context>
    <name>QBusbarAgcLockDlg</name>
    <message>
        <location filename="qbusbaragclockdlg.ui" line="14"/>
        <source>QBusbarAgcLockDlg</source>
        <translation>AGC母线闭锁</translation>
    </message>
    <message>
        <location filename="qbusbaragclockdlg.ui" line="26"/>
        <source>busbarName</source>
        <translation>母线名称</translation>
    </message>
    <message>
        <location filename="qbusbaragclockdlg.ui" line="39"/>
        <source>TextLabel</source>
        <translation>文字标签</translation>
    </message>
    <message>
        <location filename="qbusbaragclockdlg.ui" line="52"/>
        <source>lockType</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qbusbaragclockdlg.ui" line="75"/>
        <source>restoreWaitTime</source>
        <translation>恢复时间</translation>
    </message>
    <message>
        <location filename="qbusbaragclockdlg.ui" line="98"/>
        <source>second</source>
        <translation>秒</translation>
    </message>
    <message>
        <location filename="qbusbaragclockdlg.ui" line="121"/>
        <source>isManRestore</source>
        <translation>是否人工恢复</translation>
    </message>
    <message>
        <location filename="qbusbaragclockdlg.ui" line="134"/>
        <source>relatedYxNum</source>
        <translation>关联遥信</translation>
    </message>
    <message>
        <location filename="qbusbaragclockdlg.ui" line="167"/>
        <source>num</source>
        <translation>编号编号</translation>
    </message>
    <message>
        <location filename="qbusbaragclockdlg.ui" line="180"/>
        <location filename="qbusbaragclockdlg.ui" line="193"/>
        <location filename="qbusbaragclockdlg.ui" line="206"/>
        <location filename="qbusbaragclockdlg.ui" line="219"/>
        <source>PushButton</source>
        <translation>确定</translation>
    </message>
</context>
<context>
    <name>QBusbarHisCurveView</name>
    <message>
        <source>QBusbarHisCurveView</source>
        <translation type="obsolete">母线历史曲线</translation>
    </message>
    <message>
        <source>V</source>
        <translation type="obsolete">电压值</translation>
    </message>
    <message>
        <source>HV</source>
        <translation type="obsolete">最高值</translation>
    </message>
    <message>
        <source>LV</source>
        <translation type="obsolete">最低值</translation>
    </message>
    <message>
        <source>Current Volt</source>
        <translation type="obsolete">当前电压</translation>
    </message>
    <message>
        <source>Max Volt</source>
        <translation type="obsolete">最大电压</translation>
    </message>
    <message>
        <source>Min Volt</source>
        <translation type="obsolete">最小电压</translation>
    </message>
    <message>
        <source>Plan Volt</source>
        <oldsource>PlanV</oldsource>
        <translation type="obsolete">计划电压</translation>
    </message>
    <message>
        <location filename="qbusbarhiscurveview.cpp" line="36"/>
        <source>Current p</source>
        <translation>当前有功</translation>
    </message>
    <message>
        <location filename="qbusbarhiscurveview.cpp" line="37"/>
        <source>Max p</source>
        <translation>最大有功</translation>
    </message>
    <message>
        <location filename="qbusbarhiscurveview.cpp" line="38"/>
        <source>Min p</source>
        <translation>最小有功</translation>
    </message>
    <message>
        <location filename="qbusbarhiscurveview.cpp" line="39"/>
        <source>Plan p</source>
        <translation>计划有功</translation>
    </message>
    <message>
        <location filename="qbusbarhiscurveview.cpp" line="41"/>
        <source>Busbar History Curve</source>
        <oldsource>BusbarHisCurve</oldsource>
        <translation>母线有功历史曲线</translation>
    </message>
    <message>
        <location filename="qbusbarhiscurveview.cpp" line="139"/>
        <source>his_curve_bus open failed!</source>
        <translation>打开历史曲线失败！</translation>
    </message>
    <message>
        <location filename="qbusbarhiscurveview.cpp" line="165"/>
        <source>BusbarPHisCurve</source>
        <translation>有功历史曲线</translation>
    </message>
    <message>
        <source>BusbarVHisCurve</source>
        <translation type="obsolete">母线电压历史曲线</translation>
    </message>
    <message>
        <source>Q</source>
        <translation type="obsolete">无功值</translation>
    </message>
    <message>
        <location filename="qbusbarhiscurveview.ui" line="14"/>
        <source>ScrollArea</source>
        <translation>母线有功历史曲线</translation>
    </message>
</context>
<context>
    <name>QBusbarHisSelDlg</name>
    <message>
        <location filename="qbusbarhisseldlg.ui" line="14"/>
        <source>QBusbarHisSelDlg</source>
        <translation>选择母线</translation>
    </message>
    <message>
        <location filename="qbusbarhisseldlg.ui" line="26"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qbusbarhisseldlg.ui" line="39"/>
        <source>BusbarSelect</source>
        <translation>选择母线</translation>
    </message>
    <message>
        <location filename="qbusbarhisseldlg.ui" line="52"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qbusbarhisseldlg.ui" line="75"/>
        <source>yyyy/MM/dd :mm:ss</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbusbarhisseldlg.ui" line="88"/>
        <source>start time</source>
        <translation>起始时间</translation>
    </message>
    <message>
        <location filename="qbusbarhisseldlg.ui" line="101"/>
        <source>yyyy/MM/dd hh:mm:ss</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbusbarhisseldlg.ui" line="114"/>
        <source>end time</source>
        <translation>终止时间</translation>
    </message>
</context>
<context>
    <name>QBusbarLock</name>
    <message>
        <location filename="qbusbarlock.ui" line="14"/>
        <source>QBusbarLock</source>
        <translation>母线自定义闭锁</translation>
    </message>
    <message>
        <location filename="qbusbarlock.ui" line="26"/>
        <source>IDC_YC</source>
        <translation>遥测条件</translation>
    </message>
    <message>
        <location filename="qbusbarlock.ui" line="62"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qbusbarlock.ui" line="75"/>
        <source>busbar</source>
        <translation>母线</translation>
    </message>
    <message>
        <location filename="qbusbarlock.ui" line="88"/>
        <source>restoreWaitTime</source>
        <translation>恢复时间</translation>
    </message>
    <message>
        <location filename="qbusbarlock.ui" line="111"/>
        <source>restoreType</source>
        <translation>恢复类型</translation>
    </message>
    <message>
        <location filename="qbusbarlock.ui" line="123"/>
        <source>auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <location filename="qbusbarlock.ui" line="136"/>
        <source>man</source>
        <translation>人工</translation>
    </message>
    <message>
        <location filename="qbusbarlock.ui" line="160"/>
        <source>lockname</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qbusbarlock.ui" line="173"/>
        <source>relatedYx</source>
        <translation>关联遥信</translation>
    </message>
    <message>
        <location filename="qbusbarlock.ui" line="206"/>
        <source>IDC_YX</source>
        <translation>遥信条件</translation>
    </message>
    <message>
        <location filename="qbusbarlock.ui" line="219"/>
        <source>IDC_LOCK_ADD</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="qbusbarlock.ui" line="232"/>
        <source>IDC_DELETE</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="qbusbarlock.ui" line="245"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qbusbarlock.ui" line="258"/>
        <source>IDOK</source>
        <translation>修改</translation>
    </message>
    <message>
        <location filename="qbusbarlock.cpp" line="25"/>
        <source>total lock</source>
        <translation>总闭锁</translation>
    </message>
    <message>
        <location filename="qbusbarlock.cpp" line="27"/>
        <source>lock up</source>
        <translation>上闭锁</translation>
    </message>
    <message>
        <location filename="qbusbarlock.cpp" line="29"/>
        <source>lock down</source>
        <translation>下闭锁</translation>
    </message>
    <message>
        <location filename="qbusbarlock.cpp" line="282"/>
        <source>really delete?</source>
        <translation>确定删除？</translation>
    </message>
    <message>
        <location filename="qbusbarlock.cpp" line="331"/>
        <source>deleted</source>
        <translation>已删除！</translation>
    </message>
    <message>
        <location filename="qbusbarlock.cpp" line="549"/>
        <location filename="qbusbarlockconditionycdlg.cpp" line="385"/>
        <source>manuset table open faulse!</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QBusbarLockConditionYCDlg</name>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="14"/>
        <source>QBusbarLockConditionYCDlg</source>
        <translation>闭锁遥测条件</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="26"/>
        <source>threshold</source>
        <translation>门槛值</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="39"/>
        <source>relatedYc</source>
        <oldsource>relatedYx</oldsource>
        <translation>关联遥测</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="52"/>
        <source>IDOK</source>
        <translation>修改</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="65"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="78"/>
        <source>deadArea</source>
        <translation>死区</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="101"/>
        <source>conditionnum</source>
        <translation>条件编号</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="114"/>
        <source>busbar</source>
        <translation>母线</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="150"/>
        <source>lockname</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="163"/>
        <source>checkType</source>
        <translation>比较类型</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="175"/>
        <source>&gt;=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="188"/>
        <source>&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="201"/>
        <source>=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="214"/>
        <source>&lt;=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="227"/>
        <source>&lt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="251"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="304"/>
        <source>IDC_ADD</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.ui" line="317"/>
        <source>IDC_DELETE</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="qbusbarlock.cpp" line="411"/>
        <location filename="qbusbarlockconditionycdlg.cpp" line="275"/>
        <source>update faulse!!!</source>
        <translation>更新失败！</translation>
    </message>
    <message>
        <location filename="qbusbarlock.cpp" line="416"/>
        <source>updated!!!</source>
        <translation>修改成功！</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.cpp" line="47"/>
        <source>really delete?</source>
        <translation>确定删除？</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.cpp" line="110"/>
        <location filename="qbusbarlockconditionycdlg.cpp" line="335"/>
        <location filename="qbusbarlockconditionycdlg.cpp" line="435"/>
        <source>locktype error</source>
        <translation>闭锁类型错误</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.cpp" line="119"/>
        <source>deleted</source>
        <translation>已删除！</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionycdlg.cpp" line="125"/>
        <source>no record </source>
        <translation>无记录！</translation>
    </message>
</context>
<context>
    <name>QBusbarLockConditionYXDlg</name>
    <message>
        <location filename="qbusbarlockconditionyxdlg.ui" line="14"/>
        <source>QBusbarLockConditionYXDlg</source>
        <translation>闭锁遥信条件</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyxdlg.ui" line="56"/>
        <source>threshold</source>
        <translation>门槛值</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyxdlg.ui" line="89"/>
        <source>conditionnum</source>
        <translation>条件编号</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyxdlg.ui" line="112"/>
        <source>IDC_DELETE</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyxdlg.ui" line="125"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyxdlg.ui" line="151"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyxdlg.ui" line="164"/>
        <source>IDC_ADD</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyxdlg.ui" line="177"/>
        <source>IDOK</source>
        <translation>修改</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyxdlg.ui" line="190"/>
        <source>busbar</source>
        <translation>母线</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyxdlg.ui" line="203"/>
        <source>lockname</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyxdlg.ui" line="216"/>
        <source>relatedYx</source>
        <translation>关联遥信</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyxdlg.cpp" line="45"/>
        <source>really delete?</source>
        <translation>确定删除？</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyxdlg.cpp" line="103"/>
        <location filename="qbusbarlockconditionyxdlg.cpp" line="229"/>
        <location filename="qbusbarlockconditionyxdlg.cpp" line="469"/>
        <source>locktype error</source>
        <translation>闭锁类型错误</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyxdlg.cpp" line="110"/>
        <source>deleted</source>
        <translation>已删除！</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyxdlg.cpp" line="116"/>
        <source>no record </source>
        <translation>无记录！</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyxdlg.cpp" line="153"/>
        <source>update faulse!!!</source>
        <translation>更新失败！</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyxdlg.cpp" line="312"/>
        <source>manuset table open faulse!</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QBusbarLock_ADD</name>
    <message>
        <location filename="qbusbarlock_add.ui" line="14"/>
        <source>QBusbarLock_ADD</source>
        <translation>添加闭锁</translation>
    </message>
    <message>
        <location filename="qbusbarlock_add.ui" line="39"/>
        <source>lockname</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qbusbarlock_add.ui" line="62"/>
        <source>locknum</source>
        <translation>闭锁编号</translation>
    </message>
    <message>
        <location filename="qbusbarlock_add.ui" line="85"/>
        <source>restoreWaitTime</source>
        <translation>恢复时间</translation>
    </message>
    <message>
        <location filename="qbusbarlock_add.ui" line="121"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qbusbarlock_add.ui" line="147"/>
        <source>busbar</source>
        <translation>母线</translation>
    </message>
    <message>
        <location filename="qbusbarlock_add.ui" line="173"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qbusbarlock_add.ui" line="186"/>
        <source>IDOKADD</source>
        <oldsource>IDOK</oldsource>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qbusbarlock_add.ui" line="199"/>
        <source>relatedYx</source>
        <translation>关联遥信</translation>
    </message>
    <message>
        <location filename="qbusbarlock_add.ui" line="212"/>
        <source>restoreType</source>
        <translation>恢复类型</translation>
    </message>
    <message>
        <location filename="qbusbarlock_add.ui" line="224"/>
        <source>auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <location filename="qbusbarlock_add.ui" line="237"/>
        <source>man</source>
        <translation>人工</translation>
    </message>
    <message>
        <location filename="qbusbarlock_add.cpp" line="93"/>
        <source>please enter restoretype </source>
        <translation>请输入恢复类型！</translation>
    </message>
    <message>
        <location filename="qbusbarlock_add.cpp" line="99"/>
        <source>please enter lock name</source>
        <translation>请输入闭锁名称！</translation>
    </message>
    <message>
        <location filename="qbusbarlock_add.cpp" line="114"/>
        <source>exist </source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbusbarlock_add.cpp" line="166"/>
        <source>inserted</source>
        <translation>添加成功！</translation>
    </message>
    <message>
        <location filename="qbusbarlock_add.cpp" line="186"/>
        <location filename="qbusbarlock_add.cpp" line="209"/>
        <source>YX_DATA open failed!</source>
        <translation>yx_data打开失败！</translation>
    </message>
</context>
<context>
    <name>QBusbarRealCurveView</name>
    <message>
        <source>QBusbarRealCurveView</source>
        <translation type="obsolete">母线电压实时曲线</translation>
    </message>
    <message>
        <source>RealV</source>
        <translation type="obsolete">实时电压</translation>
    </message>
    <message>
        <source>PlanV</source>
        <translation type="obsolete">计划电压</translation>
    </message>
    <message>
        <source>BusbarVRealTimeCurve</source>
        <translation type="obsolete">电压实时曲线</translation>
    </message>
    <message>
        <location filename="qbusbarrealcurveview.cpp" line="40"/>
        <location filename="qbusbarrealcurveview.cpp" line="104"/>
        <source>BusbarPRealTimeCurve</source>
        <translation>有功实时曲线</translation>
    </message>
    <message>
        <location filename="qbusbarrealcurveview.cpp" line="43"/>
        <source>RealP</source>
        <translation>实时有功</translation>
    </message>
    <message>
        <location filename="qbusbarrealcurveview.cpp" line="44"/>
        <source>PlanP</source>
        <translation>计划有功</translation>
    </message>
    <message>
        <location filename="qbusbarrealcurveview.cpp" line="94"/>
        <source>realP:</source>
        <translation>实时有功:</translation>
    </message>
    <message>
        <location filename="qbusbarrealcurveview.cpp" line="94"/>
        <source>    planP:</source>
        <translation>    计划有功:</translation>
    </message>
    <message>
        <location filename="qbusbarrealcurveview.ui" line="14"/>
        <source>ScrollArea</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QBusbarSelectDlg</name>
    <message>
        <location filename="qbusbarselectdlg.ui" line="14"/>
        <source>QBusbarSelectDlg</source>
        <translation>母线电压实时曲线</translation>
    </message>
    <message>
        <location filename="qbusbarselectdlg.ui" line="36"/>
        <source>BusbarSelect</source>
        <translation>选择母线</translation>
    </message>
    <message>
        <location filename="qbusbarselectdlg.ui" line="62"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qbusbarselectdlg.ui" line="49"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>QBusbarVQDialog</name>
    <message>
        <source>QBusbarVQDialog</source>
        <translation type="obsolete">母线电压无功</translation>
    </message>
    <message>
        <source>delete</source>
        <translation type="obsolete">删除</translation>
    </message>
    <message>
        <source>CANCEL</source>
        <translation type="obsolete">取消</translation>
    </message>
    <message>
        <source>modify</source>
        <translation type="obsolete">确认修改</translation>
    </message>
    <message>
        <source>add</source>
        <translation type="obsolete">增加</translation>
    </message>
    <message>
        <source>V</source>
        <translation type="obsolete">电压</translation>
    </message>
    <message>
        <source>Q</source>
        <translation type="obsolete">无功</translation>
    </message>
</context>
<context>
    <name>QBusbarlockConditionYC_ADD</name>
    <message>
        <location filename="qbusbarlockconditionyc_add.ui" line="14"/>
        <source>QBusbarlockConditionYC_ADD</source>
        <translation>添加遥测条件</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.ui" line="26"/>
        <source>busbar</source>
        <translation>母线</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.ui" line="52"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.ui" line="78"/>
        <source>lockNAME</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.ui" line="104"/>
        <source>conditionnum</source>
        <translation>条件编号</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.ui" line="130"/>
        <source>checkType</source>
        <translation>比较类型</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.ui" line="142"/>
        <source>&gt;=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.ui" line="155"/>
        <source>&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.ui" line="168"/>
        <source>=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.ui" line="181"/>
        <source>&lt;=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.ui" line="194"/>
        <source>&lt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.ui" line="231"/>
        <source>threshold</source>
        <translation>门槛值</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.ui" line="254"/>
        <source>deadArea</source>
        <translation>死区</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.ui" line="277"/>
        <source>IDOKADD</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.ui" line="290"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.ui" line="303"/>
        <source>relatedYc</source>
        <oldsource>relatedYx</oldsource>
        <translation>关联遥测</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.cpp" line="123"/>
        <source>please unter checktype</source>
        <translation>请输入比较类型！</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.cpp" line="189"/>
        <source>INSERT</source>
        <translation>添加成功！</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyc_add.cpp" line="228"/>
        <source>YC_DATA open failed!</source>
        <translation>yc_data打开失败！</translation>
    </message>
</context>
<context>
    <name>QBusbarlockConditionYX_ADD</name>
    <message>
        <location filename="qbusbarlockconditionyx_add.ui" line="14"/>
        <source>QBusbarlockConditionYX_ADD</source>
        <translation>闭锁遥信条件</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyx_add.ui" line="39"/>
        <source>conditionnum</source>
        <translation>条件编号</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyx_add.ui" line="65"/>
        <source>lockname</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyx_add.ui" line="111"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyx_add.ui" line="124"/>
        <source>threshold</source>
        <translation>门槛值</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyx_add.ui" line="150"/>
        <source>busbar</source>
        <translation>母线</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyx_add.ui" line="176"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyx_add.ui" line="189"/>
        <source>IDOKADD</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyx_add.ui" line="202"/>
        <source>relatedYx</source>
        <translation>关联遥信</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyx_add.cpp" line="33"/>
        <source>exist </source>
        <translation></translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyx_add.cpp" line="97"/>
        <source>inserted</source>
        <translation>添加成功！</translation>
    </message>
    <message>
        <location filename="qbusbarlockconditionyx_add.cpp" line="220"/>
        <source>YX_DATA open failed!</source>
        <translation>yx_data打开失败！</translation>
    </message>
</context>
<context>
    <name>QChunnelInfoConfigDlg</name>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="14"/>
        <source>QChunnelInfoConfigDlg</source>
        <translation>机组通道组态</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="26"/>
        <source>select chunnel</source>
        <translation>选择通道</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="49"/>
        <source>pYcNum</source>
        <translation>系统有功功率</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="62"/>
        <source>q</source>
        <translation>系统无功功率</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="75"/>
        <source>fYcNum</source>
        <translation>系统频率</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="88"/>
        <source>planPYcNum</source>
        <translation>计划有功返回值</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="101"/>
        <source>planPExcuteYcNum</source>
        <translation>计划有功执行值</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="114"/>
        <source>ExTargetPYcNum</source>
        <translation>目标有功执行值</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="127"/>
        <source>lineUab</source>
        <translation>线电压Uab</translation>
    </message>
    <message>
        <source>rotor current</source>
        <translation type="obsolete">转子电流</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="140"/>
        <source>PUpLimitYcNum</source>
        <translation>有功功率上限</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="153"/>
        <source>PDownLimitYcNum</source>
        <translation>有功功率下限</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="217"/>
        <source>speedUpLimitYcNum</source>
        <translation>速度上限</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="230"/>
        <source>speedDownLimitYcNum</source>
        <translation>速度下限</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="243"/>
        <source>coalConsumptionYcNum</source>
        <translation>煤耗</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="256"/>
        <source>thermalPowerYcNum</source>
        <translation>热功率</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="269"/>
        <source>dustYcNum</source>
        <translation>除尘</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="282"/>
        <source>thermalPlanYcNum</source>
        <translation>热功率计划值</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="295"/>
        <source>SO2YcNum</source>
        <translation>二氧化硫</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="308"/>
        <source>NOXYcNum</source>
        <translation>氮氧化物</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="334"/>
        <source>B phase current</source>
        <translation>B相电流</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="347"/>
        <source>A phase current</source>
        <translation>A相电流</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="373"/>
        <source>forbidSub</source>
        <translation>禁止减</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="386"/>
        <source>maxAdjustYxNum</source>
        <translation>多次调整无效闭锁</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="399"/>
        <source>invalidMeasureYxNum</source>
        <translation>无效量测闭锁</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="412"/>
        <source>rb</source>
        <translation>RB</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="425"/>
        <source>forbidAdd</source>
        <translation>禁止增</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="438"/>
        <source>isRunningYXNum</source>
        <translation>运行状态</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="451"/>
        <source>megcPermitYxNum</source>
        <translation>AGC允许</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="464"/>
        <source>gridConnect</source>
        <translation>电网连接</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="477"/>
        <source>protect</source>
        <translation>保护</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="490"/>
        <source>thermalRunning</source>
        <translation>热功率投/退</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="503"/>
        <source>ComFailureLock</source>
        <translation>通讯故障闭锁</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="166"/>
        <source>lineUca</source>
        <translation>线电压Uca</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="179"/>
        <source>lineUbc</source>
        <translation>线电压Ubc</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="321"/>
        <source>C phase current</source>
        <translation>C相电流</translation>
    </message>
    <message>
        <source>factoryAUab</source>
        <translation type="obsolete">A段厂用电Uab</translation>
    </message>
    <message>
        <source>factoryBUab</source>
        <translation type="obsolete">B段厂用电Uab</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="192"/>
        <source>CHUNNEL_YC</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="204"/>
        <source>cos</source>
        <translation>系统功率因数</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="361"/>
        <source>CHUNNEL_YX</source>
        <translation></translation>
    </message>
    <message>
        <source>AGCInput/Exit</source>
        <translation type="obsolete">AGC投/退</translation>
    </message>
    <message>
        <source>TransHighMainBusSwitch</source>
        <translation type="obsolete">主变高压侧正母闸刀</translation>
    </message>
    <message>
        <source>TransHighSecondBusSwitch</source>
        <translation type="obsolete">主变高压侧副母闸刀</translation>
    </message>
    <message>
        <source>CabinetHandle</source>
        <translation type="obsolete">机柜手柄</translation>
    </message>
    <message>
        <source>ProtectActionAndFault</source>
        <translation type="obsolete">保护动作及故障</translation>
    </message>
    <message>
        <source>TransHighBreaker</source>
        <translation type="obsolete">主变高压侧断路器开关</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="516"/>
        <source>RemoteHandle</source>
        <translation>远方手柄</translation>
    </message>
    <message>
        <source>AVRAbnormalSignalTotal</source>
        <translation type="obsolete">AVR异常信号总</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="530"/>
        <source>CHUNNEL_YS</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="536"/>
        <source>planPowerYs</source>
        <translation>计划有功</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="543"/>
        <source>pulseUpYs</source>
        <translation>增磁指令</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="550"/>
        <source>pulseDown</source>
        <translation>减磁指令</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="566"/>
        <source>addToCurrentChunnel</source>
        <translation>添加到通道</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.ui" line="579"/>
        <source>quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.cpp" line="76"/>
        <source>chunnel open failed!</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qchunnelinfoconfigdlg.cpp" line="94"/>
        <source>add to the current channel£¿</source>
        <translation>确认添加到当前通道?</translation>
    </message>
</context>
<context>
    <name>QDbConnectDlg</name>
    <message>
        <source>Data Source Set</source>
        <translation type="obsolete">数据源设置</translation>
    </message>
    <message>
        <source>Database</source>
        <translation type="obsolete">数据库</translation>
    </message>
    <message>
        <source>Driver</source>
        <translation type="obsolete">驱动程序</translation>
    </message>
    <message>
        <source>Server</source>
        <translation type="obsolete">服务器</translation>
    </message>
    <message>
        <source>user</source>
        <translation type="obsolete">用户名</translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="obsolete">密码</translation>
    </message>
    <message>
        <source>NodeNum</source>
        <translation type="obsolete">节点编号</translation>
    </message>
</context>
<context>
    <name>QDdTableView</name>
    <message>
        <source>number</source>
        <translation type="obsolete">编号</translation>
    </message>
    <message>
        <source>substation number</source>
        <translation type="obsolete">子站编号</translation>
    </message>
    <message>
        <source>line number</source>
        <translation type="obsolete">线路编号</translation>
    </message>
    <message>
        <source>name</source>
        <translation type="obsolete">名称</translation>
    </message>
    <message>
        <source>attribute</source>
        <translation type="obsolete">属性</translation>
    </message>
    <message>
        <source>process type</source>
        <translation type="obsolete">处理类型</translation>
    </message>
    <message>
        <source>coefficient</source>
        <translation type="obsolete">系数</translation>
    </message>
    <message>
        <source>raw data</source>
        <translation type="obsolete">生数据</translation>
    </message>
    <message>
        <source>real value</source>
        <translation type="obsolete">实际值</translation>
    </message>
    <message>
        <source>update time</source>
        <translation type="obsolete">更新时间</translation>
    </message>
</context>
<context>
    <name>QGenCoalCurveDlg</name>
    <message>
        <location filename="qgencoalcurvedlg.ui" line="14"/>
        <source>QGenCoalCurveDlg</source>
        <translation>煤耗曲线</translation>
    </message>
    <message>
        <location filename="qgencoalcurvedlg.ui" line="26"/>
        <source>TextLabel</source>
        <translation>文字标签</translation>
    </message>
    <message utf8="true">
        <location filename="qgencoalcurvedlg.ui" line="64"/>
        <source>拟合</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qgencoalcurvedlg.cpp" line="41"/>
        <source>Active Power</source>
        <translation>有功</translation>
    </message>
    <message>
        <location filename="qgencoalcurvedlg.cpp" line="42"/>
        <source>Coal Consume</source>
        <translation>煤耗</translation>
    </message>
    <message>
        <location filename="qgencoalcurvedlg.cpp" line="68"/>
        <source>Data Curve</source>
        <translation>数据曲线</translation>
    </message>
    <message>
        <location filename="qgencoalcurvedlg.cpp" line="79"/>
        <source>Polyfit Curve</source>
        <translation>拟合曲线</translation>
    </message>
</context>
<context>
    <name>QGenerator</name>
    <message>
        <location filename="boiler.cpp" line="628"/>
        <location filename="boiler.cpp" line="661"/>
        <location filename="generator.cpp" line="1364"/>
        <location filename="generator.cpp" line="1397"/>
        <location filename="manualsetsheetdialog.cpp" line="1294"/>
        <source>.if execute?</source>
        <translation>是否执行？</translation>
    </message>
    <message>
        <location filename="generator.cpp" line="1362"/>
        <source>Digital output:</source>
        <translation>数字量输出：</translation>
    </message>
    <message>
        <location filename="generator.cpp" line="1389"/>
        <source>Add Pulse output :</source>
        <translation>增脉冲输出：</translation>
    </message>
    <message>
        <location filename="generator.cpp" line="1393"/>
        <source>Sub Pulse output :</source>
        <translation>减脉冲输出：</translation>
    </message>
    <message>
        <location filename="generator.cpp" line="1421"/>
        <source>adjustpower:</source>
        <translation>单机定负荷调整:</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="1278"/>
        <source>Over uplimit</source>
        <translation>设定值越上限</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="1286"/>
        <source>Over downlimit</source>
        <translation>设定值越下限</translation>
    </message>
    <message>
        <location filename="manualsetsheetdialog.cpp" line="1292"/>
        <source>manualsetoutput:</source>
        <translation>定负荷调整设定值为：</translation>
    </message>
</context>
<context>
    <name>QGeneratorHisCurveView</name>
    <message>
        <source>QGeneratorHisCurveView</source>
        <translation type="obsolete">机组历史曲线</translation>
    </message>
    <message>
        <source>V</source>
        <translation type="obsolete">电压</translation>
    </message>
    <message>
        <source>Q</source>
        <translation type="obsolete">无功</translation>
    </message>
    <message>
        <source>HQ</source>
        <translation type="obsolete">最高值</translation>
    </message>
    <message>
        <source>LQ</source>
        <translation type="obsolete">最低值</translation>
    </message>
    <message>
        <source>PlanQ</source>
        <translation type="obsolete">计划无功</translation>
    </message>
    <message>
        <source>GenHisCurve</source>
        <translation type="obsolete">历史曲线</translation>
    </message>
    <message>
        <source>VHisCurveView</source>
        <translation type="obsolete">机端电压曲线</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="39"/>
        <source>current p</source>
        <oldsource>current reactive power</oldsource>
        <translation>实时无功</translation>
    </message>
    <message>
        <source>max reactive power</source>
        <translation type="obsolete">最大无功</translation>
    </message>
    <message>
        <source>min reactive power</source>
        <translation type="obsolete">最小无功</translation>
    </message>
    <message>
        <source>Plan reactive power</source>
        <translation type="obsolete">计划无功</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="40"/>
        <source>max p</source>
        <translation>最大有功</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="41"/>
        <source>min p</source>
        <translation>最小有功</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="42"/>
        <source>avg p</source>
        <translation>平均有功</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="43"/>
        <source>Plan p</source>
        <translation>计划有功</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="45"/>
        <source>current thermal</source>
        <translation>当前热功率</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="46"/>
        <source>max thermal</source>
        <translation>最大热功率</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="47"/>
        <source>min thermal</source>
        <translation>最小热功率</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="48"/>
        <source>avg thermal</source>
        <translation>平均热功率</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="49"/>
        <source>Plan thermal</source>
        <translation>计划热功率</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="51"/>
        <source>current coal</source>
        <translation>当前煤耗</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="52"/>
        <source>max coal</source>
        <translation>最大煤耗</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="53"/>
        <source>min coal</source>
        <translation>最小煤耗</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="54"/>
        <source>avg coal</source>
        <translation>平均煤耗</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="56"/>
        <source>Generator History Curve</source>
        <translation>机组有功历史曲线</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="157"/>
        <location filename="qgeneratorhiscurveview.cpp" line="330"/>
        <location filename="qgeneratorhiscurveview.cpp" line="451"/>
        <source>his_curve_gen open failed!</source>
        <translation>打开机组历史曲线失败！</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="185"/>
        <source>QHisCurvepView</source>
        <oldsource>QHisCurveView</oldsource>
        <translation>有功历史曲线</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="374"/>
        <source>QHisCurveThermalView</source>
        <translation>热功率历史曲线</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.cpp" line="485"/>
        <source>QHisCurveCoalView</source>
        <translation>煤耗历史曲线</translation>
    </message>
    <message>
        <location filename="qgeneratorhiscurveview.ui" line="14"/>
        <source>ScrollArea</source>
        <translation>机组有功历史曲线</translation>
    </message>
</context>
<context>
    <name>QGeneratorHisSelDlg</name>
    <message>
        <location filename="qgeneratorhisseldlg.ui" line="14"/>
        <source>QGeneratorHisSelDlg</source>
        <translation>选择机组</translation>
    </message>
    <message>
        <location filename="qgeneratorhisseldlg.ui" line="26"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qgeneratorhisseldlg.ui" line="39"/>
        <source>GenSelect</source>
        <translation>选择机组</translation>
    </message>
    <message>
        <location filename="qgeneratorhisseldlg.ui" line="52"/>
        <location filename="qgeneratorhisseldlg.ui" line="104"/>
        <source>yyyy/MM/dd hh:mm:ss</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qgeneratorhisseldlg.ui" line="65"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qgeneratorhisseldlg.ui" line="78"/>
        <source>start time</source>
        <translation>起始时间</translation>
    </message>
    <message>
        <location filename="qgeneratorhisseldlg.ui" line="91"/>
        <source>end time</source>
        <translation>终止时间</translation>
    </message>
</context>
<context>
    <name>QGeneratorLock</name>
    <message>
        <location filename="qgeneratorlock.ui" line="14"/>
        <source>QGeneratorLock</source>
        <translation>自定义闭锁</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.ui" line="26"/>
        <source>IDC_YC</source>
        <translation>遥测条件</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.ui" line="62"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.ui" line="75"/>
        <source>generator</source>
        <translation>机组</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.ui" line="88"/>
        <source>restoreWaitTime</source>
        <translation>恢复时间</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.ui" line="111"/>
        <source>restoreType</source>
        <translation>恢复类型</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.ui" line="123"/>
        <source>auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.ui" line="136"/>
        <source>man</source>
        <translation>人工</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.ui" line="160"/>
        <source>lockname</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.ui" line="173"/>
        <source>relatedYx</source>
        <translation>关联遥信</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.ui" line="206"/>
        <source>IDC_YX</source>
        <translation>遥信条件</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.ui" line="219"/>
        <source>IDC_LOCK_ADD</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.ui" line="232"/>
        <source>IDC_DELETE</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.ui" line="245"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.ui" line="258"/>
        <source>IDOK</source>
        <translation>修改</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.cpp" line="25"/>
        <source>total lock</source>
        <translation>总闭锁</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.cpp" line="27"/>
        <source>lock up</source>
        <translation>上闭锁</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.cpp" line="29"/>
        <source>lock down</source>
        <translation>下闭锁</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.cpp" line="284"/>
        <source>really delete?</source>
        <translation>确定删除？</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.cpp" line="333"/>
        <source>deleted</source>
        <translation>已删除！</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.cpp" line="551"/>
        <location filename="qgeneratorlockconditionycdlg.cpp" line="385"/>
        <source>manuset table open faulse!</source>
        <translation>打开数据库失败!</translation>
    </message>
</context>
<context>
    <name>QGeneratorLockConditionYCDlg</name>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="14"/>
        <source>QGeneratorLockConditionYCDlg</source>
        <translation>闭锁遥测条件</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="26"/>
        <source>threshold</source>
        <translation>门槛值</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="39"/>
        <source>relatedYc</source>
        <oldsource>relatedYx</oldsource>
        <translation>关联遥测</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="52"/>
        <source>IDOK</source>
        <translation>修改</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="65"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="78"/>
        <source>deadArea</source>
        <translation>死区</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="101"/>
        <source>conditionnum</source>
        <translation>条件编号</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="114"/>
        <source>generator</source>
        <translation>机组</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="150"/>
        <source>lockname</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="163"/>
        <source>checkType</source>
        <translation>比较类型</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="175"/>
        <source>&gt;=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="188"/>
        <source>&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="201"/>
        <source>=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="214"/>
        <source>&lt;=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="227"/>
        <source>&lt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="251"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="304"/>
        <source>IDC_ADD</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.ui" line="317"/>
        <source>IDC_DELETE</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.cpp" line="413"/>
        <location filename="qgeneratorlockconditionycdlg.cpp" line="275"/>
        <source>update faulse!!!</source>
        <translation>更新失败！</translation>
    </message>
    <message>
        <location filename="qgeneratorlock.cpp" line="418"/>
        <source>updated!!!</source>
        <translation>修改成功！</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.cpp" line="47"/>
        <source>really delete?</source>
        <translation>确定删除？</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.cpp" line="110"/>
        <location filename="qgeneratorlockconditionycdlg.cpp" line="335"/>
        <location filename="qgeneratorlockconditionycdlg.cpp" line="435"/>
        <source>locktype error</source>
        <translation>闭锁类型错误</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.cpp" line="119"/>
        <source>deleted</source>
        <translation>已删除！</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionycdlg.cpp" line="125"/>
        <source>no record </source>
        <translation>无记录！</translation>
    </message>
</context>
<context>
    <name>QGeneratorLockConditionYXDlg</name>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.ui" line="14"/>
        <source>QGeneratorrLockConditionYXDlg</source>
        <translation>闭锁遥信条件</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.ui" line="56"/>
        <source>threshold</source>
        <translation>门槛值</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.ui" line="89"/>
        <source>conditionnum</source>
        <translation>条件编号</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.ui" line="112"/>
        <source>IDC_DELETE</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.ui" line="125"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.ui" line="151"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.ui" line="164"/>
        <source>IDC_ADD</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.ui" line="177"/>
        <source>IDOK</source>
        <translation>修改</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.ui" line="190"/>
        <source>generator</source>
        <translation>机组</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.ui" line="203"/>
        <source>lockname</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.ui" line="216"/>
        <source>relatedYx</source>
        <translation>关联遥信</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.cpp" line="45"/>
        <source>really delete?</source>
        <translation>确定删除？</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.cpp" line="103"/>
        <location filename="qgeneratorlockconditionyxdlg.cpp" line="229"/>
        <location filename="qgeneratorlockconditionyxdlg.cpp" line="469"/>
        <source>locktype error</source>
        <translation>闭锁类型错误</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.cpp" line="110"/>
        <source>deleted</source>
        <translation>已删除！</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.cpp" line="116"/>
        <source>no record </source>
        <translation>无记录！</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.cpp" line="153"/>
        <source>update faulse!!!</source>
        <translation>更新失败！</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyxdlg.cpp" line="312"/>
        <source>manuset table open faulse!</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QGeneratorLock_ADD</name>
    <message>
        <location filename="qgeneratorlock_add.ui" line="14"/>
        <source>QGeneratorLock_ADD</source>
        <translation>添加闭锁</translation>
    </message>
    <message>
        <location filename="qgeneratorlock_add.ui" line="39"/>
        <source>lockname</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qgeneratorlock_add.ui" line="62"/>
        <source>locknum</source>
        <translation>闭锁编号</translation>
    </message>
    <message>
        <location filename="qgeneratorlock_add.ui" line="85"/>
        <source>restoreWaitTime</source>
        <translation>恢复时间</translation>
    </message>
    <message>
        <location filename="qgeneratorlock_add.ui" line="121"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qgeneratorlock_add.ui" line="147"/>
        <source>generator</source>
        <translation>机组</translation>
    </message>
    <message>
        <location filename="qgeneratorlock_add.ui" line="173"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qgeneratorlock_add.ui" line="186"/>
        <source>IDOKADD</source>
        <oldsource>IDOK</oldsource>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qgeneratorlock_add.ui" line="199"/>
        <source>relatedYx</source>
        <translation>关联遥信</translation>
    </message>
    <message>
        <location filename="qgeneratorlock_add.ui" line="212"/>
        <source>restoreType</source>
        <translation>恢复类型</translation>
    </message>
    <message>
        <location filename="qgeneratorlock_add.ui" line="224"/>
        <source>auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <location filename="qgeneratorlock_add.ui" line="237"/>
        <source>man</source>
        <translation>人工</translation>
    </message>
    <message>
        <location filename="qgeneratorlock_add.cpp" line="93"/>
        <source>please enter restoretype </source>
        <translation>请输入恢复类型！</translation>
    </message>
    <message>
        <location filename="qgeneratorlock_add.cpp" line="99"/>
        <source>please enter lock name</source>
        <translation>请输入闭锁名称！</translation>
    </message>
    <message>
        <location filename="qgeneratorlock_add.cpp" line="114"/>
        <source>exist </source>
        <translation></translation>
    </message>
    <message>
        <location filename="qgeneratorlock_add.cpp" line="166"/>
        <source>inserted</source>
        <translation>添加成功！</translation>
    </message>
    <message>
        <location filename="qgeneratorlock_add.cpp" line="186"/>
        <location filename="qgeneratorlock_add.cpp" line="209"/>
        <source>YX_DATA open failed!</source>
        <translation>yx_data打开失败！</translation>
    </message>
</context>
<context>
    <name>QGeneratorPQLimitDialog</name>
    <message>
        <source>QGeneratorPQLimitDialog</source>
        <translation type="obsolete">机组有功无功上下限设置</translation>
    </message>
    <message>
        <source>maxQUpLimit</source>
        <translation type="obsolete">最大无功上限</translation>
    </message>
    <message>
        <source>delete</source>
        <translation type="obsolete">删除</translation>
    </message>
    <message>
        <source>add</source>
        <translation type="obsolete">增加</translation>
    </message>
    <message>
        <source>minQUpLimit</source>
        <translation type="obsolete">最小无功上限</translation>
    </message>
    <message>
        <source>COUNT</source>
        <translation type="obsolete">点数</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">确定</translation>
    </message>
    <message>
        <source>CANCEL</source>
        <translation type="obsolete">取消</translation>
    </message>
    <message>
        <source>modify</source>
        <translation type="obsolete">确认修改</translation>
    </message>
    <message>
        <source>minP</source>
        <translation type="obsolete">最小有功</translation>
    </message>
    <message>
        <source>maxQ</source>
        <translation type="obsolete">最大有功</translation>
    </message>
    <message>
        <source>minQDownLimit</source>
        <translation type="obsolete">最小无功下限</translation>
    </message>
    <message>
        <source>maxQDownLimit</source>
        <translation type="obsolete">最大无功下限</translation>
    </message>
    <message>
        <source>P</source>
        <translation type="obsolete">有功</translation>
    </message>
    <message>
        <source>QUpLimit</source>
        <translation type="obsolete">无功上限</translation>
    </message>
    <message>
        <source>QDownLimit</source>
        <translation type="obsolete">无功下限</translation>
    </message>
</context>
<context>
    <name>QGeneratorQTimeDialog</name>
    <message>
        <source>QGeneratorQTimeDialog</source>
        <translation type="obsolete">机组无功脉冲设置</translation>
    </message>
    <message>
        <source>modify</source>
        <translation type="obsolete">确认修改</translation>
    </message>
    <message>
        <source>add</source>
        <translation type="obsolete">增加</translation>
    </message>
    <message>
        <source>delete</source>
        <translation type="obsolete">删除</translation>
    </message>
    <message>
        <source>minQ</source>
        <translation type="obsolete">最小无功</translation>
    </message>
    <message>
        <source>maxQ</source>
        <translation type="obsolete">最大无功</translation>
    </message>
    <message>
        <source>minTime</source>
        <translation type="obsolete">最小脉宽</translation>
    </message>
    <message>
        <source>maxTime</source>
        <translation type="obsolete">最大脉宽</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">确定</translation>
    </message>
    <message>
        <source>COUNT</source>
        <translation type="obsolete">点数</translation>
    </message>
    <message>
        <source>CANCEL</source>
        <translation type="obsolete">取消</translation>
    </message>
    <message>
        <source>Q</source>
        <translation type="obsolete">无功</translation>
    </message>
    <message>
        <source>TIME</source>
        <translation type="obsolete">脉冲</translation>
    </message>
</context>
<context>
    <name>QGeneratorRealCoalView</name>
    <message>
        <location filename="qgeneratorrealcoalview.ui" line="14"/>
        <source>ScrollArea</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qgeneratorrealcoalview.cpp" line="30"/>
        <location filename="qgeneratorrealcoalview.cpp" line="75"/>
        <source>QGeneratorRealCoalView</source>
        <oldsource>GeneratorPRealTimeCurve</oldsource>
        <translation>煤耗曲线</translation>
    </message>
    <message>
        <location filename="qgeneratorrealcoalview.cpp" line="33"/>
        <source>RealCoal</source>
        <translation>当前煤耗</translation>
    </message>
    <message>
        <location filename="qgeneratorrealcoalview.cpp" line="66"/>
        <source>realCoal:</source>
        <translation>当前煤耗:</translation>
    </message>
</context>
<context>
    <name>QGeneratorRealCurveView</name>
    <message>
        <source>QGeneratorRealCurveView</source>
        <translation type="obsolete">机组无功实时曲线</translation>
    </message>
    <message>
        <source>RealQ</source>
        <translation type="obsolete">实时无功</translation>
    </message>
    <message>
        <source>PlanQ</source>
        <translation type="obsolete">计划无功</translation>
    </message>
    <message>
        <source>GeneratorQRealTimeCurve</source>
        <translation type="obsolete">无功实时曲线</translation>
    </message>
    <message>
        <location filename="qgeneratorrealcurveview.cpp" line="36"/>
        <location filename="qgeneratorrealcurveview.cpp" line="109"/>
        <source>GeneratorPRealTimeCurve</source>
        <translation>有功实时曲线</translation>
    </message>
    <message>
        <location filename="qgeneratorrealcurveview.cpp" line="39"/>
        <source>RealP</source>
        <translation>实时有功</translation>
    </message>
    <message>
        <location filename="qgeneratorrealcurveview.cpp" line="40"/>
        <source>PlanP</source>
        <translation>计划有功</translation>
    </message>
    <message>
        <location filename="qgeneratorrealcurveview.cpp" line="41"/>
        <source>PUpLimit</source>
        <translation>有功上限</translation>
    </message>
    <message>
        <location filename="qgeneratorrealcurveview.cpp" line="42"/>
        <source>PDownLimit</source>
        <translation>有功下限</translation>
    </message>
    <message>
        <source>RealTP</source>
        <translation type="obsolete">当前热功率</translation>
    </message>
    <message>
        <source>PlanTP</source>
        <translation type="obsolete">计划热功率</translation>
    </message>
    <message>
        <source>RealCoal</source>
        <translation type="obsolete">当前煤耗</translation>
    </message>
    <message>
        <location filename="qgeneratorrealcurveview.cpp" line="100"/>
        <source>realP:</source>
        <translation>实时有功:</translation>
    </message>
    <message>
        <location filename="qgeneratorrealcurveview.cpp" line="100"/>
        <source>    planP:</source>
        <translation>    计划有功:</translation>
    </message>
    <message>
        <source>    PUp:</source>
        <translation type="obsolete">    有功上限:</translation>
    </message>
    <message>
        <source>    PDown:</source>
        <translation type="obsolete">    有功下限:</translation>
    </message>
    <message>
        <source>realTP:</source>
        <translation type="obsolete">当前热功率:</translation>
    </message>
    <message>
        <source>planTP:</source>
        <translation type="obsolete">    计划热功率:</translation>
    </message>
    <message>
        <source>realCoal:</source>
        <translation type="obsolete">当前煤耗:</translation>
    </message>
    <message>
        <source>P</source>
        <translation type="obsolete">有功</translation>
    </message>
    <message>
        <source>ThermalP</source>
        <translation type="obsolete">热功率</translation>
    </message>
    <message>
        <source>Coal</source>
        <translation type="obsolete">煤耗</translation>
    </message>
    <message>
        <location filename="qgeneratorrealcurveview.ui" line="14"/>
        <source>ScrollArea</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QGeneratorRealThermalPView</name>
    <message>
        <location filename="qgeneratorrealthermalpview.ui" line="14"/>
        <source>ScrollArea</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qgeneratorrealthermalpview.cpp" line="30"/>
        <location filename="qgeneratorrealthermalpview.cpp" line="83"/>
        <source>QGeneratorRealThermalPView</source>
        <translation>热功率实时曲线</translation>
    </message>
    <message>
        <location filename="qgeneratorrealthermalpview.cpp" line="33"/>
        <source>RealTP</source>
        <translation>当前热功率</translation>
    </message>
    <message>
        <location filename="qgeneratorrealthermalpview.cpp" line="34"/>
        <source>PlanTP</source>
        <translation>计划热功率</translation>
    </message>
    <message>
        <location filename="qgeneratorrealthermalpview.cpp" line="74"/>
        <source>realTP:</source>
        <translation>当前热功率:</translation>
    </message>
    <message>
        <location filename="qgeneratorrealthermalpview.cpp" line="74"/>
        <source>    planTP:</source>
        <translation>    计划热功率:</translation>
    </message>
</context>
<context>
    <name>QGeneratorSelectDlg</name>
    <message>
        <location filename="qgeneratorselectdlg.ui" line="14"/>
        <source>QGeneratorSelectDlg</source>
        <translation>机组无功实时曲线</translation>
    </message>
    <message>
        <location filename="qgeneratorselectdlg.ui" line="26"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qgeneratorselectdlg.ui" line="39"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qgeneratorselectdlg.ui" line="62"/>
        <source>GenSelect</source>
        <translation>选择机组</translation>
    </message>
</context>
<context>
    <name>QGeneratorlockConditionYC_ADD</name>
    <message>
        <location filename="qgeneratorlockconditionyc_add.ui" line="14"/>
        <source>QGeneratorlockConditionYC_ADD</source>
        <translation>添加遥测条件</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.ui" line="26"/>
        <source>generator</source>
        <translation>机组</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.ui" line="52"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.ui" line="78"/>
        <source>lockNAME</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.ui" line="104"/>
        <source>conditionnum</source>
        <translation>条件编号</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.ui" line="130"/>
        <source>checkType</source>
        <translation>比较类型</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.ui" line="142"/>
        <source>&gt;=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.ui" line="155"/>
        <source>&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.ui" line="168"/>
        <source>=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.ui" line="181"/>
        <source>&lt;=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.ui" line="194"/>
        <source>&lt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.ui" line="231"/>
        <source>threshold</source>
        <translation>门槛值</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.ui" line="254"/>
        <source>deadArea</source>
        <translation>死区</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.ui" line="277"/>
        <source>IDOKADD</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.ui" line="290"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.ui" line="303"/>
        <source>relatedYc</source>
        <oldsource>relatedYx</oldsource>
        <translation>关联遥测</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.cpp" line="123"/>
        <source>please unter checktype</source>
        <translation>请输入比较类型！</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.cpp" line="189"/>
        <source>INSERT</source>
        <translation>添加成功！</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyc_add.cpp" line="228"/>
        <source>YC_DATA open failed!</source>
        <translation>yc_data打开失败！</translation>
    </message>
</context>
<context>
    <name>QGeneratorlockConditionYX_ADD</name>
    <message>
        <location filename="qgeneratorlockconditionyx_add.ui" line="20"/>
        <source>QGeneratorlockConditionYX_ADD</source>
        <translation>添加遥信条件</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyx_add.ui" line="45"/>
        <source>conditionnum</source>
        <translation>条件编号</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyx_add.ui" line="71"/>
        <source>lockname</source>
        <translation>闭锁名称</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyx_add.ui" line="117"/>
        <source>locktype</source>
        <translation>闭锁类型</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyx_add.ui" line="130"/>
        <source>threshold</source>
        <translation>门槛值</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyx_add.ui" line="156"/>
        <source>generator</source>
        <translation>机组</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyx_add.ui" line="182"/>
        <source>IDCANCEL</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyx_add.ui" line="195"/>
        <source>IDOKADD</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyx_add.ui" line="208"/>
        <source>relatedYx</source>
        <translation>关联遥信</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyx_add.cpp" line="33"/>
        <source>exist </source>
        <translation></translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyx_add.cpp" line="97"/>
        <source>inserted</source>
        <translation>添加成功！</translation>
    </message>
    <message>
        <location filename="qgeneratorlockconditionyx_add.cpp" line="220"/>
        <source>YX_DATA open failed!</source>
        <translation>yx_data打开失败！</translation>
    </message>
</context>
<context>
    <name>QHisCurveQueryDlg</name>
    <message>
        <location filename="qhiscurvequerydlg.ui" line="14"/>
        <source>QHisCurveQueryDlg</source>
        <translation>机组数据查询</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.ui" line="26"/>
        <location filename="qhiscurvequerydlg.ui" line="62"/>
        <source>yyyy/MM/dd hh:mm:ss</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.ui" line="39"/>
        <source>query</source>
        <translation>查询</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.ui" line="75"/>
        <source>select gen</source>
        <translation>选择机组</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.ui" line="98"/>
        <source>close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.ui" line="111"/>
        <source>start time</source>
        <translation>起始时间</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.ui" line="124"/>
        <source>end time</source>
        <translation>终止时间</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.ui" line="153"/>
        <source>Next Page</source>
        <translation>下一页</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.ui" line="185"/>
        <source>Previous Page</source>
        <translation>上一页</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.ui" line="198"/>
        <source>Current Page</source>
        <translation>当前页</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.ui" line="211"/>
        <source>To</source>
        <translation>转到</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.ui" line="227"/>
        <source>Go</source>
        <translation>执行</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.ui" line="253"/>
        <source>Total Page</source>
        <translation>总页数</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.ui" line="266"/>
        <source>export</source>
        <translation>导出</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="112"/>
        <source>Time</source>
        <translation>时间</translation>
    </message>
    <message>
        <source>average_Q</source>
        <oldsource>Generator</oldsource>
        <translation type="obsolete">当前无功</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="62"/>
        <source>his_curve_gen open failed!</source>
        <translation>打开机组历史曲线失败！</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="113"/>
        <location filename="qhiscurvequerydlg.cpp" line="312"/>
        <source>high_p</source>
        <oldsource>high_Q</oldsource>
        <translation>最高有功</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="114"/>
        <location filename="qhiscurvequerydlg.cpp" line="313"/>
        <source>low_p</source>
        <oldsource>low_Q</oldsource>
        <translation>最低有功</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="115"/>
        <location filename="qhiscurvequerydlg.cpp" line="314"/>
        <source>avg_p</source>
        <translation>平均有功</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="116"/>
        <location filename="qhiscurvequerydlg.cpp" line="315"/>
        <source>cur_p</source>
        <translation>当前有功</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="117"/>
        <location filename="qhiscurvequerydlg.cpp" line="316"/>
        <source>plan_p</source>
        <translation>计划有功</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="118"/>
        <location filename="qhiscurvequerydlg.cpp" line="317"/>
        <source>high_thermal</source>
        <translation>最大热功率</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="119"/>
        <location filename="qhiscurvequerydlg.cpp" line="318"/>
        <source>low_thermal</source>
        <translation>最小热功率</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="120"/>
        <location filename="qhiscurvequerydlg.cpp" line="319"/>
        <source>avg_thermal</source>
        <translation>平均热功率</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="121"/>
        <location filename="qhiscurvequerydlg.cpp" line="320"/>
        <source>cur_thermal</source>
        <translation>当前热功率</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="122"/>
        <location filename="qhiscurvequerydlg.cpp" line="321"/>
        <source>plan_thermal</source>
        <translation>计划热功率</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="123"/>
        <location filename="qhiscurvequerydlg.cpp" line="322"/>
        <source>high_coal</source>
        <translation>最大煤耗</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="124"/>
        <location filename="qhiscurvequerydlg.cpp" line="323"/>
        <source>low_coal</source>
        <translation>最小煤耗</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="125"/>
        <location filename="qhiscurvequerydlg.cpp" line="324"/>
        <source>avg_coal</source>
        <translation>平均煤耗</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="126"/>
        <location filename="qhiscurvequerydlg.cpp" line="325"/>
        <source>cur_coal</source>
        <translation>当前煤耗</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="287"/>
        <source>Excel file</source>
        <translation>报表文件</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="287"/>
        <source>Files (*.csv)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="307"/>
        <source>gen_his</source>
        <translation>历史数据</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="310"/>
        <source>num</source>
        <translation>编号</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="311"/>
        <source>save time</source>
        <translation>存储时间</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="371"/>
        <source>Export data succeeded</source>
        <translation>导出数据成功</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="371"/>
        <source>Information saved in</source>
        <translation>信息已保存在</translation>
    </message>
    <message>
        <location filename="qhiscurvequerydlg.cpp" line="371"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <source>plan_Q</source>
        <translation type="obsolete">计划值</translation>
    </message>
    <message>
        <source>Vllage</source>
        <translation type="obsolete">机端电压</translation>
    </message>
    <message>
        <source>Power</source>
        <translation type="obsolete">有功</translation>
    </message>
    <message>
        <source>Cos</source>
        <translation type="obsolete">功率因数</translation>
    </message>
    <message>
        <source>All Gens</source>
        <translation type="obsolete">所有机组</translation>
    </message>
</context>
<context>
    <name>QHisCurveSvQueryDlg</name>
    <message>
        <location filename="qhiscurvesvquerydlg.ui" line="14"/>
        <source>QHisCurveSvQueryDlg</source>
        <translation>母线数据查询</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.ui" line="26"/>
        <source>cancel</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.ui" line="49"/>
        <source>end time</source>
        <translation>终止时间</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.ui" line="62"/>
        <source>query</source>
        <translation>查询</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.ui" line="75"/>
        <location filename="qhiscurvesvquerydlg.ui" line="88"/>
        <source>yyyy/MM/dd hh:mm:ss</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.ui" line="101"/>
        <source>select busbar</source>
        <translation>选择母线</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.ui" line="124"/>
        <source>start time</source>
        <translation>起始时间</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.ui" line="153"/>
        <source>Next Page</source>
        <translation>下一页</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.ui" line="185"/>
        <source>Previous Page</source>
        <translation>上一页</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.ui" line="198"/>
        <source>Current Page</source>
        <translation>当前页</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.ui" line="211"/>
        <source>To</source>
        <translation>转到</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.ui" line="227"/>
        <source>Go</source>
        <translation>执行</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.ui" line="253"/>
        <source>Total Page</source>
        <translation>总页数</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.ui" line="266"/>
        <source>export</source>
        <translation>导出</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.cpp" line="117"/>
        <source>Time</source>
        <translation>时间</translation>
    </message>
    <message>
        <source>Busbar</source>
        <translation type="obsolete">母线</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.cpp" line="65"/>
        <source>his_curve_bus open failed!</source>
        <translation>打开母线历史曲线失败！</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.cpp" line="118"/>
        <location filename="qhiscurvesvquerydlg.cpp" line="288"/>
        <source>high_p</source>
        <oldsource>high_SV</oldsource>
        <translation>最高</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.cpp" line="119"/>
        <location filename="qhiscurvesvquerydlg.cpp" line="289"/>
        <source>low_p</source>
        <oldsource>low_SV</oldsource>
        <translation>最低</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.cpp" line="120"/>
        <source>average_p</source>
        <oldsource>average_SV</oldsource>
        <translation>平均</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.cpp" line="121"/>
        <location filename="qhiscurvesvquerydlg.cpp" line="291"/>
        <source>cur_p</source>
        <translation>当前有功</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.cpp" line="122"/>
        <location filename="qhiscurvesvquerydlg.cpp" line="292"/>
        <source>plan_p</source>
        <translation>计划有功</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.cpp" line="259"/>
        <source>Excel file</source>
        <translation>报表文件</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.cpp" line="259"/>
        <source>Files (*.csv)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.cpp" line="283"/>
        <source>bus_his</source>
        <translation>历史数据</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.cpp" line="286"/>
        <source>num</source>
        <translation>编号</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.cpp" line="287"/>
        <source>save time</source>
        <translation>存储时间</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.cpp" line="290"/>
        <source>avg_p</source>
        <translation>平均有功</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.cpp" line="320"/>
        <source>Export data succeeded</source>
        <translation>导出数据成功</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.cpp" line="320"/>
        <source>Information saved in</source>
        <translation>信息已保存在</translation>
    </message>
    <message>
        <location filename="qhiscurvesvquerydlg.cpp" line="320"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <source>plan_SV</source>
        <translation type="obsolete">计划值</translation>
    </message>
    <message>
        <source>All Busbars</source>
        <translation type="obsolete">所有母线</translation>
    </message>
</context>
<context>
    <name>QJsTableView</name>
    <message>
        <source>number</source>
        <translation type="obsolete">编号</translation>
    </message>
    <message>
        <source>name</source>
        <translation type="obsolete">名称</translation>
    </message>
    <message>
        <source>process type</source>
        <translation type="obsolete">处理类型</translation>
    </message>
    <message>
        <source>run status</source>
        <translation type="obsolete">运行状态</translation>
    </message>
    <message>
        <source>coeficient</source>
        <translation type="obsolete">系数</translation>
    </message>
    <message>
        <source>calculate result</source>
        <translation type="obsolete">计算结果</translation>
    </message>
    <message>
        <source>update time</source>
        <translation type="obsolete">更新时间</translation>
    </message>
</context>
<context>
    <name>QLockSetDialog</name>
    <message>
        <location filename="clocksetdialog.ui" line="14"/>
        <source>Lock Setting</source>
        <translation>闭锁设置</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="26"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="39"/>
        <source>over reactive power rational limit</source>
        <oldsource>over eactive power rational limit</oldsource>
        <translation>越无功上上或下下限总闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="52"/>
        <source>over differencec of double measure</source>
        <translation>双量测差值大总闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="65"/>
        <source>over active power lower limit</source>
        <oldsource>over active power rational limit</oldsource>
        <translation>越有功下限总闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="78"/>
        <source>over stator current limit</source>
        <translation>定子电流越上限增闭锁,越越下限减闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="91"/>
        <source>over active power up limit</source>
        <translation>越有功上限增闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="104"/>
        <source>over factory volt up limit</source>
        <translation>越厂用电上限增闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="117"/>
        <source>over generator volt down limit</source>
        <translation>越机端电压下限减闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="130"/>
        <source>over factory volt lower limit</source>
        <translation>越厂用电下限减闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="143"/>
        <source>over factory volt rational limit</source>
        <translation>越厂用电上上或下下限总闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="156"/>
        <source>over rotor current limit</source>
        <translation>转子电流越上限增闭锁或越下限减闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="169"/>
        <source>over generator volt rational limit</source>
        <translation>越机端电压上上或下下限总闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="182"/>
        <source>over frequency  limit</source>
        <oldsource>over frequency lower limit</oldsource>
        <translation>越频率上限或下限总闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="195"/>
        <source>over reactive power lower limit</source>
        <translation>越无功下限减磁闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="208"/>
        <source>Low frequency oscillation</source>
        <translation>低频震荡总闭锁</translation>
    </message>
    <message>
        <source>over PQ limit</source>
        <translation type="obsolete">PQ图越限</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="221"/>
        <source>over system volt rational limit</source>
        <translation>越系统电压上上或下下限总闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="234"/>
        <source>over reactive power up limit</source>
        <translation>越无功上限增磁闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="247"/>
        <source>over syatem volt lower limit</source>
        <translation>越系统电压下限减磁闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="260"/>
        <source>over generator volt up limit</source>
        <translation>越机端电压上限增磁闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="273"/>
        <source>over syatem volt up limit</source>
        <translation>越系统电压上限增磁闭锁</translation>
    </message>
    <message>
        <location filename="clocksetdialog.ui" line="286"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>QOriTextView</name>
    <message>
        <source>copy original code data</source>
        <translation type="obsolete">复制源码数据</translation>
    </message>
</context>
<context>
    <name>QPlanCurveDispDlg31</name>
    <message>
        <location filename="qplancurvedispdlg31.ui" line="14"/>
        <source>QPlanCurveDispDlg31</source>
        <translation>31天计划曲线</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.ui" line="36"/>
        <source>date</source>
        <translation>日期</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.ui" line="59"/>
        <source>Seting</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.ui" line="71"/>
        <source>Plan Up Limit</source>
        <translation>计划上限</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.ui" line="94"/>
        <location filename="qplancurvedispdlg31.ui" line="120"/>
        <source>kV</source>
        <oldsource>KV</oldsource>
        <translation></translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.ui" line="107"/>
        <source>Plan Lower Limit</source>
        <translation>计划下限</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.ui" line="143"/>
        <source>Confirm Midify</source>
        <translation>确认修改</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.ui" line="156"/>
        <source>Start Time</source>
        <translation>起始时间</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.ui" line="169"/>
        <source>End Time</source>
        <translation>结束时间</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.ui" line="202"/>
        <source>Return</source>
        <translation>返回</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.ui" line="215"/>
        <source>copyti</source>
        <translation>复制到</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.ui" line="238"/>
        <source>updateMonths</source>
        <translation>更新全月</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.cpp" line="171"/>
        <source>PlanCurve</source>
        <translation>计划曲线</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.cpp" line="232"/>
        <location filename="qplancurvedispdlg31.cpp" line="308"/>
        <location filename="qplancurvedispdlg31.cpp" line="365"/>
        <source>Input data is out of adjustable range!</source>
        <oldsource>Input data is out of adjustable range��</oldsource>
        <translation>输入数据不在可调范围！</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.cpp" line="313"/>
        <location filename="qplancurvedispdlg31.cpp" line="370"/>
        <source>The lower limit of planned voltage should not be higher than the upper limit!</source>
        <oldsource>The lower limit of planned voltage should not be higher than the upper limit��</oldsource>
        <translation>计划电压下限不可高于上限！</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.cpp" line="245"/>
        <location filename="qplancurvedispdlg31.cpp" line="321"/>
        <location filename="qplancurvedispdlg31.cpp" line="378"/>
        <source>The starting time shall not be greater than the ending time!</source>
        <translation>开始时间不可大于结束时间！</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.cpp" line="152"/>
        <source>BUSBAR_AGC_31_PLAN open failed!</source>
        <translation>打开母线有功31天计划曲线失败！</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.cpp" line="237"/>
        <source>The lower limit of planned p should not be higher than the upper limit!</source>
        <translation>计划有功下限不能超过上限！</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.cpp" line="285"/>
        <source>Set up successfully!</source>
        <oldsource>Set up successfully��</oldsource>
        <translation>设置成功！</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.cpp" line="343"/>
        <location filename="qplancurvedispdlg31.cpp" line="400"/>
        <source>Replicating Success!</source>
        <oldsource>Replicating Success��</oldsource>
        <translation>复制成功！</translation>
    </message>
    <message>
        <location filename="qplancurvedispdlg31.cpp" line="425"/>
        <source>PLAN_CURVE_31DAY open failed!</source>
        <translation>打开31天计划曲线失败！</translation>
    </message>
</context>
<context>
    <name>QTimeoutMessageBox</name>
    <message>
        <location filename="qtimeoutmessagebox.ui" line="17"/>
        <source>QTimeoutMessageBox</source>
        <translation>超时对话框</translation>
    </message>
    <message>
        <location filename="qtimeoutmessagebox.ui" line="32"/>
        <source>TextLabel</source>
        <translation>文字标签</translation>
    </message>
    <message>
        <location filename="qtimeoutmessagebox.ui" line="45"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="qtimeoutmessagebox.ui" line="58"/>
        <source>CANCEL</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>QYcTableView</name>
    <message>
        <source>number</source>
        <translation type="obsolete">编号</translation>
    </message>
    <message>
        <source>substation number</source>
        <translation type="obsolete">子站编号</translation>
    </message>
    <message>
        <source>line number</source>
        <translation type="obsolete">线路编号</translation>
    </message>
    <message>
        <source>name</source>
        <translation type="obsolete">名称</translation>
    </message>
    <message>
        <source>attribute</source>
        <translation type="obsolete">属性</translation>
    </message>
    <message>
        <source>process type</source>
        <translation type="obsolete">处理类型</translation>
    </message>
    <message>
        <source>run status</source>
        <translation type="obsolete">运行状态</translation>
    </message>
    <message>
        <source>coeficient</source>
        <translation type="obsolete">系数</translation>
    </message>
    <message>
        <source>up limit</source>
        <translation type="obsolete">上限</translation>
    </message>
    <message>
        <source>up up limit</source>
        <translation type="obsolete">上上限</translation>
    </message>
    <message>
        <source>down limit</source>
        <translation type="obsolete">下限</translation>
    </message>
    <message>
        <source>down down limit</source>
        <translation type="obsolete">下下限</translation>
    </message>
    <message>
        <source>raw data</source>
        <translation type="obsolete">生数据</translation>
    </message>
    <message>
        <source>real value</source>
        <translation type="obsolete">实际值</translation>
    </message>
    <message>
        <source>update time</source>
        <translation type="obsolete">更新时间</translation>
    </message>
</context>
<context>
    <name>QYkTableView</name>
    <message>
        <source>number</source>
        <translation type="obsolete">编号</translation>
    </message>
    <message>
        <source>yx name</source>
        <translation type="obsolete">遥信名称</translation>
    </message>
    <message>
        <source>run status</source>
        <translation type="obsolete">运行状态</translation>
    </message>
    <message>
        <source>yk status</source>
        <translation type="obsolete">遥控状态</translation>
    </message>
    <message>
        <source>change time</source>
        <translation type="obsolete">变为时间</translation>
    </message>
</context>
<context>
    <name>QYtTableView</name>
    <message>
        <source>number</source>
        <translation type="obsolete">编号</translation>
    </message>
    <message>
        <source>yc name</source>
        <translation type="obsolete">遥测名称</translation>
    </message>
    <message>
        <source>rational up limit</source>
        <translation type="obsolete">合理上限</translation>
    </message>
    <message>
        <source>rational down limit</source>
        <translation type="obsolete">合理下限</translation>
    </message>
    <message>
        <source>targe up limit</source>
        <translation type="obsolete">目标上限</translation>
    </message>
    <message>
        <source>target down limit</source>
        <translation type="obsolete">目标下限</translation>
    </message>
    <message>
        <source>run status</source>
        <translation type="obsolete">运行状态</translation>
    </message>
    <message>
        <source>yt dw</source>
        <translation type="obsolete">遥调挡位</translation>
    </message>
    <message>
        <source>update time</source>
        <translation type="obsolete">更新时间</translation>
    </message>
</context>
<context>
    <name>QYxTableView</name>
    <message>
        <source>number</source>
        <translation type="obsolete">编号</translation>
    </message>
    <message>
        <source>substation number</source>
        <translation type="obsolete">子站编号</translation>
    </message>
    <message>
        <source>line number</source>
        <translation type="obsolete">线路编号</translation>
    </message>
    <message>
        <source>name</source>
        <translation type="obsolete">名称</translation>
    </message>
    <message>
        <source>attribute</source>
        <translation type="obsolete">属性</translation>
    </message>
    <message>
        <source>process type</source>
        <translation type="obsolete">处理类型</translation>
    </message>
    <message>
        <source>status</source>
        <translation type="obsolete">状态</translation>
    </message>
    <message>
        <source>change time</source>
        <translation type="obsolete">变位时间</translation>
    </message>
    <message>
        <source>change interval</source>
        <translation type="obsolete">变位累计时间</translation>
    </message>
</context>
<context>
    <name>QStartFormWidget</name>
    <message>
        <source>Analog Value</source>
        <translation type="obsolete">模拟量</translation>
    </message>
    <message>
        <source>Statis Value</source>
        <translation type="obsolete">状态量</translation>
    </message>
    <message>
        <source>Manual Set</source>
        <translation type="obsolete">人工设定</translation>
    </message>
    <message>
        <source>User Picture</source>
        <translation type="obsolete">用户图形</translation>
    </message>
    <message>
        <source>Calculate Value</source>
        <translation type="obsolete">计算量</translation>
    </message>
    <message>
        <source>Remote Control</source>
        <translation type="obsolete">遥控量</translation>
    </message>
    <message>
        <source>Remote Adjust</source>
        <translation type="obsolete">遥调量</translation>
    </message>
</context>
<context>
    <name>QWarnInfoSelectDlg</name>
    <message>
        <location filename="warninfoselectdlg.ui" line="14"/>
        <source>WarnInfoQueryDlg</source>
        <translation>报警信息查询</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.ui" line="26"/>
        <location filename="warninfoselectdlg.ui" line="39"/>
        <source>yyyy/MM/dd hh:mm:ss</source>
        <translation></translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.ui" line="52"/>
        <source>start time</source>
        <translation>起始时间</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.ui" line="65"/>
        <source>query</source>
        <translation>查询</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.ui" line="78"/>
        <source>close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.ui" line="91"/>
        <source>end time</source>
        <translation>终止时间</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.ui" line="117"/>
        <source>Previous Page</source>
        <translation>上一页</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.ui" line="133"/>
        <source>Next Page</source>
        <translation>下一页</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.ui" line="146"/>
        <source>To</source>
        <translation>转到</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.ui" line="178"/>
        <source>Go</source>
        <translation>执行</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.ui" line="191"/>
        <source>Total Page</source>
        <translation>总页数</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.ui" line="217"/>
        <source>Current Page</source>
        <translation>当前页</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.ui" line="243"/>
        <source>export</source>
        <translation>导出</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.cpp" line="34"/>
        <source>Time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.cpp" line="35"/>
        <source>Content</source>
        <translation>内容</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.cpp" line="69"/>
        <source>warn_info open failed!</source>
        <translation>打开告警信息失败！</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.cpp" line="214"/>
        <source>Excel file</source>
        <translation>报表文件</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.cpp" line="214"/>
        <source>Files (*.csv)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.cpp" line="231"/>
        <location filename="warninfoselectdlg.cpp" line="236"/>
        <source>warn info</source>
        <oldsource>adjust info</oldsource>
        <translation>告警信息</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.cpp" line="234"/>
        <source>num</source>
        <translation>编号</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.cpp" line="235"/>
        <source>warn time</source>
        <translation>告警时间</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.cpp" line="258"/>
        <source>Export data succeeded</source>
        <translation>导出数据成功</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.cpp" line="258"/>
        <source>Information saved in</source>
        <translation>信息已保存在</translation>
    </message>
    <message>
        <location filename="warninfoselectdlg.cpp" line="258"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
</context>
<context>
    <name>oriSelDlg</name>
    <message>
        <source>origin code select</source>
        <translation type="obsolete">源码选择</translation>
    </message>
    <message>
        <source>chunnel name</source>
        <translation type="obsolete">通道名称</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">取消取消</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="obsolete">确定确定</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation type="obsolete">方向</translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="obsolete">上行</translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="obsolete">下行</translation>
    </message>
    <message>
        <source>highlight1</source>
        <translation type="obsolete">特显1</translation>
    </message>
    <message>
        <source>highlight2</source>
        <translation type="obsolete">特显2</translation>
    </message>
    <message>
        <source>please select chunnel</source>
        <translation type="obsolete">请选择通道</translation>
    </message>
</context>
</TS>
